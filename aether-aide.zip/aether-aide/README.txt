=== AETHER AI สำหรับ AIDE ===

วิธีติดตั้ง:

1. ติดตั้ง AIDE จาก Play Store
2. แตกไฟล์ zip นี้ไปไว้ในเครื่อง
3. เปิด AIDE → Open Project → เลือกโฟลเดอร์ aether-aide
4. กด Build (▶) → รอสักครู่
5. APK จะอยู่ที่ app/build/outputs/apk/

วิธีใช้:

1. ติดตั้ง APK
2. เปิดแอป Aether AI
3. กด "เริ่ม AI"
4. อนุญาต permissions ที่ขอ
5. เปิดเกม 8 Ball Pool
6. ESP จะแสดงบนจอเกม

หมายเหตุ:

- ต้องมี Android 5.0 ขึ้นไป
- ต้องอนุญาต Overlay, Accessibility
- ถ้า build ไม่ผ่าน ลองลด compileSdkVersion เหลือ 26
