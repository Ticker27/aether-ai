package com.aether.vision;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.aether.game.Ball;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * ตรวจจับลูกบิลเลียดจาก Miniclip 8 Ball Pool
 * ค่าสี HSV ปรับจากเกมจริง (Android)
 *
 * IMPORTANT: Miniclip 8 Ball Pool ใช้สีสดใสกว่าลูกจริง
 * โต๊ะสีเขียวเข้ม (H:100-140) ต้องกรองออก
 */
public class BallDetector {
    private static final String TAG = "AetherBall";

    // === ค่าคงที่ ===
    private static final float MIN_BALL_RADIUS_PX = 10f;
    private static final float MAX_BALL_RADIUS_PX = 40f;
    private static final int   SCAN_STEP = 2;
    private static final float CLUSTER_DIST = 25f;

    // === โต๊ะสีเขียว (ต้องกรองออก) ===
    // Miniclip table: H:100-140, S:30-80, V:20-60
    private static final float TABLE_H_MIN = 95f;
    private static final float TABLE_H_MAX = 145f;
    private static final float TABLE_S_MIN = 25f;
    private static final float TABLE_S_MAX = 85f;

    // =====================================================
    //  ค่าสี HSV จาก Miniclip 8 Ball Pool เกมจริง
    //
    //  {hMin, hMax, sMin, sMax, vMin, vMax, ballNumber}
    //
    //  NOTE: hMin > hMax = hue wrap-around (ผ่าน 0/360)
    // =====================================================
    private static final float[][] COLOR_PROFILES = {

        // ──────────────────────────────────────
        //  SOLID BALLS (1-7)
        // ──────────────────────────────────────

        // 1: YELLOW — สีเหลืองสด (Miniclip)
        //    RGB ≈ (255, 205, 0) → HSV ≈ (48, 100%, 100%)
        {35f, 55f, 0.70f, 1.0f, 0.80f, 1.0f, 1},

        // 2: BLUE — น้ำเงินเข้ม (Miniclip)
        //    RGB ≈ (0, 70, 190) → HSV ≈ (218, 100%, 75%)
        {195f, 230f, 0.60f, 1.0f, 0.50f, 1.0f, 2},

        // 3: RED — แดงสด (Miniclip)
        //    RGB ≈ (220, 30, 30) → HSV ≈ (0, 86%, 86%)
        {345f, 360f, 0.60f, 1.0f, 0.60f, 1.0f, 3},  // wrap
        {0f, 12f, 0.60f, 1.0f, 0.60f, 1.0f, 3},

        // 4: PURPLE — ม่วง (Miniclip)
        //    RGB ≈ (130, 0, 190) → HSV ≈ (281, 100%, 75%)
        {265f, 305f, 0.50f, 1.0f, 0.45f, 1.0f, 4},

        // 5: ORANGE — ส้มสด (Miniclip)
        //    RGB ≈ (255, 130, 0) → HSV ≈ (30, 100%, 100%)
        {12f, 32f, 0.70f, 1.0f, 0.75f, 1.0f, 5},

        // 6: GREEN — เขียว (Miniclip)
        //    RGB ≈ (0, 150, 50) → HSV ≈ (140, 100%, 59%)
        //    ⚠️ ระวังซ้ำกับสีโต๊ะ! ใช้ S สูงกว่าโต๊ะ
        {130f, 160f, 0.55f, 1.0f, 0.45f, 1.0f, 6},

        // 7: MAROON — น้ำตาลเข้ม/แดงเลือดหมู (Miniclip)
        //    RGB ≈ (140, 20, 20) → HSV ≈ (0, 86%, 55%)
        {345f, 360f, 0.50f, 1.0f, 0.30f, 0.65f, 7},  // wrap
        {0f, 12f, 0.50f, 1.0f, 0.30f, 0.65f, 7},

        // ──────────────────────────────────────
        //  EIGHT BALL (8)
        // ──────────────────────────────────────

        // 8: BLACK — ดำ
        //    RGB ≈ (20, 20, 20) → HSV ≈ (0, 0%, 8%)
        {0f, 360f, 0f, 0.40f, 0f, 0.25f, 8},

        // ──────────────────────────────────────
        //  STRIPE BALLS (9-15)
        //  สีเดียวกับ solid แต่มีแถบขาว
        //  ตรวจจับจาก "ขอบสี + กลางขาว"
        // ──────────────────────────────────────

        // 9: YELLOW STRIPE — ขอบเหลือง + กลางขาว
        {35f, 55f, 0.50f, 0.80f, 0.70f, 1.0f, 9},

        // 10: BLUE STRIPE — ขอบน้ำเงิน + กลางขาว
        {195f, 230f, 0.40f, 0.75f, 0.45f, 1.0f, 10},

        // 11: RED STRIPE — ขอบแดง + กลางขาว
        {345f, 360f, 0.40f, 0.75f, 0.55f, 1.0f, 11},
        {0f, 12f, 0.40f, 0.75f, 0.55f, 1.0f, 11},

        // 12: PURPLE STRIPE — ขอบม่วง + กลางขาว
        {265f, 305f, 0.35f, 0.70f, 0.40f, 1.0f, 12},

        // 13: ORANGE STRIPE — ขอบส้ม + กลางขาว
        {12f, 32f, 0.50f, 0.80f, 0.65f, 1.0f, 13},

        // 14: GREEN STRIPE — ขอบเขียว + กลางขาว
        {130f, 160f, 0.40f, 0.70f, 0.40f, 1.0f, 14},

        // 15: MAROON STRIPE — ขอบน้ำตาล + กลางขาว
        {345f, 360f, 0.35f, 0.65f, 0.25f, 0.60f, 15},
        {0f, 12f, 0.35f, 0.65f, 0.25f, 0.60f, 15},
    };

    // === ข้อมูลโต๊ะ ===
    private float tableLeft, tableTop, tableRight, tableBottom;

    public void setTableBounds(float left, float top, float right, float bottom) {
        this.tableLeft = left;
        this.tableTop = top;
        this.tableRight = right;
        this.tableBottom = bottom;
    }

    // =====================================================
    //  ตรวจจับลูกทั้งหมด
    // =====================================================
    public List<Ball> detect(Bitmap frame) {
        List<Ball> detected = new ArrayList<>();
        if (frame == null) return detected;

        int w = frame.getWidth();
        int h = frame.getHeight();

        // === 1. ตรวจจับลูก Cue (ขาว) ===
        List<Vec2> cuePoints = findWhitePixels(frame);
        Vec2 cueCenter = findBestCenter(cuePoints);
        if (cueCenter != null) {
            detected.add(new Ball(0, normalize(cueCenter, w, h), Color.WHITE));
        }

        // === 2. ตรวจจับลูก 8 (ดำ) ===
        List<Vec2> blackPoints = findBlackPixels(frame);
        Vec2 eightCenter = findBestCenter(blackPoints);
        if (eightCenter != null && !isDuplicate(eightCenter, detected, w, h)) {
            detected.add(new Ball(8, normalize(eightCenter, w, h),
                Ball.getBallColor(8)));
        }

        // === 3. ตรวจจับลูกสี (1-7, 9-15) ===
        for (float[] profile : COLOR_PROFILES) {
            int ballNum = (int) profile[6];
            if (ballNum == 0 || ballNum == 8) continue; // ตรวจแยกแล้ว

            List<Vec2> points = findColorPixels(frame,
                profile[0], profile[1], profile[2], profile[3],
                profile[4], profile[5]);

            Vec2 center = findBestCenter(points);
            if (center != null && !isDuplicate(center, detected, w, h)) {
                detected.add(new Ball(ballNum, normalize(center, w, h),
                    Ball.getBallColor(ballNum)));
            }
        }

        // === 4. ตรวจจับ Stripe จาก pattern (ขอบสี + กลางขาว) ===
        detectStripesFromPattern(frame, detected, w, h);

        // === 5. เรียงลำดับตามหมายเลข ===
        Collections.sort(detected, (a, b) -> Integer.compare(a.number, b.number));

        return detected;
    }

    // =====================================================
    //  หา pixel สีขาว (ลูก Cue)
    // =====================================================
    private List<Vec2> findWhitePixels(Bitmap frame) {
        List<Vec2> points = new ArrayList<>();
        int w = frame.getWidth(), h = frame.getHeight();
        int startX = Math.max(0, (int) tableLeft);
        int startY = Math.max(0, (int) tableTop);
        int endX = Math.min(w, (int) tableRight);
        int endY = Math.min(h, (int) tableBottom);

        for (int y = startY; y < endY; y += SCAN_STEP) {
            for (int x = startX; x < endX; x += SCAN_STEP) {
                int pixel = frame.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                // ขาว: saturation ต่ำ, value สูง
                if (hsv[1] < 0.20f && hsv[2] > 0.85f) {
                    // ไม่ใช่ไฮไลท์ (specular highlight บนลูก)
                    if (hsv[2] < 0.98f) {
                        points.add(new Vec2(x, y));
                    }
                }
            }
        }
        return points;
    }

    // =====================================================
    //  หา pixel ดำ (ลูก 8)
    // =====================================================
    private List<Vec2> findBlackPixels(Bitmap frame) {
        List<Vec2> points = new ArrayList<>();
        int w = frame.getWidth(), h = frame.getHeight();
        int startX = Math.max(0, (int) tableLeft);
        int startY = Math.max(0, (int) tableTop);
        int endX = Math.min(w, (int) tableRight);
        int endY = Math.min(h, (int) tableBottom);

        for (int y = startY; y < endY; y += SCAN_STEP) {
            for (int x = startX; x < endX; x += SCAN_STEP) {
                int pixel = frame.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                // ดำ: value ต่ำ
                if (hsv[2] < 0.25f && hsv[1] < 0.40f) {
                    points.add(new Vec2(x, y));
                }
            }
        }
        return points;
    }

    // =====================================================
    //  หา pixel ตามช่วงสี HSV
    // =====================================================
    private List<Vec2> findColorPixels(Bitmap frame,
            float hMin, float hMax, float sMin, float sMax,
            float vMin, float vMax) {
        List<Vec2> points = new ArrayList<>();
        int w = frame.getWidth(), h = frame.getHeight();
        int startX = Math.max(0, (int) tableLeft);
        int startY = Math.max(0, (int) tableTop);
        int endX = Math.min(w, (int) tableRight);
        int endY = Math.min(h, (int) tableBottom);

        for (int y = startY; y < endY; y += SCAN_STEP) {
            for (int x = startX; x < endX; x += SCAN_STEP) {
                int pixel = frame.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                float hue = hsv[0]; // 0-360
                float sat = hsv[1]; // 0-1
                float val = hsv[2]; // 0-1

                // กรองสีโต๊ะออก
                if (isTableColor(hue, sat, val)) continue;

                // Hue match (รองรับ wrap-around)
                boolean hueMatch;
                if (hMin > hMax) {
                    hueMatch = hue >= hMin || hue <= hMax;
                } else {
                    hueMatch = hue >= hMin && hue <= hMax;
                }

                if (hueMatch && sat >= sMin && sat <= sMax
                    && val >= vMin && val <= vMax) {
                    points.add(new Vec2(x, y));
                }
            }
        }
        return points;
    }

    // =====================================================
    //  ตรวจจับ Stripe จาก pattern (ขอบสี + กลางขาว)
    // =====================================================
    private void detectStripesFromPattern(Bitmap frame, List<Ball> existing,
                                           int w, int h) {
        // Stripe มีลักษณะ: ขอบบน/ล่างเป็นสี, กลางเป็นแถบขาว
        // ใช้ vertical scan ผ่านลูกที่ตรวจเจอแล้ว

        for (Ball ball : new ArrayList<>(existing)) {
            if (ball.number == 0 || ball.number == 8) continue;
            if (ball.number >= 9) continue; // ตรวจ stripe แล้ว

            // แปลงเป็น pixel coordinate
            Vec2 px = denormalize(ball.pos, w, h);
            int cx = (int) px.x;
            int cy = (int) px.y;
            int r = 20; // approximate radius in pixels

            // สแกนแนวตั้งผ่านศูนย์กลาง
            int colorCount = 0;
            int whiteCount = 0;

            for (int dy = -r; dy <= r; dy += 2) {
                int py = cy + dy;
                if (py < 0 || py >= h) continue;

                int pixel = frame.getPixel(Math.max(0, Math.min(cx, w - 1)), py);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                if (hsv[1] < 0.20f && hsv[2] > 0.80f) {
                    whiteCount++;
                } else if (hsv[1] > 0.40f) {
                    colorCount++;
                }
            }

            // Stripe: มีทั้งสีและขาวในสัดส่วนที่ใกล้เคียง
            float ratio = (float) whiteCount / Math.max(1, colorCount + whiteCount);
            if (ratio > 0.25f && ratio < 0.65f) {
                // น่าจะเป็น stripe → เปลี่ยนหมายเลข
                ball.number += 8; // 1→9, 2→10, ..., 7→15
            }
        }
    }

    // =====================================================
    //  Helper: ตรวจว่าเป็นสีโต๊ะไหม
    // =====================================================
    private boolean isTableColor(float hue, float sat, float val) {
        return hue >= TABLE_H_MIN && hue <= TABLE_H_MAX
            && sat >= TABLE_S_MIN && sat <= TABLE_S_MAX;
    }

    // =====================================================
    //  Helper: หา centroid ของกลุ่มจุด
    // =====================================================
    private Vec2 findBestCenter(List<Vec2> points) {
        if (points.size() < 5) return null;

        List<List<Vec2>> clusters = clusterPoints(points, CLUSTER_DIST);

        List<Vec2> best = null;
        int bestSize = 0;

        for (List<Vec2> cluster : clusters) {
            if (cluster.size() > bestSize) {
                bestSize = cluster.size();
                best = cluster;
            }
        }

        if (best == null || best.size() < 3) return null;

        float cx = 0, cy = 0;
        for (Vec2 p : best) { cx += p.x; cy += p.y; }
        return new Vec2(cx / best.size(), cy / best.size());
    }

    // =====================================================
    //  Helper: จัดกลุ่มจุด (simple clustering)
    // =====================================================
    private List<List<Vec2>> clusterPoints(List<Vec2> points, float maxDist) {
        List<List<Vec2>> clusters = new ArrayList<>();
        boolean[] used = new boolean[points.size()];

        for (int i = 0; i < points.size(); i++) {
            if (used[i]) continue;
            List<Vec2> cluster = new ArrayList<>();
            cluster.add(points.get(i));
            used[i] = true;

            for (int j = i + 1; j < points.size(); j++) {
                if (used[j]) continue;
                if (points.get(i).distTo(points.get(j)) < maxDist) {
                    cluster.add(points.get(j));
                    used[j] = true;
                }
            }
            if (cluster.size() >= 3) clusters.add(cluster);
        }
        return clusters;
    }

    // =====================================================
    //  Helper: ตรวจซ้ำ
    // =====================================================
    private boolean isDuplicate(Vec2 pos, List<Ball> existing, int w, int h) {
        Vec2 norm = normalize(pos, w, h);
        for (Ball b : existing) {
            if (norm.distTo(b.pos) < 0.05f) return true;
        }
        return false;
    }

    // =====================================================
    //  Helper: แปลงพิกัด
    // =====================================================
    private Vec2 normalize(Vec2 pixel, int w, int h) {
        return new Vec2(
            (pixel.x - tableLeft) / (tableRight - tableLeft),
            (pixel.y - tableTop) / (tableBottom - tableTop)
        );
    }

    private Vec2 denormalize(Vec2 norm, int w, int h) {
        return new Vec2(
            norm.x * (tableRight - tableLeft) + tableLeft,
            norm.y * (tableBottom - tableTop) + tableTop
        );
    }
}
