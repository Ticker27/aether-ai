package com.aether.vision;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * ตรวจจับโต๊ะและหลุมทั้ง 6 อัตโนมัติ
 * — หาขอบโต๊ะจากสีเขียว
 * — หาหลุมจากจุดดำ/ขอบมืด
 * — Fix ตำแหน่งให้ตรงกับจอจริง
 */
public class TableDetector {
    private static final String TAG = "AetherTable";

    // === ค่าคงที่ ===
    private static final float TABLE_ASPECT_RATIO = 2.0f;  // โต๊ะจริง กว้าง:ยาว = 2:1
    private static final float ASPECT_TOLERANCE = 0.3f;     // ความคลาดเคลื่อน
    private static final int MIN_TABLE_SIZE = 100;           // ขนาดโต๊ะขั้นต่ำ (pixels)
    private static final float POCKET_SIZE_RATIO = 0.04f;    // ขนาดหลุมเทียบโต๊ะ

    // === ผลลัพธ์ ===
    public static class TableResult {
        public boolean found;
        public float left, top, right, bottom;  // ขอบโต๊ะ (pixels)
        public float width, height;
        public Vec2[] pockets = new Vec2[6];     // ตำแหน่งหลุม 6 จุด
        public float confidence;                  // ความมั่นใจ (0-1)

        public float getCenterX() { return (left + right) / 2; }
        public float getCenterY() { return (top + bottom) / 2; }

        public String toString() {
            return String.format("Table[%.0f,%.0f - %.0f,%.0f] %dx%d conf=%.2f",
                left, top, right, bottom, (int)width, (int)height, confidence);
        }
    }

    /**
     * ตรวจจับโต๊ะและหลุมจากภาพหน้าจอ
     */
    public static TableResult detect(Bitmap frame) {
        TableResult result = new TableResult();

        int w = frame.getWidth();
        int h = frame.getHeight();

        // === 1. หาขอบโต๊ะจากสีเขียว ===
        int[] tableBounds = findTableBounds(frame);
        if (tableBounds == null) {
            Log.w(TAG, "Table not found");
            result.found = false;
            return result;
        }

        result.left = tableBounds[0];
        result.top = tableBounds[1];
        result.right = tableBounds[2];
        result.bottom = tableBounds[3];
        result.width = result.right - result.left;
        result.height = result.bottom - result.top;

        // ตรวจสอบอัตราส่วน (โต๊ะจริง ≈ 2:1)
        float ratio = result.width / result.height;
        if (ratio < TABLE_ASPECT_RATIO - ASPECT_TOLERANCE ||
            ratio > TABLE_ASPECT_RATIO + ASPECT_TOLERANCE) {
            Log.w(TAG, "Aspect ratio mismatch: " + ratio);
            // ไม่ reject แต่ลด confidence
            result.confidence = 0.5f;
        } else {
            result.confidence = 0.9f;
        }

        // === 2. หาหลุมทั้ง 6 ===
        result.pockets = findPockets(frame, result);
        result.found = true;

        Log.d(TAG, "Table found: " + result);
        for (int i = 0; i < 6; i++) {
            Log.d(TAG, String.format("  Pocket %d: (%.0f, %.0f)",
                i, result.pockets[i].x, result.pockets[i].y));
        }

        return result;
    }

    /**
     * หาขอบโต๊ะจากสีเขียว (table cloth)
     */
    private static int[] findTableBounds(Bitmap frame) {
        int w = frame.getWidth();
        int h = frame.getHeight();

        // สแกนแนวนอนเพื่อหาขอบบน/ล่าง
        int topBound = -1, bottomBound = -1;

        for (int y = 0; y < h; y += 3) {
            int greenCount = 0;
            for (int x = 0; x < w; x += 5) {
                if (isTableGreen(frame.getPixel(x, y))) {
                    greenCount++;
                }
            }
            float greenRatio = (float) greenCount / (w / 5);

            if (topBound < 0 && greenRatio > 0.5f) {
                topBound = y;
            }
            if (greenRatio > 0.5f) {
                bottomBound = y;
            }
        }

        if (topBound < 0 || bottomBound < 0 || bottomBound - topBound < MIN_TABLE_SIZE) {
            return null;
        }

        // สแกนแนวตั้งเพื่อหาขอบซ้าย/ขวา
        int leftBound = -1, rightBound = -1;
        int midY = (topBound + bottomBound) / 2;

        for (int x = 0; x < w; x += 3) {
            if (isTableGreen(frame.getPixel(x, midY))) {
                if (leftBound < 0) leftBound = x;
                rightBound = x;
            }
        }

        if (leftBound < 0 || rightBound < 0 || rightBound - leftBound < MIN_TABLE_SIZE) {
            return null;
        }

        // ขยายขอบเล็กน้อย (รวมขอบโต๊ะ)
        int padding = (int) ((rightBound - leftBound) * 0.02f);
        leftBound = Math.max(0, leftBound - padding);
        rightBound = Math.min(w, rightBound + padding);
        topBound = Math.max(0, topBound - padding);
        bottomBound = Math.min(h, bottomBound + padding);

        return new int[]{leftBound, topBound, rightBound, bottomBound};
    }

    /**
     * หาหลุมทั้ง 6 จากตำแหน่งขอบโต๊ะ
     * หลุมอยู่ที่มุม 4 จุด + กลางขอบ 2 จุด
     */
    private static Vec2[] findPockets(Bitmap frame, TableResult table) {
        Vec2[] pockets = new Vec2[6];

        float margin = table.width * 0.03f;  // ระยะจากขอบ

        // มุม 4 หลุม
        pockets[0] = new Vec2(table.left + margin, table.top + margin);                    // บนซ้าย
        pockets[1] = new Vec2(table.getCenterX(), table.top - margin * 0.5f);              // บนกลาง
        pockets[2] = new Vec2(table.right - margin, table.top + margin);                   // บนขวา
        pockets[3] = new Vec2(table.left + margin, table.bottom - margin);                 // ล่างซ้าย
        pockets[4] = new Vec2(table.getCenterX(), table.bottom + margin * 0.5f);           // ล่างกลาง
        pockets[5] = new Vec2(table.right - margin, table.bottom - margin);                // ล่างขวา

        // ปรับตำแหน่งจากภาพจริง (ตรวจจับจุดดำ)
        adjustPocketPositions(frame, pockets, table);

        return pockets;
    }

    /**
     * ปรับตำแหน่งหลุมจากจุดดำในภาพ
     */
    private static void adjustPocketPositions(Bitmap frame, Vec2[] pockets, TableResult table) {
        int searchRadius = (int) (table.width * 0.05f);

        for (int i = 0; i < 6; i++) {
            Vec2 pocket = pockets[i];
            Vec2 adjusted = findDarkestPoint(frame,
                (int) pocket.x, (int) pocket.y, searchRadius);

            if (adjusted != null) {
                pockets[i] = adjusted;
            }
        }
    }

    /**
     * หาจุดที่มืดที่สุดในรัศมีที่กำหนด
     */
    private static Vec2 findDarkestPoint(Bitmap frame, int cx, int cy, int radius) {
        int w = frame.getWidth();
        int h = frame.getHeight();

        float darkestVal = 1.0f;
        int darkestX = cx, darkestY = cy;
        boolean found = false;

        for (int dy = -radius; dy <= radius; dy += 2) {
            for (int dx = -radius; dx <= radius; dx += 2) {
                int x = cx + dx;
                int y = cy + dy;

                if (x < 0 || x >= w || y < 0 || y >= h) continue;

                int pixel = frame.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                if (hsv[2] < darkestVal) {
                    darkestVal = hsv[2];
                    darkestX = x;
                    darkestY = y;
                    found = true;
                }
            }
        }

        return found ? new Vec2(darkestX, darkestY) : null;
    }

    /**
     * ตรวจว่า pixel เป็นสีเขียวโต๊ะไหม
     */
    private static boolean isTableGreen(int pixel) {
        float[] hsv = new float[3];
        Color.colorToHSV(pixel, hsv);

        // สีเขียวโต๊ะ: H: 90-150, S: 20-80, V: 15-65
        return hsv[0] >= 90 && hsv[0] <= 150
            && hsv[1] >= 0.20f && hsv[1] <= 0.80f
            && hsv[2] >= 0.15f && hsv[2] <= 0.65f;
    }

    /**
     * แปลงตำแหน่งหลุมเป็น normalized (0-1)
     */
    public static Vec2[] normalizePockets(Vec2[] pockets, TableResult table) {
        Vec2[] normalized = new Vec2[6];
        for (int i = 0; i < 6; i++) {
            normalized[i] = new Vec2(
                (pockets[i].x - table.left) / table.width,
                (pockets[i].y - table.top) / table.height
            );
        }
        return normalized;
    }
}
