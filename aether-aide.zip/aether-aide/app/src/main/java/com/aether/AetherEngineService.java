package com.aether;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/**
 * Aether Engine — Foreground Service หลัก
 * ทำงานเบื้องหลังตลอดเวลา
 */
public class AetherEngineService extends Service {
    private static final String TAG = "AetherEngine";
    private static final String CHANNEL_ID = "aether_engine";
    private static final int NOTIFICATION_ID = 1001;

    private volatile boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Log.d(TAG, "Engine Service created");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Start foreground
        Notification notification = buildNotification("Aether AI กำลังเริ่ม...");
        startForeground(NOTIFICATION_ID, notification);

        running = true;
        Log.d(TAG, "Engine Service started");

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        stopForeground(true);
        super.onDestroy();
        Log.d(TAG, "Engine Service stopped");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    /**
     * อัปเดตข้อความ notification
     */
    public void updateStatus(String status) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(status));
    }

    private Notification buildNotification(String text) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        return builder
            .setContentTitle("👁️ Aether AI")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pending)
            .setOngoing(true)
            .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Aether Engine",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Aether AI Engine Service");
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }
}
