package com.aether.vision;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import com.aether.game.Ball;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ปรับค่า HSV อัตโนมัติตามหน้าจอ/อุปกรณ์
 * — วิเคราะห์ screenshot จริงจากเกม
 * — ปรับช่วงสีให้ตรงกับจอที่ใช้
 */
public class ColorCalibrator {
    private static final String TAG = "AetherCalibrator";

    // =====================================================
    //  ค่า HSV เริ่มต้น (ค่ากลางจาก Miniclip หลายอุปกรณ์)
    // =====================================================
    private static final float[][] DEFAULT_PROFILES = {
        // {hMin, hMax, sMin, sMax, vMin, vMax, ballNum}
        {35f, 55f, 0.70f, 1.0f, 0.80f, 1.0f, 1},       // Yellow
        {195f, 230f, 0.60f, 1.0f, 0.50f, 1.0f, 2},      // Blue
        {345f, 360f, 0.60f, 1.0f, 0.60f, 1.0f, 3},      // Red (wrap)
        {0f, 12f, 0.60f, 1.0f, 0.60f, 1.0f, 3},
        {265f, 305f, 0.50f, 1.0f, 0.45f, 1.0f, 4},      // Purple
        {12f, 32f, 0.70f, 1.0f, 0.75f, 1.0f, 5},        // Orange
        {130f, 160f, 0.55f, 1.0f, 0.45f, 1.0f, 6},      // Green
        {345f, 360f, 0.50f, 1.0f, 0.30f, 0.65f, 7},     // Maroon
        {0f, 12f, 0.50f, 1.0f, 0.30f, 0.65f, 7},
    };

    // ค่าที่ปรับแล้ว (จาก calibration)
    private float[][] calibratedProfiles;
    private boolean calibrated = false;

    // สถิติสีที่ตรวจพบ
    private Map<Integer, ColorStats> colorStats = new HashMap<>();

    public static class ColorStats {
        public int ballNum;
        public List<Float> hues = new ArrayList<>();
        public List<Float> sats = new ArrayList<>();
        public List<Float> vals = new ArrayList<>();

        public float hMin, hMax, sMin, sMax, vMin, vMax;
        public int sampleCount;

        public void addSample(float h, float s, float v) {
            hues.add(h);
            sats.add(s);
            vals.add(v);
            sampleCount++;
        }

        public void calculate() {
            if (sampleCount < 5) return;

            Collections.sort(hues);
            Collections.sort(sats);
            Collections.sort(vals);

            // ใช้ percentile 5-95 เพื่อกรอง outlier
            int p5 = (int) (sampleCount * 0.05f);
            int p95 = (int) (sampleCount * 0.95f);

            hMin = hues.get(p5) - 5f;
            hMax = hues.get(Math.min(p95, sampleCount - 1)) + 5f;
            sMin = sats.get(p5) - 0.05f;
            sMax = Math.min(1f, sats.get(Math.min(p95, sampleCount - 1)) + 0.05f);
            vMin = vals.get(p5) - 0.05f;
            vMax = Math.min(1f, vals.get(Math.min(p95, sampleCount - 1)) + 0.05f);
        }
    }

    /**
     * Calibrate จาก screenshot จริงของเกม
     * ต้องมีลูกทุกสีปรากฏในภาพ
     */
    public CalibrationResult calibrate(Bitmap screenshot, float tableLeft,
                                        float tableTop, float tableRight,
                                        float tableBottom) {
        Log.d(TAG, "Starting calibration...");

        colorStats.clear();
        for (int i = 1; i <= 7; i++) {
            colorStats.put(i, new ColorStats());
        }

        int w = screenshot.getWidth();
        int h = screenshot.getHeight();
        int startX = Math.max(0, (int) tableLeft);
        int startY = Math.max(0, (int) tableTop);
        int endX = Math.min(w, (int) tableRight);
        int endY = Math.min(h, (int) tableBottom);

        // สแกนทุก pixel ในพื้นที่โต๊ะ
        int totalPixels = 0;
        int matchedPixels = 0;

        for (int y = startY; y < endY; y += 3) {
            for (int x = startX; x < endX; x += 3) {
                totalPixels++;
                int pixel = screenshot.getPixel(x, y);
                float[] hsv = new float[3];
                Color.colorToHSV(pixel, hsv);

                float hue = hsv[0];
                float sat = hsv[1];
                float val = hsv[2];

                // กรองโต๊ะ + ขาว + ดำ
                if (isTableColor(hue, sat, val)) continue;
                if (sat < 0.20f && val > 0.85f) continue; // white
                if (val < 0.25f) continue; // black

                // จัดกลุ่มสี
                int ballNum = classifyColor(hue, sat, val);
                if (ballNum > 0) {
                    ColorStats stats = colorStats.get(ballNum);
                    if (stats != null) {
                        stats.addSample(hue, sat, val);
                        matchedPixels++;
                    }
                }
            }
        }

        // คำนวณค่าจากสถิติ
        CalibrationResult result = new CalibrationResult();
        calibratedProfiles = new float[DEFAULT_PROFILES.length][];

        for (int i = 0; i < DEFAULT_PROFILES.length; i++) {
            int ballNum = (int) DEFAULT_PROFILES[i][6];
            ColorStats stats = colorStats.get(ballNum);

            if (stats != null && stats.sampleCount >= 10) {
                stats.calculate();

                calibratedProfiles[i] = new float[]{
                    stats.hMin, stats.hMax,
                    Math.max(0, stats.sMin), Math.min(1, stats.sMax),
                    Math.max(0, stats.vMin), Math.min(1, stats.vMax),
                    ballNum
                };

                result.addResult(ballNum, stats.sampleCount,
                    stats.hMin, stats.hMax, stats.sMin, stats.sMax,
                    stats.vMin, stats.vMax);

                Log.d(TAG, String.format("Ball %d: H[%.0f-%.0f] S[%.2f-%.2f] V[%.2f-%.2f] (%d samples)",
                    ballNum, stats.hMin, stats.hMax, stats.sMin, stats.sMax,
                    stats.vMin, stats.vMax, stats.sampleCount));
            } else {
                // ใช้ค่า default
                calibratedProfiles[i] = DEFAULT_PROFILES[i].clone();
                result.addResult(ballNum, 0, 0, 0, 0, 0, 0, 0);
            }
        }

        calibrated = true;
        result.totalPixels = totalPixels;
        result.matchedPixels = matchedPixels;
        result.success = matchedPixels > totalPixels * 0.01f;

        Log.d(TAG, String.format("Calibration done: %d/%d pixels matched (%.1f%%)",
            matchedPixels, totalPixels, 100f * matchedPixels / totalPixels));

        return result;
    }

    /**
     * ดึงค่า profiles ที่ปรับแล้ว (หรือ default ถ้ายังไม่ calibrate)
     */
    public float[][] getProfiles() {
        return calibrated ? calibratedProfiles : DEFAULT_PROFILES;
    }

    public boolean isCalibrated() { return calibrated; }

    /**
     * รีเซ็ตเป็นค่า default
     */
    public void reset() {
        calibrated = false;
        calibratedProfiles = null;
        colorStats.clear();
    }

    /**
     * จัดกลุ่มสี (approximate)
     */
    private int classifyColor(float hue, float sat, float val) {
        // Yellow
        if (hue >= 35 && hue <= 55 && sat >= 0.50f && val >= 0.60f) return 1;
        // Blue
        if (hue >= 195 && hue <= 230 && sat >= 0.40f && val >= 0.35f) return 2;
        // Red
        if ((hue >= 345 || hue <= 12) && sat >= 0.40f && val >= 0.45f) return 3;
        // Purple
        if (hue >= 265 && hue <= 305 && sat >= 0.35f && val >= 0.30f) return 4;
        // Orange
        if (hue >= 12 && hue <= 32 && sat >= 0.50f && val >= 0.55f) return 5;
        // Green (ระวังโต๊ะ)
        if (hue >= 130 && hue <= 160 && sat >= 0.45f && val >= 0.35f) return 6;
        // Maroon
        if ((hue >= 345 || hue <= 12) && sat >= 0.35f && val >= 0.20f && val < 0.55f) return 7;

        return -1;
    }

    private boolean isTableColor(float hue, float sat, float val) {
        return hue >= 95 && hue <= 145 && sat >= 25f && sat <= 85f;
    }

    // =====================================================
    //  ผลลัพธ์ Calibration
    // =====================================================
    public static class CalibrationResult {
        public boolean success;
        public int totalPixels;
        public int matchedPixels;
        public List<BallResult> ballResults = new ArrayList<>();

        public static class BallResult {
            public int ballNum;
            public int samples;
            public float hMin, hMax, sMin, sMax, vMin, vMax;
        }

        public void addResult(int ballNum, int samples,
                               float hMin, float hMax, float sMin, float sMax,
                               float vMin, float vMax) {
            BallResult r = new BallResult();
            r.ballNum = ballNum;
            r.samples = samples;
            r.hMin = hMin; r.hMax = hMax;
            r.sMin = sMin; r.sMax = sMax;
            r.vMin = vMin; r.vMax = vMax;
            ballResults.add(r);
        }

        public String getReport() {
            StringBuilder sb = new StringBuilder();
            sb.append("=== Calibration Report ===\n");
            sb.append(String.format("Total pixels: %d\n", totalPixels));
            sb.append(String.format("Matched: %d (%.1f%%)\n", matchedPixels,
                100f * matchedPixels / Math.max(1, totalPixels)));
            sb.append(String.format("Status: %s\n\n", success ? "✅ SUCCESS" : "⚠️ LOW MATCH"));

            for (BallResult r : ballResults) {
                sb.append(String.format("Ball %2d: ", r.ballNum));
                if (r.samples > 0) {
                    sb.append(String.format("H[%3.0f-%3.0f] S[%.2f-%.2f] V[%.2f-%.2f] (%d samples)\n",
                        r.hMin, r.hMax, r.sMin, r.sMax, r.vMin, r.vMax, r.samples));
                } else {
                    sb.append("❌ No samples (using default)\n");
                }
            }
            return sb.toString();
        }
    }
}
