package com.aether.overlay;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import com.aether.brain.PhysicsEngine;
import com.aether.brain.StrategyEngine;
import com.aether.game.Ball;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.List;

/**
 * ESP Overlay — วาดเส้นนำทางแบบโปร
 * เหมือนในวิดีโอ: เส้นสี neon, multi-path, bank shot visualization
 */
public class AetherOverlay extends Service {
    private static final String TAG = "AetherOverlay";

    private WindowManager windowManager;
    private ESPView espView;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        espView = new ESPView(this);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(espView, params);
        Log.d(TAG, "ESP Overlay started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (espView != null) windowManager.removeView(espView);
    }

    // === Public API ===

    public void updateESP(ESPData data) {
        if (espView != null) espView.updateData(data);
    }

    /**
     * ข้อมูล ESP ทั้งหมด
     */
    public static class ESPData {
        // โต๊ะ
        public float tableX, tableY, tableW, tableH;

        // เส้นทางลูก cue (หลังชน)
        public List<Vec2> cueBallPath = new ArrayList<>();

        // เส้นทางลูกเป้าหมาย (เข้าหลุม)
        public List<Vec2> targetBallPath = new ArrayList<>();

        // เส้นทาง bank shot (ชิ่งขอบ)
        public List<List<Vec2>> bankPaths = new ArrayList<>();

        // จุดกระทบ
        public Vec2 impactPoint;

        // จุดลงหลุม
        public Vec2 pocketTarget;

        // ข้อมูล shot
        public float power;
        public float angle;
        public String shotType;  // "STRAIGHT", "BANK", "KICK", "COMBO"
        public int targetBallNum;

        // Multi-ball prediction (สำหรับ combo/chain shots)
        public List<BallPath> allBallPaths = new ArrayList<>();

        // ข้อมูล spin
        public float sideSpin;
        public float topSpin;
    }

    /**
     * เส้นทางของแต่ละลูก
     */
    public static class BallPath {
        public int ballNumber;
        public int color;
        public List<Vec2> path;
        public Vec2 finalPos;      // ตำแหน่งสุดท้าย
        public boolean pocketed;   // ลงหลุมไหม
        public int pocketIndex;    // หลุมไหน

        public BallPath(int num, int col, List<Vec2> path) {
            this.ballNumber = num;
            this.color = col;
            this.path = path;
        }
    }

    // =====================================================
    //  ESP View — วาด overlay ทั้งหมด
    // =====================================================
    private static class ESPView extends View {
        // === ESP Colors (Neon style เหมือนในวิดีโอ) ===
        private static final int COL_CUE_PATH     = Color.argb(200, 255, 255, 255);  // ขาว
        private static final int COL_TARGET_PATH   = Color.argb(200, 255, 50, 50);    // แดง
        private static final int COL_IMPACT        = Color.argb(220, 255, 255, 0);    // เหลือง
        private static final int COL_POCKET        = Color.argb(200, 0, 255, 100);    // เขียว
        private static final int COL_GHOST_BALL    = Color.argb(120, 255, 255, 255);  // ขาวโปร่งใส
        private static final int COL_AIM_LINE      = Color.argb(180, 0, 200, 255);    // ฟ้า

        // สีสำหรับลูกแต่ละหมายเลข (ตามลำดับ)
        private static final int[] BALL_TRAIL_COLORS = {
            Color.argb(180, 255, 255, 255),  // 0: Cue (ขาว)
            Color.argb(180, 255, 215, 0),    // 1: Yellow
            Color.argb(180, 0, 100, 255),    // 2: Blue
            Color.argb(180, 255, 30, 30),    // 3: Red
            Color.argb(180, 180, 0, 255),    // 4: Purple
            Color.argb(180, 255, 140, 0),    // 5: Orange
            Color.argb(180, 0, 200, 0),      // 6: Green
            Color.argb(180, 180, 30, 30),    // 7: Maroon
            Color.argb(180, 50, 50, 50),     // 8: Black
            Color.argb(180, 255, 215, 0),    // 9: Yellow Stripe
            Color.argb(180, 0, 100, 255),    // 10: Blue Stripe
            Color.argb(180, 255, 30, 30),    // 11: Red Stripe
            Color.argb(180, 180, 0, 255),    // 12: Purple Stripe
            Color.argb(180, 255, 140, 0),    // 13: Orange Stripe
            Color.argb(180, 0, 200, 0),      // 14: Green Stripe
            Color.argb(180, 180, 30, 30),    // 15: Maroon Stripe
        };

        // === Paints ===
        private Paint cuePathPaint;         // เส้นทางลูก cue
        private Paint targetPathPaint;      // เส้นทางลูกเป้าหมาย
        private Paint aimLinePaint;         // เส้นเล็ง
        private Paint impactPaint;          // จุดกระทบ
        private Paint pocketPaint;          // จุดหลุม
        private Paint ghostBallPaint;       // ลูก ghost (จุดที่จะกระทบ)
        private Paint textPaint;            // ข้อความ
        private Paint textBgPaint;          // พื้นหลังข้อความ
        private Paint dashPaint;            // เส้นประ
        private Paint dotPaint;             // จุด

        private ESPData data;
        private long animTime = 0;

        public ESPView(Context context) {
            super(context);
            setWillNotDraw(false);
            initPaints();
            startAnimation();
        }

        private void initPaints() {
            // เส้นทางลูก cue (ขาว, เส้นทึบ)
            cuePathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            cuePathPaint.setColor(COL_CUE_PATH);
            cuePathPaint.setStrokeWidth(2.5f);
            cuePathPaint.setStyle(Paint.Style.STROKE);
            cuePathPaint.setStrokeCap(Paint.Cap.ROUND);

            // เส้นทางลูกเป้าหมาย (สีลูก, เส้นทึบ)
            targetPathPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            targetPathPaint.setColor(COL_TARGET_PATH);
            targetPathPaint.setStrokeWidth(3f);
            targetPathPaint.setStyle(Paint.Style.STROKE);
            targetPathPaint.setStrokeCap(Paint.Cap.ROUND);

            // เส้นเล็ง (ฟ้า, เส้นทึบ)
            aimLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            aimLinePaint.setColor(COL_AIM_LINE);
            aimLinePaint.setStrokeWidth(2f);
            aimLinePaint.setStyle(Paint.Style.STROKE);

            // จุดกระทบ
            impactPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            impactPaint.setColor(COL_IMPACT);
            impactPaint.setStyle(Paint.Style.STROKE);
            impactPaint.setStrokeWidth(2f);

            // จุดหลุม
            pocketPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            pocketPaint.setColor(COL_POCKET);
            pocketPaint.setStyle(Paint.Style.STROKE);
            pocketPaint.setStrokeWidth(2f);

            // Ghost ball
            ghostBallPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            ghostBallPaint.setColor(COL_GHOST_BALL);
            ghostBallPaint.setStyle(Paint.Style.STROKE);
            ghostBallPaint.setStrokeWidth(1.5f);

            // ข้อความ
            textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(22f);
            textPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK);

            // พื้นหลังข้อความ
            textBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textBgPaint.setColor(Color.argb(160, 0, 0, 0));
            textBgPaint.setStyle(Paint.Style.FILL);

            // เส้นประ
            dashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            dashPaint.setColor(Color.argb(100, 255, 255, 255));
            dashPaint.setStrokeWidth(1f);
            dashPaint.setStyle(Paint.Style.STROKE);
            dashPaint.setPathEffect(new DashPathEffect(new float[]{8, 8}, 0));

            // จุด
            dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            dotPaint.setStyle(Paint.Style.FILL);
        }

        public void updateData(ESPData data) {
            this.data = data;
            postInvalidate();
        }

        private void startAnimation() {
            // Animation loop สำหรับเอฟเฟกต์
            post(new Runnable() {
                @Override
                public void run() {
                    animTime = System.currentTimeMillis();
                    invalidate();
                    postDelayed(this, 33); // ~30fps
                }
            });
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (canvas == null || data == null) return;

            // === 1. วาดเส้นเล็ง (Aim Line) ===
            drawAimLine(canvas);

            // === 2. วาดเส้นทางลูกเป้าหมาย ===
            drawTargetBallPath(canvas);

            // === 3. วาดเส้นทางลูก cue (หลังชน) ===
            drawCueBallPath(canvas);

            // === 4. วาดเส้นทาง bank shot ===
            drawBankPaths(canvas);

            // === 5. วาดจุดกระทบ (Impact Point) ===
            drawImpactPoint(canvas);

            // === 6. วาดจุดหลุมเป้าหมาย ===
            drawPocketTarget(canvas);

            // === 7. วาด Ghost Ball ===
            drawGhostBall(canvas);

            // === 8. วาด Multi-ball paths (combo) ===
            drawAllBallPaths(canvas);

            // === 9. วาดข้อมูล Shot ===
            drawShotInfo(canvas);
        }

        // =====================================================
        //  1. เส้นเล็ง (Aim Line) — จากลูก cue ไปจุดกระทบ
        // =====================================================
        private void drawAimLine(Canvas canvas) {
            if (data.impactPoint == null || data.cueBallPath.isEmpty()) return;

            Vec2 from = toScreen(data.cueBallPath.get(0));
            Vec2 to = toScreen(data.impactPoint);

            // เส้นทึบ (ฟ้า)
            canvas.drawLine(from.x, from.y, to.x, to.y, aimLinePaint);

            // เส้นประต่อจากจุดกระทบ (แสดงทิศทางต่อ)
            Vec2 dir = to.sub(from).normalized();
            Vec2 extended = to.add(dir.mul(50));
            canvas.drawLine(to.x, to.y, extended.x, extended.y, dashPaint);
        }

        // =====================================================
        //  2. เส้นทางลูกเป้าหมาย — แดง/สีลูก, เส้นทึบ
        // =====================================================
        private void drawTargetBallPath(Canvas canvas) {
            if (data.targetBallPath.size() < 2) return;

            int color = COL_TARGET_PATH;
            if (data.targetBallNum >= 0 && data.targetBallNum < BALL_TRAIL_COLORS.length) {
                color = BALL_TRAIL_COLORS[data.targetBallNum];
            }

            Paint paint = new Paint(targetPathPaint);
            paint.setColor(color);

            drawPathWithFade(canvas, data.targetBallPath, paint, 0.6f);

            // จุดทุกๆ ระยะ (ลูกศร)
            for (int i = 0; i < data.targetBallPath.size(); i += 8) {
                Vec2 p = toScreen(data.targetBallPath.get(i));
                float alpha = 1f - (float) i / data.targetBallPath.size();
                dotPaint.setColor(Color.argb((int)(alpha * 200),
                    Color.red(color), Color.green(color), Color.blue(color)));
                canvas.drawCircle(p.x, p.y, 4f, dotPaint);
            }
        }

        // =====================================================
        //  3. เส้นทางลูก cue — ขาว, เส้นทึบ
        // =====================================================
        private void drawCueBallPath(Canvas canvas) {
            if (data.cueBallPath.size() < 2) return;
            drawPathWithFade(canvas, data.cueBallPath, cuePathPaint, 0.5f);
        }

        // =====================================================
        //  4. เส้นทาง Bank Shot — เส้นประ, สีต่างกัน
        // =====================================================
        private void drawBankPaths(Canvas canvas) {
            for (int i = 0; i < data.bankPaths.size(); i++) {
                List<Vec2> bankPath = data.bankPaths.get(i);
                if (bankPath.size() < 2) continue;

                // สีต่างกันตามจำนวน bounce
                int[] bankColors = {
                    Color.argb(150, 255, 100, 100),  // bounce 1: แดงอ่อน
                    Color.argb(150, 100, 255, 100),  // bounce 2: เขียว
                    Color.argb(150, 100, 100, 255),  // bounce 3: น้ำเงิน
                    Color.argb(150, 255, 255, 100),  // bounce 4: เหลือง
                };

                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setColor(bankColors[i % bankColors.length]);
                paint.setStrokeWidth(2f);
                paint.setStyle(Paint.Style.STROKE);
                paint.setPathEffect(new DashPathEffect(new float[]{10, 6}, 0));

                drawPathWithFade(canvas, bankPath, paint, 0.4f);

                // จุด bounce
                for (int j = 1; j < bankPath.size() - 1; j++) {
                    Vec2 p = toScreen(bankPath.get(j));
                    Paint bouncePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bouncePaint.setColor(Color.argb(200, 255, 255, 0));
                    bouncePaint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(p.x, p.y, 6f, bouncePaint);

                    // วงแหวน
                    bouncePaint.setStyle(Paint.Style.STROKE);
                    bouncePaint.setStrokeWidth(1.5f);
                    canvas.drawCircle(p.x, p.y, 10f, bouncePaint);
                }
            }
        }

        // =====================================================
        //  5. จุดกระทบ (Impact Point)
        // =====================================================
        private void drawImpactPoint(Canvas canvas) {
            if (data.impactPoint == null) return;
            Vec2 p = toScreen(data.impactPoint);

            // วงกลม + กากบาท
            canvas.drawCircle(p.x, p.y, 12f, impactPaint);
            canvas.drawCircle(p.x, p.y, 20f, impactPaint);

            // กากบาท
            float s = 8f;
            canvas.drawLine(p.x - s, p.y - s, p.x + s, p.y + s, impactPaint);
            canvas.drawLine(p.x + s, p.y - s, p.x - s, p.y + s, impactPaint);
        }

        // =====================================================
        //  6. จุดหลุมเป้าหมาย
        // =====================================================
        private void drawPocketTarget(Canvas canvas) {
            if (data.pocketTarget == null) return;
            Vec2 p = toScreen(data.pocketTarget);

            // วงกลมเป้าหมาย (3 ชั้น)
            float[] radii = {25f, 18f, 10f};
            float pulse = (float) Math.sin(animTime * 0.005) * 3f;

            for (float r : radii) {
                canvas.drawCircle(p.x, p.y, r + pulse, pocketPaint);
            }

            // กากบาท
            float s = 15f;
            canvas.drawLine(p.x - s, p.y, p.x + s, p.y, pocketPaint);
            canvas.drawLine(p.x, p.y - s, p.x, p.y + s, pocketPaint);

            // ข้อความ "POCKET"
            textPaint.setTextSize(16f);
            canvas.drawText("POCKET", p.x + 20, p.y - 10, textPaint);
        }

        // =====================================================
        //  7. Ghost Ball — ลูกใสที่ตำแหน่งกระทบ
        // =====================================================
        private void drawGhostBall(Canvas canvas) {
            if (data.impactPoint == null) return;
            Vec2 p = toScreen(data.impactPoint);

            float r = 20f; // radius (normalized → pixel ประมาณ)
            canvas.drawCircle(p.x, p.y, r, ghostBallPaint);

            // เส้นผ่านศูนย์กลาง (แสดงทิศทาง)
            Vec2 dir = data.targetBallPath.size() > 1 ?
                data.targetBallPath.get(1).sub(data.targetBallPath.get(0)).normalized() :
                new Vec2(1, 0);
            canvas.drawLine(p.x - dir.x * r, p.y - dir.y * r,
                p.x + dir.x * r, p.y + dir.y * r, ghostBallPaint);
        }

        // =====================================================
        //  8. Multi-ball paths (Combo/Chain shots)
        // =====================================================
        private void drawAllBallPaths(Canvas canvas) {
            for (BallPath bp : data.allBallPaths) {
                if (bp.path == null || bp.path.size() < 2) continue;

                int color = bp.color;
                if (bp.ballNumber < BALL_TRAIL_COLORS.length) {
                    color = BALL_TRAIL_COLORS[bp.ballNumber];
                }

                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setColor(color);
                paint.setStrokeWidth(2f);
                paint.setStyle(Paint.Style.STROKE);

                drawPathWithFade(canvas, bp.path, paint, 0.5f);

                // จุดสุดท้าย
                if (bp.pocketed && bp.finalPos != null) {
                    Vec2 end = toScreen(bp.finalPos);
                    Paint endPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    endPaint.setColor(color);
                    endPaint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(end.x, end.y, 8f, endPaint);
                }
            }
        }

        // =====================================================
        //  9. ข้อมูล Shot (มุม, แรง, ประเภท)
        // =====================================================
        private void drawShotInfo(Canvas canvas) {
            if (data.shotType == null) return;

            float x = 30f, y = getHeight() - 180f;
            float lineH = 28f;

            // พื้นหลัง
            canvas.drawRoundRect(new RectF(x - 10, y - 25, x + 250, y + lineH * 4 + 10),
                12, 12, textBgPaint);

            textPaint.setTextSize(20f);
            textPaint.setTextAlign(Paint.Align.LEFT);

            // ประเภท shot
            int shotColor;
            switch (data.shotType) {
                case "BANK":  shotColor = Color.rgb(255, 180, 0); break;
                case "KICK":  shotColor = Color.rgb(255, 100, 100); break;
                case "COMBO": shotColor = Color.rgb(180, 100, 255); break;
                default:      shotColor = Color.rgb(100, 255, 100); break;
            }
            textPaint.setColor(shotColor);
            canvas.drawText("🎯 " + data.shotType, x, y, textPaint);

            // มุม
            textPaint.setColor(Color.WHITE);
            canvas.drawText(String.format("📐 มุม: %.1f°", Math.toDegrees(data.angle)),
                x, y + lineH, textPaint);

            // แรง
            float powerPct = data.power * 100;
            int powerColor = powerPct < 30 ? Color.GREEN :
                powerPct < 70 ? Color.YELLOW : Color.RED;
            textPaint.setColor(powerColor);
            canvas.drawText(String.format("💪 แรง: %.0f%%", powerPct),
                x, y + lineH * 2, textPaint);

            // Spin
            if (Math.abs(data.sideSpin) > 0.01f || Math.abs(data.topSpin) > 0.01f) {
                textPaint.setColor(Color.rgb(0, 200, 255));
                String spinText = "🔄 ";
                if (data.sideSpin > 0.01f) spinText += "English ขวา ";
                else if (data.sideSpin < -0.01f) spinText += "English ซ้าย ";
                if (data.topSpin > 0.01f) spinText += "Top Spin";
                else if (data.topSpin < -0.01f) spinText += "Draw";
                canvas.drawText(spinText, x, y + lineH * 3, textPaint);
            }
        }

        // =====================================================
        //  Helper: วาดเส้นทางแบบ fade out
        // =====================================================
        private void drawPathWithFade(Canvas canvas, List<Vec2> path, Paint basePaint, float fadeStart) {
            if (path.size() < 2) return;

            int totalAlpha = basePaint.getAlpha();

            for (int i = 1; i < path.size(); i++) {
                Vec2 from = toScreen(path.get(i - 1));
                Vec2 to = toScreen(path.get(i));

                // Fade out ตามระยะ
                float progress = (float) i / path.size();
                float alpha = progress < fadeStart ? 1f :
                    1f - (progress - fadeStart) / (1f - fadeStart);
                alpha = Math.max(0.1f, alpha);

                Paint paint = new Paint(basePaint);
                paint.setAlpha((int) (totalAlpha * alpha));

                canvas.drawLine(from.x, from.y, to.x, to.y, paint);
            }
        }

        /**
         * แปลง normalized coordinate เป็น screen pixel
         */
        private Vec2 toScreen(Vec2 norm) {
            if (data == null) return norm;
            return new Vec2(
                norm.x * data.tableW + data.tableX,
                norm.y * data.tableH + data.tableY
            );
        }
    }
}
