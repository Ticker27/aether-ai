package com.aether.game;

import android.graphics.Color;

/**
 * ข้อมูลลูกบิลเลียด — สีจาก Miniclip 8 Ball Pool เกมจริง
 */
public class Ball {
    public int number;          // 0=cue, 1-7=solid, 8=eight, 9-15=stripe
    public Vec2 pos;            // ตำแหน่งบนโต๊ะ (normalized 0-1)
    public Vec2 vel;            // ความเร็ว
    public float radius;        // รัศมี (normalized)
    public int color;           // สี (Android Color)
    public boolean pocketed;
    public boolean visible;

    public Ball(int number, Vec2 pos, int color) {
        this.number = number;
        this.pos = pos;
        this.color = color;
        this.vel = new Vec2();
        this.radius = 0.025f;
        this.visible = true;
    }

    public boolean isCue()    { return number == 0; }
    public boolean isEight()  { return number == 8; }
    public boolean isSolid()  { return number >= 1 && number <= 7; }
    public boolean isStripe() { return number >= 9 && number <= 15; }
    public boolean isMoving() { return vel.length() > 0.001f; }

    /**
     * สีจริงจาก Miniclip 8 Ball Pool
     * (ปรับจากเกมจริงบน Android)
     */
    public static int getBallColor(int number) {
        switch (number) {
            case 0:  return Color.rgb(255, 255, 255);   // White (Cue)
            case 1:  return Color.rgb(255, 205, 0);     // Yellow
            case 2:  return Color.rgb(0, 70, 195);      // Blue
            case 3:  return Color.rgb(220, 30, 30);     // Red
            case 4:  return Color.rgb(130, 0, 190);     // Purple
            case 5:  return Color.rgb(255, 130, 0);     // Orange
            case 6:  return Color.rgb(0, 150, 50);      // Green
            case 7:  return Color.rgb(140, 20, 20);     // Maroon
            case 8:  return Color.rgb(20, 20, 20);      // Black
            case 9:  return Color.rgb(255, 205, 0);     // Yellow Stripe
            case 10: return Color.rgb(0, 70, 195);      // Blue Stripe
            case 11: return Color.rgb(220, 30, 30);     // Red Stripe
            case 12: return Color.rgb(130, 0, 190);     // Purple Stripe
            case 13: return Color.rgb(255, 130, 0);     // Orange Stripe
            case 14: return Color.rgb(0, 150, 50);      // Green Stripe
            case 15: return Color.rgb(140, 20, 20);     // Maroon Stripe
            default: return Color.GRAY;
        }
    }

    /**
     * ชื่อสี (สำหรับ debug/UI)
     */
    public static String getColorName(int number) {
        switch (number) {
            case 0:  return "White (Cue)";
            case 1:  return "Yellow";
            case 2:  return "Blue";
            case 3:  return "Red";
            case 4:  return "Purple";
            case 5:  return "Orange";
            case 6:  return "Green";
            case 7:  return "Maroon";
            case 8:  return "Black (8-Ball)";
            case 9:  return "Yellow Stripe";
            case 10: return "Blue Stripe";
            case 11: return "Red Stripe";
            case 12: return "Purple Stripe";
            case 13: return "Orange Stripe";
            case 14: return "Green Stripe";
            case 15: return "Maroon Stripe";
            default: return "Unknown";
        }
    }

    /**
     * ชื่อย่อ (สำหรับ ESP overlay)
     */
    public static String getShortName(int number) {
        if (number == 0) return "CUE";
        if (number == 8) return "8";
        if (number <= 7) return "S" + number;  // Solid
        return "T" + (number - 8);              // Stripe (T=thin stripe)
    }
}
