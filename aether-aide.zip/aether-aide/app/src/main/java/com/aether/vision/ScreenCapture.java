package com.aether.vision;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

/**
 * จับภาพหน้าจอแบบเรียลไทม์ผ่าน MediaProjection API
 * — ไม่แตะหน่วยความจำเกม ไม่ inject อะไร
 */
public class ScreenCapture {
    private static final String TAG = "AetherCapture";
    private static final int FPS = 15;  // จับภาพ 15 fps (ประหยัด CPU)

    private Context context;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private int screenWidth, screenHeight, screenDpi;
    private HandlerThread captureThread;
    private Handler captureHandler;

    private volatile boolean running = false;
    private long lastFrameTime = 0;
    private long frameIntervalMs = 1000 / FPS;

    // Callback
    public interface FrameCallback {
        void onFrame(Bitmap frame, long timestamp);
    }
    private FrameCallback callback;

    public ScreenCapture(Context context, MediaProjection projection) {
        this.context = context;
        this.mediaProjection = projection;

        // วัดขนาดจอ
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;
        screenDpi = dm.densityDpi;

        // ลดความละเอียดลง 50% เพื่อประหยัด CPU
        screenWidth /= 2;
        screenHeight /= 2;
    }

    public void setFrameCallback(FrameCallback cb) {
        this.callback = cb;
    }

    /**
     * เริ่มจับภาพ
     */
    public void start() {
        if (running) return;
        running = true;

        captureThread = new HandlerThread("AetherCaptureThread");
        captureThread.start();
        captureHandler = new Handler(captureThread.getLooper());

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight,
            PixelFormat.RGBA_8888,
            2  // max images
        );

        imageReader.setOnImageAvailableListener(reader -> {
            if (!running) return;

            // Rate limiting
            long now = System.currentTimeMillis();
            if (now - lastFrameTime < frameIntervalMs) {
                Image img = reader.acquireLatestImage();
                if (img != null) img.close();
                return;
            }
            lastFrameTime = now;

            Image image = reader.acquireLatestImage();
            if (image == null) return;

            try {
                Bitmap bitmap = imageToBitmap(image);
                if (callback != null) {
                    callback.onFrame(bitmap, now);
                }
                bitmap.recycle();
            } catch (Exception e) {
                Log.e(TAG, "Frame processing error", e);
            } finally {
                image.close();
            }
        }, captureHandler);

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "AetherScreen",
            screenWidth, screenHeight, screenDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.getSurface(),
            null, captureHandler
        );

        Log.d(TAG, "Screen capture started: " + screenWidth + "x" + screenHeight);
    }

    /**
     * หยุดจับภาพ
     */
    public void stop() {
        running = false;
        if (virtualDisplay != null) {
            virtualDisplay.release();
            virtualDisplay = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
        if (captureThread != null) {
            captureThread.quitSafely();
            captureThread = null;
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
        }
        Log.d(TAG, "Screen capture stopped");
    }

    public boolean isRunning() { return running; }
    public int getWidth()  { return screenWidth; }
    public int getHeight() { return screenHeight; }

    /**
     * แปลง Image เป็น Bitmap
     */
    private Bitmap imageToBitmap(Image image) {
        int w = image.getWidth(), h = image.getHeight();
        Image.Plane plane = image.getPlanes()[0];
        int stride = plane.getRowStride();
        int pixelStride = plane.getPixelStride();
        int rowPadding = stride - pixelStride * w;

        Bitmap bitmap = Bitmap.createBitmap(
            w + rowPadding / pixelStride, h,
            Bitmap.Config.ARGB_8888
        );
        bitmap.copyPixelsFromBuffer(plane.getBuffer());

        // Crop padding
        if (rowPadding > 0) {
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, w, h);
            bitmap.recycle();
            return cropped;
        }
        return bitmap;
    }
}
