package com.aether.brain;

import com.aether.game.Ball;
import com.aether.game.GameState;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.List;

/**
 * เอนจิ้นกลยุทธ์ — เลือกลูกที่ดีที่สุด + เลือกหลุม
 * รองรับ: ยิงตรง, ชิ่ง 1-4 ขอบ, combo, ตั้งรับ
 * คิดแบบมนุษย์: ง่าย → ยาก, ปลอดภัย → เสี่ยง
 */
public class StrategyEngine {

    /**
     * ผลลัพธ์การวิเคราะห์ shot
     */
    public static class ShotOption {
        public Ball targetBall;
        public Vec2 aimDir;
        public Vec2 pocketTarget;
        public float power;
        public float score;
        public float angle;
        public String reason;
        public String shotType;         // STRAIGHT, BANK, KICK, COMBO
        public boolean isBankShot;
        public int bankCount;
        public float sideSpin;
        public float topSpin;

        // ESP data
        public PhysicsEngine.FullSimResult simResult;
        public List<PhysicsEngine.BankShotResult> bankResults;
    }

    /**
     * หา shot ที่ดีที่สุด — วิเคราะห์ทุก possibility
     */
    public static ShotOption findBestShot(GameState state) {
        if (state.cueBall == null) return null;

        List<Ball> myBalls = state.getMyBalls();
        if (myBalls.isEmpty() && state.isAllMyBallsPocketed()) {
            for (Ball b : state.getActiveBalls()) {
                if (b.isEight()) { myBalls.add(b); break; }
            }
        }
        if (myBalls.isEmpty()) return null;

        List<ShotOption> allShots = new ArrayList<>();

        // === 1. Shot ตรง (ไม่ชิ่ง) ===
        for (Ball target : myBalls) {
            for (int p = 0; p < PhysicsEngine.POCKETS.length; p++) {
                ShotOption shot = analyzeStraightShot(state.cueBall, target,
                    PhysicsEngine.POCKETS[p], state.getActiveBalls());
                if (shot != null) allShots.add(shot);
            }
        }

        // === 2. Bank Shot (ชิ่ง 1 ขอบ) ===
        for (Ball target : myBalls) {
            for (int p = 0; p < PhysicsEngine.POCKETS.length; p++) {
                List<PhysicsEngine.BankShotResult> banks =
                    PhysicsEngine.findBankShots(state.cueBall.pos, target.pos,
                        PhysicsEngine.POCKETS[p], state.getActiveBalls());

                for (PhysicsEngine.BankShotResult bank : banks) {
                    ShotOption shot = new ShotOption();
                    shot.targetBall = target;
                    shot.aimDir = bank.path.size() > 1 ?
                        bank.path.get(1).sub(bank.path.get(0)).normalized() :
                        bank.bankPoint.sub(state.cueBall.pos).normalized();
                    shot.pocketTarget = PhysicsEngine.POCKETS[p];
                    shot.isBankShot = true;
                    shot.bankCount = 1;
                    shot.shotType = "BANK";
                    shot.score = bank.score;
                    shot.angle = (float) Math.atan2(shot.aimDir.y, shot.aimDir.x);
                    shot.power = calculatePower(state.cueBall.pos.distTo(target.pos), 0.3f);
                    shot.bankResults = banks;

                    // Simulate for ESP
                    shot.simResult = PhysicsEngine.simulateFull(
                        state.cueBall.pos, shot.aimDir, shot.power,
                        state.getActiveBalls(), true, shot.sideSpin, shot.topSpin);

                    recommendSpin(shot, state.cueBall, target, PhysicsEngine.POCKETS[p]);
                    allShots.add(shot);
                }
            }
        }

        // === 3. Multi-cushion bank shots (2-4 ขอบ เหมือนในวิดีโอ) ===
        for (Ball target : myBalls) {
            for (int p = 0; p < PhysicsEngine.POCKETS.length; p++) {
                List<List<Vec2>> multiPaths = PhysicsEngine.findMultiCushionShots(
                    state.cueBall.pos, target.pos, PhysicsEngine.POCKETS[p],
                    state.getActiveBalls(), 4);

                for (List<Vec2> path : multiPaths) {
                    if (path.size() < 2) continue;

                    ShotOption shot = new ShotOption();
                    shot.targetBall = target;
                    shot.aimDir = path.get(0).sub(state.cueBall.pos).normalized();
                    shot.pocketTarget = PhysicsEngine.POCKETS[p];
                    shot.isBankShot = true;
                    shot.bankCount = path.size() - 1;
                    shot.shotType = shot.bankCount > 2 ? "COMBO" : "BANK";
                    shot.score = 60 - shot.bankCount * 8;
                    shot.angle = (float) Math.atan2(shot.aimDir.y, shot.aimDir.x);
                    shot.power = calculatePower(state.cueBall.pos.distTo(target.pos), 0.5f);

                    shot.simResult = PhysicsEngine.simulateFull(
                        state.cueBall.pos, shot.aimDir, shot.power,
                        state.getActiveBalls(), true, shot.sideSpin, shot.topSpin);

                    allShots.add(shot);
                }
            }
        }

        if (allShots.isEmpty()) return defensiveShot(state);

        // เรียงตามคะแนน
        allShots.sort((a, b) -> Float.compare(b.score, a.score));

        ShotOption best = allShots.get(0);
        best.reason = generateReason(best);
        return best;
    }

    // === Shot ตรง ===
    private static ShotOption analyzeStraightShot(Ball cue, Ball target, Vec2 pocket,
                                                    List<Ball> allBalls) {
        Vec2 targetToPocket = pocket.sub(target.pos).normalized();
        Vec2 contactPoint = target.pos.sub(targetToPocket.mul(Ball.getBallColor(0) == 0 ?
            PhysicsEngine.BALL_RADIUS * 2 : PhysicsEngine.BALL_RADIUS * 2));
        Vec2 aimDir = contactPoint.sub(cue.pos).normalized();

        float angle = (float) Math.atan2(aimDir.y, aimDir.x);
        float targetAngle = (float) Math.atan2(targetToPocket.y, targetToPocket.x);
        float cutAngle = Math.abs(angle - targetAngle);
        if (cutAngle > 1.4f) return null;

        PhysicsEngine.FullSimResult sim = PhysicsEngine.simulateFull(
            cue.pos, aimDir, 0.5f, allBalls, false, 0, 0);

        // ตรวจว่าลูกเป้าหมายลงหลุม
        boolean targetPocketed = false;
        for (PhysicsEngine.BallPathResult bpr : sim.ballPaths) {
            if (bpr.ballNumber == target.number && bpr.pocketed) {
                targetPocketed = true;
                break;
            }
        }
        if (!targetPocketed) return null;
        if (sim.cuePocketed) return null;

        float score = 100;
        score -= cutAngle * 30;
        score -= cue.pos.distTo(target.pos) * 20;

        float cueDistCenter = sim.cuePath.get(sim.cuePath.size() - 1).distTo(new Vec2(0.5f, 0.5f));
        score += (1 - cueDistCenter) * 10;

        int blockers = countBlockers(cue.pos, contactPoint, allBalls);
        score -= blockers * 15;

        ShotOption shot = new ShotOption();
        shot.targetBall = target;
        shot.aimDir = aimDir;
        shot.pocketTarget = pocket;
        shot.power = calculatePower(cue.pos.distTo(target.pos), cutAngle);
        shot.score = score;
        shot.angle = angle;
        shot.isBankShot = false;
        shot.shotType = "STRAIGHT";
        shot.simResult = sim;

        recommendSpin(shot, cue, target, pocket);
        return shot;
    }

    // === ตั้งรับ ===
    private static ShotOption defensiveShot(GameState state) {
        if (state.cueBall == null) return null;
        ShotOption shot = new ShotOption();
        shot.targetBall = null;
        shot.power = 0.3f;
        shot.score = 20;
        shot.reason = "ตั้งรับ — ไม่มี shot ที่ดี";
        shot.shotType = "DEFENSIVE";
        shot.aimDir = new Vec2(0.5f, 0.5f).sub(state.cueBall.pos).normalized();
        return shot;
    }

    // === แนะนำ spin ===
    private static void recommendSpin(ShotOption shot, Ball cue, Ball target, Vec2 pocket) {
        Vec2 cueToTarget = target.pos.sub(cue.pos).normalized();
        Vec2 targetToPocket = pocket.sub(target.pos).normalized();
        float cross = cueToTarget.cross(targetToPocket);

        if (cross > 0.1f) shot.sideSpin = 0.3f;
        else if (cross < -0.1f) shot.sideSpin = -0.3f;

        float dist = cue.pos.distTo(target.pos);
        if (dist > 0.4f) shot.topSpin = 0.5f;
        else shot.topSpin = -0.3f;
    }

    // === Helper ===
    private static int countBlockers(Vec2 from, Vec2 to, List<Ball> balls) {
        int count = 0;
        Vec2 dir = to.sub(from).normalized();
        float dist = from.distTo(to);
        for (Ball b : balls) {
            if (b.isCue() || b.pocketed) continue;
            Vec2 toBall = b.pos.sub(from);
            float proj = toBall.dot(dir);
            if (proj < 0 || proj > dist) continue;
            float perpDist = toBall.sub(dir.mul(proj)).length();
            if (perpDist < PhysicsEngine.BALL_RADIUS * 3) count++;
        }
        return count;
    }

    private static float calculatePower(float dist, float cutAngle) {
        return Math.min(1f, 0.3f + dist * 0.8f + cutAngle * 0.2f);
    }

    private static String generateReason(ShotOption shot) {
        StringBuilder sb = new StringBuilder();
        if (shot.isBankShot) {
            sb.append("ชิ่ง").append(shot.bankCount).append("ขอบ");
        } else {
            sb.append("ยิงตรง");
        }
        sb.append(" → ลูก").append(shot.targetBall.number);

        if (Math.abs(shot.sideSpin) > 0.01f) {
            sb.append(shot.sideSpin > 0 ? " +EN ขวา" : " +EN ซ้าย");
        }
        if (Math.abs(shot.topSpin) > 0.01f) {
            sb.append(shot.topSpin > 0 ? " +Top" : " +Draw");
        }
        return sb.toString();
    }
}
