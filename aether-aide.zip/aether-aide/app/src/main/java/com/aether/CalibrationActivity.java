package com.aether;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.LinearLayout;

import com.aether.vision.BallDetector;
import com.aether.vision.ColorCalibrator;
import com.aether.vision.DetectionTester;

/**
 * Calibration & Debug Activity
 */
public class CalibrationActivity extends Activity {
    private static final String TAG = "AetherCalibration";

    private TextView tvReport;
    private ScrollView scrollView;
    private Button btnTest, btnCalibrate, btnDebug;
    private BallDetector detector;
    private ColorCalibrator calibrator;
    private Handler mainHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // สร้าง UI แบบง่าย
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(getResources().getColor(R.color.bg_dark));
        layout.setPadding(24, 24, 24, 24);

        // Header
        TextView header = new TextView(this);
        header.setText("🔧 AETHER CALIBRATION");
        header.setTextSize(24f);
        header.setTextColor(getResources().getColor(R.color.colorAccent));
        header.setPadding(0, 32, 0, 16);
        layout.addView(header);

        // Buttons
        LinearLayout btnLayout = new LinearLayout(this);
        btnLayout.setOrientation(LinearLayout.HORIZONTAL);
        btnLayout.setPadding(0, 8, 0, 8);

        btnTest = createButton("🧪 Test");
        btnCalibrate = createButton("🔧 Calibrate");
        btnDebug = createButton("📊 Debug");

        btnLayout.addView(btnTest);
        btnLayout.addView(btnCalibrate);
        btnLayout.addView(btnDebug);
        layout.addView(btnLayout);

        // Report
        scrollView = new ScrollView(this);
        tvReport = new TextView(this);
        tvReport.setPadding(0, 16, 0, 16);
        tvReport.setTextSize(14f);
        tvReport.setTextColor(getResources().getColor(R.color.text_secondary));
        scrollView.addView(tvReport);
        layout.addView(scrollView);

        setContentView(layout);

        mainHandler = new Handler(Looper.getMainLooper());
        detector = new BallDetector();
        calibrator = new ColorCalibrator();

        // Button handlers
        btnTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runDetectionTest();
            }
        });

        btnCalibrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCalibration();
            }
        });

        btnDebug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleDebugMode();
            }
        });

        showWelcome();
    }

    private Button createButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(12f);
        btn.setBackgroundColor(getResources().getColor(R.color.btn_calibrate));
        btn.setTextColor(getResources().getColor(R.color.text_primary));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        params.setMargins(4, 0, 4, 0);
        btn.setLayoutParams(params);
        return btn;
    }

    private void showWelcome() {
        appendReport("=== AETHER CALIBRATION TOOL ===\n\n");
        appendReport("เครื่องมือปรับค่าสี HSV\n");
        appendReport("ให้ตรงกับหน้าจอแต่ละอุปกรณ์\n\n");
        appendReport("📋 ขั้นตอน:\n");
        appendReport("1. เปิดเกม 8 Ball Pool\n");
        appendReport("2. เข้าโต๊ะที่มีลูกทุกสี\n");
        appendReport("3. กด 'Calibrate'\n");
        appendReport("4. กด 'Test' เพื่อทดสอบ\n\n");

        // แสดงค่า default
        appendReport("=== DEFAULT HSV PROFILES ===\n");
        float[][] profiles = calibrator.getProfiles();
        for (float[] p : profiles) {
            int ballNum = (int) p[6];
            appendReport(String.format("  Ball %2d: H[%3.0f-%3.0f]\n",
                ballNum, p[0], p[1]));
        }
    }

    private void runDetectionTest() {
        appendReport("\n🧪 Running Test...\n");

        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap testImage = DetectionTester.createTestImage(800, 400);
                final DetectionTester.TestResult result =
                    DetectionTester.runDetectionTest(testImage, detector);

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        appendReport(result.getReport());
                    }
                });
            }
        }).start();
    }

    private void runCalibration() {
        appendReport("\n🔧 Calibrating...\n");

        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap testImage = DetectionTester.createTestImage(800, 400);
                final ColorCalibrator.CalibrationResult result =
                    calibrator.calibrate(testImage, 0, 0,
                        testImage.getWidth(), testImage.getHeight());

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        appendReport(result.getReport());
                    }
                });
            }
        }).start();
    }

    private void toggleDebugMode() {
        appendReport("\n📊 Debug Mode\n");
        appendReport("เปิดเกม 8 Ball Pool แล้วกดเริ่ม AI\n");
    }

    private void appendReport(String text) {
        tvReport.append(text);
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(View.FOCUS_DOWN);
            }
        });
    }
}
