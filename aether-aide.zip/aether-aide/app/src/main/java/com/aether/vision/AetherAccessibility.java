package com.aether.vision;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Accessibility Service — อ่าน UI ของเกม
 * ใช้รู้ว่า:
 * - ตาใครอยู่ (turn indicator)
 * - เกมเริ่ม/จบ
 * - ข้อความในเกม
 * - ปุ่มต่างๆ
 *
 * ไม่แตะหน่วยความจำเกม 100% — อ่าน UI ผ่าน API ปกติของ Android
 */
public class AetherAccessibility extends AccessibilityService {
    private static final String TAG = "AetherA11y";

    // Package ของเกม
    private static final String GAME_PACKAGE = "com.miniclip.eightballpool";

    public interface AccessibilityCallback {
        void onGameDetected();
        void onTurnChanged(boolean myTurn);
        void onGameStateChanged(String state);
        void onTextFound(String text);
    }

    private static AccessibilityCallback callback;

    public static void setCallback(AccessibilityCallback cb) {
        callback = cb;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility Service connected");

        // ตั้งค่าให้ดักเฉพาะเกม
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) {
            info = new AccessibilityServiceInfo();
        }
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                   | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String packageName = event.getPackageName() != null ?
            event.getPackageName().toString() : "";

        // ตรวจว่าเป็นเกมไหม
        if (!packageName.equals(GAME_PACKAGE)) return;

        if (callback != null) callback.onGameDetected();

        // === วิเคราะห์ event ===
        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                analyzeGameUI();
                break;

            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                Log.d(TAG, "UI Click: " + event.getText());
                break;

            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                String text = event.getText().toString();
                analyzeText(text);
                break;
        }
    }

    /**
     * วิเคราะห์ UI ของเกม
     */
    private void analyzeGameUI() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            // ค้นหาข้อความที่บ่งบอกสถานะ
            findTextsRecursive(root, 0);
        } catch (Exception e) {
            Log.e(TAG, "UI analysis error", e);
        } finally {
            root.recycle();
        }
    }

    /**
     * ค้นหาข้อความใน UI tree
     */
    private void findTextsRecursive(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 10) return;

        // อ่านข้อความ
        CharSequence text = node.getText();
        if (text != null && text.length() > 0) {
            String textStr = text.toString().toLowerCase();
            analyzeText(textStr);
        }

        // อ่าน content description
        CharSequence desc = node.getContentDescription();
        if (desc != null && desc.length() > 0) {
            analyzeText(desc.toString().toLowerCase());
        }

        // อ่าน child nodes
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                findTextsRecursive(child, depth + 1);
                child.recycle();
            }
        }
    }

    /**
     * วิเคราะห์ข้อความที่พบ
     */
    private void analyzeText(String text) {
        text = text.toLowerCase().trim();

        // ตรวจตา
        if (text.contains("your turn") || text.contains("ตาคุณ") ||
            text.contains("shoot") || text.contains("aim")) {
            if (callback != null) callback.onTurnChanged(true);
        }

        if (text.contains("opponent") || text.contains("waiting") ||
            text.contains("คู่แข่ง") || text.contains("รอ")) {
            if (callback != null) callback.onTurnChanged(false);
        }

        // ตรวจสถานะเกม
        if (text.contains("break") || text.contains("เริ่ม")) {
            if (callback != null) callback.onGameStateChanged("breaking");
        }

        if (text.contains("win") || text.contains("ชนะ")) {
            if (callback != null) callback.onGameStateChanged("win");
        }

        if (text.contains("lose") || text.contains("แพ้")) {
            if (callback != null) callback.onGameStateChanged("lose");
        }

        // ส่งข้อความทั้งหมด
        if (callback != null) callback.onTextFound(text);
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Accessibility Service destroyed");
    }
}
