package com.aether.game;

/**
 * เวกเตอร์ 2D — ใช้ทั่วทั้งโปรเจกต์
 */
public class Vec2 {
    public float x, y;

    public Vec2() { this(0, 0); }
    public Vec2(float x, float y) { this.x = x; this.y = y; }

    public Vec2 add(Vec2 o) { return new Vec2(x + o.x, y + o.y); }
    public Vec2 sub(Vec2 o) { return new Vec2(x - o.x, y - o.y); }
    public Vec2 mul(float s) { return new Vec2(x * s, y * s); }
    public Vec2 div(float s) { return new Vec2(x / s, y / s); }

    public float dot(Vec2 o)   { return x * o.x + y * o.y; }
    public float cross(Vec2 o) { return x * o.y - y * o.x; }
    public float length()      { return (float) Math.sqrt(x * x + y * y); }
    public float lengthSq()    { return x * x + y * y; }
    public float distTo(Vec2 o) { return sub(o).length(); }

    public Vec2 normalized() {
        float l = length();
        return l > 0 ? div(l) : new Vec2();
    }

    public Vec2 perpendicular() { return new Vec2(-y, x); }

    public Vec2 reflect(Vec2 n) {
        float d = dot(n) * 2;
        return new Vec2(x - n.x * d, y - n.y * d);
    }

    public Vec2 rotated(float rad) {
        float c = (float) Math.cos(rad), s = (float) Math.sin(rad);
        return new Vec2(x * c - y * s, x * s + y * c);
    }

    public Vec2 copy() { return new Vec2(x, y); }

    @Override
    public String toString() { return String.format("(%.3f, %.3f)", x, y); }
}
