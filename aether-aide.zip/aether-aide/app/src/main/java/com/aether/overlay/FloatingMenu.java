package com.aether.overlay;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Floating Menu — ปุ่มลอยสำหรับควบคุม Aether AI
 * - ลากได้
 * - กดเพื่อเปิด/ปิด
 * - เมนูปรับแต่ง
 */
public class FloatingMenu extends Service {
    private static final String TAG = "AetherFloat";

    private WindowManager windowManager;
    private View floatingView;
    private View menuView;
    private boolean menuOpen = false;

    // Callback
    public interface MenuCallback {
        void onStartStop(boolean start);
        void onCalibrate();
        void onDebugToggle(boolean on);
        void onSettings();
    }

    private static MenuCallback callback;

    public static void setCallback(MenuCallback cb) {
        callback = cb;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createFloatingButton();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
        if (menuView != null) {
            windowManager.removeView(menuView);
        }
    }

    /**
     * สร้างปุ่มลอย
     */
    private void createFloatingButton() {
        // สร้าง floating button (ใช้ View ธรรมดา)
        floatingView = new FloatingButtonView(this);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            120, 120,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 20;
        params.y = 300;

        // ตั้งค่าให้ลากได้
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean moved = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        moved = false;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        moved = true;
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            toggleMenu();
                        }
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(floatingView, params);
    }

    /**
     * เปิด/ปิดเมนู
     */
    private void toggleMenu() {
        if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void openMenu() {
        if (menuView != null) return;

        menuView = createMenuView();

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 150;
        params.y = 300;

        windowManager.addView(menuView, params);
        menuOpen = true;
    }

    private void closeMenu() {
        if (menuView != null) {
            windowManager.removeView(menuView);
            menuView = null;
        }
        menuOpen = false;
    }

    /**
     * สร้างเมนู
     */
    private View createMenuView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.argb(230, 20, 20, 35));
        layout.setPadding(20, 20, 20, 20);

        // หัวข้อ
        TextView title = new TextView(this);
        title.setText("AETHER AI");
        title.setTextColor(Color.rgb(0, 200, 255));
        title.setTextSize(16f);
        title.setPadding(0, 0, 0, 15);
        layout.addView(title);

        // ปุ่ม Start/Stop
        Button btnStart = createMenuButton("▶ เริ่ม AI");
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) callback.onStartStop(true);
                closeMenu();
            }
        });
        layout.addView(btnStart);

        Button btnStop = createMenuButton("⏹ หยุด AI");
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) callback.onStartStop(false);
                closeMenu();
            }
        });
        layout.addView(btnStop);

        // ปุ่ม Calibrate
        Button btnCalibrate = createMenuButton("🔧 ปรับค่าสี");
        btnCalibrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) callback.onCalibrate();
                closeMenu();
            }
        });
        layout.addView(btnCalibrate);

        // ปุ่ม Debug
        Button btnDebug = createMenuButton("📊 Debug Mode");
        btnDebug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) callback.onDebugToggle(true);
                closeMenu();
            }
        });
        layout.addView(btnDebug);

        // ปุ่ม Settings
        Button btnSettings = createMenuButton("⚙️ Settings");
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) callback.onSettings();
                closeMenu();
            }
        });
        layout.addView(btnSettings);

        // ปุ่มปิด
        Button btnClose = createMenuButton("❌ ปิดเมนู");
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeMenu();
            }
        });
        layout.addView(btnClose);

        return layout;
    }

    private Button createMenuButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(14f);
        btn.setBackgroundColor(Color.argb(200, 30, 30, 50));
        btn.setTextColor(Color.WHITE);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 5, 0, 5);
        btn.setLayoutParams(params);

        return btn;
    }

    /**
     * Floating Button View (วงกลม)
     */
    private static class FloatingButtonView extends View {
        private Paint bgPaint, iconPaint, glowPaint;

        public FloatingButtonView(Context context) {
            super(context);
            initPaints();
        }

        private void initPaints() {
            bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgPaint.setColor(Color.argb(220, 0, 150, 255));
            bgPaint.setStyle(Paint.Style.FILL);

            iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            iconPaint.setColor(Color.WHITE);
            iconPaint.setTextSize(40f);
            iconPaint.setTextAlign(Paint.Align.CENTER);

            glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            glowPaint.setColor(Color.argb(80, 0, 200, 255));
            glowPaint.setStyle(Paint.Style.STROKE);
            glowPaint.setStrokeWidth(3f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - 5;

            // Glow effect
            canvas.drawCircle(cx, cy, r + 5, glowPaint);

            // Background
            canvas.drawCircle(cx, cy, r, bgPaint);

            // Eye icon
            iconPaint.setTextSize(r * 0.8f);
            canvas.drawText("👁", cx, cy + r * 0.25f, iconPaint);
        }
    }
}
