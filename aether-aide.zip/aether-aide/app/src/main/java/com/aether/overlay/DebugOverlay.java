package com.aether.overlay;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import com.aether.game.Ball;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Debug Overlay — แสดงข้อมูลการตรวจจับสีแบบ real-time
 * ช่วยปรับค่า HSV ให้ตรงกับจอแต่ละเครื่อง
 */
public class DebugOverlay extends Service {
    private static final String TAG = "AetherDebug";

    private WindowManager windowManager;
    private DebugView debugView;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        debugView = new DebugView(this);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.LEFT;
        windowManager.addView(debugView, params);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (debugView != null) windowManager.removeView(debugView);
    }

    public void updateDebug(DebugData data) {
        if (debugView != null) debugView.updateData(data);
    }

    // =====================================================
    //  ข้อมูล Debug
    // =====================================================
    public static class DebugData {
        // ลูกที่ตรวจพบ
        public List<BallDebugInfo> detectedBalls = new ArrayList<>();

        // สถิติสี
        public Map<Integer, Integer> colorHitCounts = new HashMap<>();

        // ค่า HSV ปัจจุบันที่ pixel ตรงกลางจอ
        public float centerH, centerS, centerV;

        // ข้อมูลเฟรม
        public int frameWidth, frameHeight;
        public long frameTime;
        public float fps;

        // สถานะ
        public String status = "";
        public boolean isCalibrating = false;
        public float calibrationProgress = 0f;

        // ค่า HSV ที่กำลัง debug (pixel ที่แตะ)
        public List<HSVSample> hsvSamples = new ArrayList<>();
    }

    public static class BallDebugInfo {
        public int number;
        public Vec2 pos;
        public int color;
        public float confidence;  // 0-1
        public float detectedH, detectedS, detectedV;
        public int pixelCount;    // จำนวน pixel ที่พบ
    }

    public static class HSVSample {
        public float x, y;       // screen position
        public float h, s, v;
        public int matchedBall;  // -1 = no match
    }

    // =====================================================
    //  Debug View
    // =====================================================
    private static class DebugView extends View {
        // === Colors ===
        private static final int BG_COLOR = Color.argb(200, 10, 10, 20);
        private static final int TEXT_COLOR = Color.rgb(200, 200, 200);
        private static final int HIGHLIGHT = Color.rgb(0, 200, 255);
        private static final int SUCCESS = Color.rgb(0, 255, 100);
        private static final int WARNING = Color.rgb(255, 200, 0);
        private static final int ERROR = Color.rgb(255, 50, 50);

        private Paint bgPaint, textPaint, headerPaint, colorSwatchPaint;
        private Paint crosshairPaint, ballCirclePaint;

        private DebugData data;

        public DebugView(Context context) {
            super(context);
            setWillNotDraw(false);
            initPaints();
            startAnimation();
        }

        private void initPaints() {
            bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgPaint.setColor(BG_COLOR);
            bgPaint.setStyle(Paint.Style.FILL);

            textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setColor(TEXT_COLOR);
            textPaint.setTextSize(18f);
            textPaint.setShadowLayer(2f, 1f, 1f, Color.BLACK);

            headerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            headerPaint.setColor(HIGHLIGHT);
            headerPaint.setTextSize(22f);
            headerPaint.setFakeBoldText(true);
            headerPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK);

            colorSwatchPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            colorSwatchPaint.setStyle(Paint.Style.FILL);

            crosshairPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            crosshairPaint.setColor(Color.argb(150, 255, 255, 255));
            crosshairPaint.setStrokeWidth(1f);
            crosshairPaint.setStyle(Paint.Style.STROKE);

            ballCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            ballCirclePaint.setStyle(Paint.Style.STROKE);
            ballCirclePaint.setStrokeWidth(2f);
        }

        public void updateData(DebugData data) {
            this.data = data;
            postInvalidate();
        }

        private void startAnimation() {
            post(new Runnable() {
                @Override
                public void run() {
                    invalidate();
                    postDelayed(this, 100); // 10fps for debug
                }
            });
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (canvas == null || data == null) return;

            int W = getWidth();
            int H = getHeight();

            // === 1. วาด crosshair กลางจอ ===
            drawCrosshair(canvas, W, H);

            // === 2. วาดจุดสีที่ตรวจพบ (HSV samples) ===
            drawHSVSamples(canvas);

            // === 3. วาดลูกที่ตรวจพบ ===
            drawDetectedBalls(canvas, W, H);

            // === 4. วาด Panel ข้อมูล (ซ้ายบน) ===
            drawInfoPanel(canvas, W, H);

            // === 5. วาด Color Palette (ขวาบน) ===
            drawColorPalette(canvas, W, H);

            // === 6. วาด HSV Meter (ล่างซ้าย) ===
            drawHSVMeter(canvas, W, H);

            // === 7. Calibration progress ===
            if (data.isCalibrating) {
                drawCalibrationBar(canvas, W, H);
            }
        }

        // ─── 1. Crosshair ───
        private void drawCrosshair(Canvas canvas, int W, int H) {
            float cx = W / 2f, cy = H / 2f;
            float size = 30f;

            canvas.drawLine(cx - size, cy, cx + size, cy, crosshairPaint);
            canvas.drawLine(cx, cy - size, cx, cy + size, crosshairPaint);
            canvas.drawCircle(cx, cy, size, crosshairPaint);

            // แสดง HSV ที่จุดกลาง
            textPaint.setTextSize(14f);
            textPaint.setColor(HIGHLIGHT);
            canvas.drawText(String.format("H:%.0f S:%.2f V:%.2f",
                data.centerH, data.centerS, data.centerV),
                cx + size + 10, cy + 5, textPaint);
        }

        // ─── 2. HSV Samples ───
        private void drawHSVSamples(Canvas canvas) {
            for (HSVSample sample : data.hsvSamples) {
                // จุดสีที่ตรวจพบ
                Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                int color = Color.HSVToColor(200, new float[]{sample.h, sample.s, sample.v});
                dotPaint.setColor(color);
                canvas.drawCircle(sample.x, sample.y, 8f, dotPaint);

                // ขอบตาม ball match
                if (sample.matchedBall >= 0) {
                    Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    borderPaint.setColor(SUCCESS);
                    borderPaint.setStyle(Paint.Style.STROKE);
                    borderPaint.setStrokeWidth(2f);
                    canvas.drawCircle(sample.x, sample.y, 12f, borderPaint);

                    // Label
                    textPaint.setTextSize(12f);
                    textPaint.setColor(SUCCESS);
                    canvas.drawText("B" + sample.matchedBall,
                        sample.x + 15, sample.y + 5, textPaint);
                }
            }
        }

        // ─── 3. Detected Balls ───
        private void drawDetectedBalls(Canvas canvas, int W, int H) {
            for (BallDebugInfo ball : data.detectedBalls) {
                float px = ball.pos.x * W;
                float py = ball.pos.y * H;

                // วงกลมสีลูก
                ballCirclePaint.setColor(ball.color);
                canvas.drawCircle(px, py, 25f, ballCirclePaint);

                // Confidence ring
                int confColor = ball.confidence > 0.7f ? SUCCESS :
                    ball.confidence > 0.4f ? WARNING : ERROR;
                ballCirclePaint.setColor(confColor);
                canvas.drawCircle(px, py, 30f, ballCirclePaint);

                // Label
                textPaint.setTextSize(16f);
                textPaint.setColor(Color.WHITE);
                String label = String.format("B%d (%.0f%%)", ball.number, ball.confidence * 100);
                canvas.drawText(label, px + 35, py + 5, textPaint);

                // Pixel count
                textPaint.setTextSize(12f);
                textPaint.setColor(TEXT_COLOR);
                canvas.drawText(String.format("%d px", ball.pixelCount),
                    px + 35, py + 22, textPaint);
            }
        }

        // ─── 4. Info Panel ───
        private void drawInfoPanel(Canvas canvas, int W, int H) {
            float x = 15f, y = 30f;
            float lineH = 22f;
            float panelW = 280f;
            float panelH = lineH * 9 + 20;

            // Background
            canvas.drawRoundRect(new RectF(x - 10, y - 20, x + panelW, y + panelH),
                10, 10, bgPaint);

            // Header
            headerPaint.setTextSize(18f);
            canvas.drawText("🔍 DEBUG PANEL", x, y, headerPaint);
            y += lineH + 5;

            // Status
            textPaint.setTextSize(16f);
            textPaint.setColor(data.status.contains("✅") ? SUCCESS :
                data.status.contains("❌") ? ERROR : TEXT_COLOR);
            canvas.drawText(data.status, x, y, textPaint);
            y += lineH;

            // Frame info
            textPaint.setColor(TEXT_COLOR);
            canvas.drawText(String.format("Frame: %dx%d", data.frameWidth, data.frameHeight), x, y, textPaint);
            y += lineH;

            canvas.drawText(String.format("FPS: %.1f", data.fps), x, y, textPaint);
            y += lineH;

            // Detected count
            textPaint.setColor(HIGHLIGHT);
            canvas.drawText(String.format("Balls detected: %d", data.detectedBalls.size()), x, y, textPaint);
            y += lineH;

            // Color hits
            textPaint.setColor(TEXT_COLOR);
            StringBuilder hits = new StringBuilder("Color hits: ");
            for (Map.Entry<Integer, Integer> entry : data.colorHitCounts.entrySet()) {
                hits.append(String.format("B%d:%d ", entry.getKey(), entry.getValue()));
            }
            canvas.drawText(hits.toString(), x, y, textPaint);
            y += lineH;

            // HSV samples count
            canvas.drawText(String.format("HSV samples: %d", data.hsvSamples.size()), x, y, textPaint);
            y += lineH;

            // Instructions
            textPaint.setColor(WARNING);
            textPaint.setTextSize(14f);
            canvas.drawText("แตะจอเพื่อ sampling HSV", x, y, textPaint);
        }

        // ─── 5. Color Palette ───
        private void drawColorPalette(Canvas canvas, int W, int H) {
            float x = W - 120f, y = 30f;
            float swatchSize = 25f;
            float gap = 5f;

            // Background
            canvas.drawRoundRect(new RectF(x - 10, y - 20, W - 5, y + swatchSize * 16 + gap * 16),
                10, 10, bgPaint);

            // Header
            headerPaint.setTextSize(14f);
            canvas.drawText("COLORS", x, y, headerPaint);
            y += 20;

            // Swatches
            int[] ballNums = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
            String[] labels = {"CUE", "YLW", "BLU", "RED", "PUR", "ORN", "GRN", "MAR",
                              "8", "S-Y", "S-B", "S-R", "S-P", "S-O", "S-G", "S-M"};

            for (int i = 0; i < ballNums.length; i++) {
                int color = Ball.getBallColor(ballNums[i]);

                // Swatch
                colorSwatchPaint.setColor(color);
                canvas.drawRect(x, y, x + swatchSize, y + swatchSize, colorSwatchPaint);

                // Border
                Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
                border.setColor(Color.WHITE);
                border.setStyle(Paint.Style.STROKE);
                border.setStrokeWidth(1f);
                canvas.drawRect(x, y, x + swatchSize, y + swatchSize, border);

                // Label
                textPaint.setTextSize(11f);
                textPaint.setColor(TEXT_COLOR);
                canvas.drawText(labels[i], x + swatchSize + 5, y + 17, textPaint);

                // Hit count
                Integer hits = data.colorHitCounts.get(ballNums[i]);
                if (hits != null && hits > 0) {
                    textPaint.setColor(SUCCESS);
                    canvas.drawText("✓", x + swatchSize + 45, y + 17, textPaint);
                }

                y += swatchSize + gap;
            }
        }

        // ─── 6. HSV Meter ───
        private void drawHSVMeter(Canvas canvas, int W, int H) {
            float x = 15f, y = H - 140f;
            float meterW = 200f, meterH = 15f;

            // Background
            canvas.drawRoundRect(new RectF(x - 10, y - 25, x + meterW + 80, y + 90),
                10, 10, bgPaint);

            // Header
            textPaint.setTextSize(14f);
            textPaint.setColor(HIGHLIGHT);
            canvas.drawText("Center Pixel HSV", x, y - 5, textPaint);
            y += 15;

            // H meter (0-360)
            drawMeter(canvas, x, y, meterW, meterH, data.centerH / 360f,
                Color.HSVToColor(255, new float[]{data.centerH, 1f, 1f}), "H");
            textPaint.setColor(TEXT_COLOR);
            textPaint.setTextSize(12f);
            canvas.drawText(String.format("%.0f°", data.centerH), x + meterW + 5, y + 12, textPaint);
            y += meterH + 10;

            // S meter (0-1)
            drawMeter(canvas, x, y, meterW, meterH, data.centerS,
                Color.HSVToColor(255, new float[]{data.centerH, data.centerS, 1f}), "S");
            canvas.drawText(String.format("%.2f", data.centerS), x + meterW + 5, y + 12, textPaint);
            y += meterH + 10;

            // V meter (0-1)
            drawMeter(canvas, x, y, meterW, meterH, data.centerV,
                Color.HSVToColor(255, new float[]{data.centerH, 1f, data.centerV}), "V");
            canvas.drawText(String.format("%.2f", data.centerV), x + meterW + 5, y + 12, textPaint);
        }

        private void drawMeter(Canvas canvas, float x, float y, float w, float h,
                                float fill, int color, String label) {
            // Background
            Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            bgPaint.setColor(Color.argb(100, 50, 50, 50));
            canvas.drawRoundRect(new RectF(x, y, x + w, y + h), 5, 5, bgPaint);

            // Fill
            Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            fillPaint.setColor(color);
            canvas.drawRoundRect(new RectF(x, y, x + w * Math.min(1f, fill), y + h), 5, 5, fillPaint);

            // Label
            textPaint.setTextSize(12f);
            textPaint.setColor(Color.WHITE);
            canvas.drawText(label, x - 15, y + 12, textPaint);
        }

        // ─── 7. Calibration Bar ───
        private void drawCalibrationBar(Canvas canvas, int W, int H) {
            float barW = W * 0.6f;
            float barH = 30f;
            float x = (W - barW) / 2;
            float y = H / 2f - barH / 2;

            // Background
            canvas.drawRoundRect(new RectF(x - 5, y - 40, x + barW + 5, y + barH + 20),
                15, 15, bgPaint);

            // Text
            headerPaint.setTextSize(18f);
            headerPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("🔧 Calibrating...", W / 2f, y - 10, headerPaint);
            headerPaint.setTextAlign(Paint.Align.LEFT);

            // Bar background
            Paint barBg = new Paint(Paint.ANTI_ALIAS_FLAG);
            barBg.setColor(Color.argb(100, 50, 50, 50));
            canvas.drawRoundRect(new RectF(x, y, x + barW, y + barH), 10, 10, barBg);

            // Bar fill
            Paint barFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            barFill.setColor(HIGHLIGHT);
            canvas.drawRoundRect(new RectF(x, y, x + barW * data.calibrationProgress, y + barH),
                10, 10, barFill);

            // Percentage
            textPaint.setTextSize(18f);
            textPaint.setColor(Color.WHITE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(String.format("%.0f%%", data.calibrationProgress * 100),
                W / 2f, y + barH - 8, textPaint);
            textPaint.setTextAlign(Paint.Align.LEFT);
        }
    }
}
