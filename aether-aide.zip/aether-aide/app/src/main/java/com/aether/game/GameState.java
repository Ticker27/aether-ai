package com.aether.game;

import java.util.ArrayList;
import java.util.List;

/**
 * สถานะเกมปัจจุบัน — ได้มาจากสายตา AI
 */
public class GameState {
    // === โต๊ะ ===
    public float tableX, tableY;        // ตำแหน่งโต๊ะบนจอ (pixel)
    public float tableW, tableH;        // ขนาดโต๊ะ (pixel)
    public float tableAngle;            // มุมเอียงของโต๊ะ (radians)

    // === หลุม ===
    public Vec2[] pockets = new Vec2[6]; // ตำแหน่งหลุม 6 จุด (normalized)

    // === ลูก ===
    public List<Ball> balls = new ArrayList<>();
    public Ball cueBall;                // reference ไปที่ลูก cue

    // === สถานะเกม ===
    public boolean myTurn;              // ตาของเรา
    public boolean ballInHand;          // วางลูก cue ได้
    public boolean isBreaking;          // กำลัง break
    public int myType;                  // 0=ยังไม่กำหนด, 1=solid, 2=stripe
    public int targetBall;              // ลูกที่ต้องยิง (from AI)

    // === เวลา ===
    public long timestamp;              // เวลาที่อัปเดต
    public int frameNumber;             // เฟรมปัจจุบัน

    public GameState() {
        timestamp = System.currentTimeMillis();
    }

    public void updateFromVision(Ball[] detectedBalls, float tx, float ty,
                                  float tw, float th) {
        tableX = tx; tableY = ty;
        tableW = tw; tableH = th;
        timestamp = System.currentTimeMillis();
        frameNumber++;

        // อัปเดตตำแหน่งลูก (merge กับข้อมูลเดิมเพื่อ smooth)
        for (Ball detected : detectedBalls) {
            Ball existing = findBall(detected.number);
            if (existing != null) {
                // Smooth position (EMA)
                float alpha = 0.7f;
                existing.pos.x = existing.pos.x * (1-alpha) + detected.pos.x * alpha;
                existing.pos.y = existing.pos.y * (1-alpha) + detected.pos.y * alpha;
                existing.vel = detected.pos.sub(existing.pos);
                existing.visible = true;
            } else {
                balls.add(detected);
            }
        }

        // หาลูก cue
        for (Ball b : balls) {
            if (b.isCue()) { cueBall = b; break; }
        }

        // 标记ลูกที่ไม่เห็น
        for (Ball b : balls) {
            boolean found = false;
            for (Ball d : detectedBalls) {
                if (d.number == b.number) { found = true; break; }
            }
            if (!found) b.visible = false;
        }
    }

    private Ball findBall(int number) {
        for (Ball b : balls) {
            if (b.number == number) return b;
        }
        return null;
    }

    public List<Ball> getActiveBalls() {
        List<Ball> active = new ArrayList<>();
        for (Ball b : balls) {
            if (!b.pocketed && b.visible) active.add(b);
        }
        return active;
    }

    public List<Ball> getMyBalls() {
        List<Ball> result = new ArrayList<>();
        for (Ball b : getActiveBalls()) {
            if (b.isCue() || b.isEight()) continue;
            if (myType == 1 && b.isSolid()) result.add(b);
            else if (myType == 2 && b.isStripe()) result.add(b);
        }
        return result;
    }

    public boolean isAllMyBallsPocketed() {
        return getMyBalls().isEmpty();
    }
}
