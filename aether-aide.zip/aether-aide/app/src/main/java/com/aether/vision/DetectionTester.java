package com.aether.vision;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.Log;

import com.aether.game.Ball;
import com.aether.game.Vec2;

import java.util.List;

/**
 * ทดสอบการตรวจจับ — สร้างภาพจำลองจากค่าสีจริง
 * ใช้ตรวจสอบว่า HSV profile ตรงกับสีจริงในเกมไหม
 */
public class DetectionTester {
    private static final String TAG = "AetherTest";

    /**
     * สร้างภาพทดสอบที่มีลูกทุกสี
     * (ใช้ค่าสี RGB จริงจาก Miniclip)
     */
    public static Bitmap createTestImage(int width, int height) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        // พื้นหลังสีเขียวโต๊ะ
        Paint bgPaint = new Paint();
        bgPaint.setColor(Color.rgb(20, 100, 40)); // สีโต๊ะ Miniclip
        canvas.drawRect(0, 0, width, height, bgPaint);

        // วาดลูกทุกสี
        float ballRadius = Math.min(width, height) * 0.04f;
        float startX = width * 0.1f;
        float startY = height * 0.15f;
        float gapX = width * 0.1f;
        float gapY = height * 0.2f;

        // แถว 1: Solid (1-7) + Cue
        drawBall(canvas, startX, startY, ballRadius, 0);  // Cue
        for (int i = 1; i <= 7; i++) {
            drawBall(canvas, startX + i * gapX, startY, ballRadius, i);
        }

        // แถว 2: Stripe (9-15) + 8
        drawBall(canvas, startX, startY + gapY, ballRadius, 8); // 8-ball
        for (int i = 9; i <= 15; i++) {
            drawBall(canvas, startX + (i - 8) * gapX, startY + gapY, ballRadius, i);
        }

        // แถว 3: Random positions (simulate game)
        drawBall(canvas, width * 0.3f, height * 0.5f, ballRadius, 1);
        drawBall(canvas, width * 0.5f, height * 0.6f, ballRadius, 3);
        drawBall(canvas, width * 0.7f, height * 0.45f, ballRadius, 5);
        drawBall(canvas, width * 0.4f, height * 0.7f, ballRadius, 10);
        drawBall(canvas, width * 0.6f, height * 0.75f, ballRadius, 12);

        return bitmap;
    }

    /**
     * วาดลูกบิลเลียด (solid + stripe)
     */
    private static void drawBall(Canvas canvas, float cx, float cy, float r, int ballNum) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        if (ballNum == 0) {
            // Cue ball — ขาว
            paint.setColor(Color.rgb(255, 255, 255));
            canvas.drawCircle(cx, cy, r, paint);

            // Highlight
            paint.setColor(Color.argb(80, 255, 255, 255));
            canvas.drawCircle(cx - r * 0.3f, cy - r * 0.3f, r * 0.4f, paint);
            return;
        }

        if (ballNum == 8) {
            // 8-ball — ดำ
            paint.setColor(Color.rgb(20, 20, 20));
            canvas.drawCircle(cx, cy, r, paint);

            // White circle with 8
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r * 0.4f, paint);

            paint.setColor(Color.BLACK);
            paint.setTextSize(r * 0.5f);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("8", cx, cy + r * 0.15f, paint);
            return;
        }

        int color = Ball.getBallColor(ballNum);
        boolean isStripe = ballNum >= 9;

        if (isStripe) {
            // Stripe: white base + color band
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r, paint);

            // Color band (middle)
            paint.setColor(color);
            canvas.drawRect(cx - r, cy - r * 0.5f, cx + r, cy + r * 0.5f, paint);

            // Clip to circle
            paint.setXfermode(new android.graphics.PorterDuffXfermode(
                android.graphics.PorterDuff.Mode.DST_IN));
            paint.setColor(Color.WHITE);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setXfermode(null);
        } else {
            // Solid: full color
            paint.setColor(color);
            canvas.drawCircle(cx, cy, r, paint);

            // Highlight
            paint.setColor(Color.argb(60, 255, 255, 255));
            canvas.drawCircle(cx - r * 0.3f, cy - r * 0.3f, r * 0.35f, paint);
        }

        // Number circle
        paint.setColor(Color.WHITE);
        canvas.drawCircle(cx, cy, r * 0.35f, paint);

        // Number text
        paint.setColor(Color.BLACK);
        paint.setTextSize(r * 0.4f);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.valueOf(ballNum), cx, cy + r * 0.12f, paint);
    }

    /**
     * ทดสอบการตรวจจับกับภาพทดสอบ
     */
    public static TestResult runDetectionTest(Bitmap testImage, BallDetector detector) {
        TestResult result = new TestResult();

        // ตั้งค่า table bounds (ทั้งภาพ)
        detector.setTableBounds(0, 0, testImage.getWidth(), testImage.getHeight());

        // ตรวจจับ
        long startTime = System.currentTimeMillis();
        List<Ball> detected = detector.detect(testImage);
        long elapsed = System.currentTimeMillis() - startTime;

        result.detectionTimeMs = elapsed;
        result.detectedCount = detected.size();

        // ตรวจสอบว่าตรวจพบลูกครบไหม
        boolean[] found = new boolean[16];
        for (Ball b : detected) {
            if (b.number >= 0 && b.number <= 15) {
                found[b.number] = true;
                result.detectedBalls.add(b.number);
            }
        }

        // นับลูกที่ตรวจพบ vs ที่ควรมี
        int expectedCount = 16; // 0-15
        int foundCount = 0;
        for (int i = 0; i < 16; i++) {
            if (found[i]) foundCount++;
            else result.missedBalls.add(i);
        }

        result.foundCount = foundCount;
        result.accuracy = (float) foundCount / expectedCount;
        result.success = result.accuracy >= 0.7f; // 70% threshold

        return result;
    }

    public static class TestResult {
        public boolean success;
        public float accuracy;
        public int detectedCount;
        public int foundCount;
        public long detectionTimeMs;
        public List<Integer> detectedBalls = new java.util.ArrayList<>();
        public List<Integer> missedBalls = new java.util.ArrayList<>();

        public String getReport() {
            StringBuilder sb = new StringBuilder();
            sb.append("=== Detection Test Report ===\n");
            sb.append(String.format("Status: %s\n", success ? "✅ PASS" : "❌ FAIL"));
            sb.append(String.format("Accuracy: %.1f%% (%d/16 balls)\n", accuracy * 100, foundCount));
            sb.append(String.format("Detection time: %d ms\n", detectionTimeMs));
            sb.append(String.format("Detected: %d blobs\n\n", detectedCount));

            sb.append("Found: ");
            for (int b : detectedBalls) sb.append(b).append(" ");
            sb.append("\n");

            if (!missedBalls.isEmpty()) {
                sb.append("Missed: ");
                for (int b : missedBalls) sb.append(b).append(" ");
                sb.append("\n");
            }

            return sb.toString();
        }
    }
}
