package com.aether.brain;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import com.aether.game.Ball;
import com.aether.game.GameState;
import com.aether.game.Vec2;
import com.aether.overlay.AetherOverlay;

import java.util.ArrayList;
import java.util.List;

/**
 * สมองหลักของ Aether AI
 */
public class AetherBrain {
    private static final String TAG = "AetherBrain";

    public interface BrainCallback {
        void onShotDecision(StrategyEngine.ShotOption shot);
        void onESPUpdate(AetherOverlay.ESPData espData);
        void onStateChange(String state);
    }

    private Context context;
    private Handler mainHandler;
    private BrainCallback callback;
    private GameState gameState;
    private StrategyEngine.ShotOption lastDecision;
    private volatile boolean thinking = false;
    private long lastThinkTime = 0;
    private static final long THINK_COOLDOWN = 300;

    public AetherBrain(Context context) {
        this.context = context;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.gameState = new GameState();
    }

    public void setCallback(BrainCallback cb) {
        this.callback = cb;
    }

    public void processVision(Ball[] detectedBalls, float tableX, float tableY,
                               float tableW, float tableH) {
        gameState.updateFromVision(detectedBalls, tableX, tableY, tableW, tableH);

        long now = System.currentTimeMillis();
        if (now - lastThinkTime < THINK_COOLDOWN || thinking) return;

        thinking = true;
        lastThinkTime = now;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    think();
                } catch (Exception e) {
                    Log.e(TAG, "Thinking error", e);
                } finally {
                    thinking = false;
                }
            }
        }).start();
    }

    private void think() {
        if (!gameState.myTurn) {
            notifyState("รอตา...");
            return;
        }

        List<Ball> activeBalls = gameState.getActiveBalls();
        if (activeBalls.size() < 2) {
            notifyState("ไม่พบลูกเพียงพอ");
            return;
        }

        StrategyEngine.ShotOption bestShot = StrategyEngine.findBestShot(gameState);
        if (bestShot == null) {
            notifyState("ไม่พบ shot ที่ดี");
            return;
        }

        lastDecision = bestShot;

        final AetherOverlay.ESPData espData = buildESPData(bestShot, gameState);
        final StrategyEngine.ShotOption shot = bestShot;

        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) {
                    callback.onShotDecision(shot);
                    callback.onESPUpdate(espData);
                    callback.onStateChange(shot.reason);
                }
                Toast.makeText(context, "🎯 " + shot.reason, Toast.LENGTH_LONG).show();
            }
        });
    }

    private AetherOverlay.ESPData buildESPData(StrategyEngine.ShotOption shot, GameState state) {
        AetherOverlay.ESPData esp = new AetherOverlay.ESPData();

        esp.tableX = state.tableX;
        esp.tableY = state.tableY;
        esp.tableW = state.tableW;
        esp.tableH = state.tableH;

        esp.power = shot.power;
        esp.angle = shot.angle;
        esp.shotType = shot.shotType;
        esp.sideSpin = shot.sideSpin;
        esp.topSpin = shot.topSpin;

        if (shot.targetBall != null) {
            esp.targetBallNum = shot.targetBall.number;
        }

        if (shot.simResult != null) {
            PhysicsEngine.FullSimResult sim = shot.simResult;
            esp.cueBallPath = sim.cuePath;
            esp.impactPoint = sim.impactPoint;

            for (PhysicsEngine.BallPathResult bpr : sim.ballPaths) {
                if (bpr.ballNumber == 0) continue;
                if (bpr.path.size() < 2) continue;

                AetherOverlay.BallPath bp = new AetherOverlay.BallPath(
                    bpr.ballNumber,
                    Ball.getBallColor(bpr.ballNumber),
                    bpr.path
                );
                bp.pocketed = bpr.pocketed;
                bp.pocketIndex = bpr.pocketIndex;
                bp.finalPos = bpr.finalPos;
                esp.allBallPaths.add(bp);

                if (bpr.ballNumber == esp.targetBallNum) {
                    esp.targetBallPath = bpr.path;
                    if (bpr.pocketed && bpr.pocketIndex >= 0) {
                        esp.pocketTarget = PhysicsEngine.POCKETS[bpr.pocketIndex];
                    }
                }
            }
        }

        return esp;
    }

    public void forceRethink() {
        lastThinkTime = 0;
    }

    public void setMyTurn(boolean turn) {
        gameState.myTurn = turn;
        if (turn) forceRethink();
    }

    public void setMyType(int type) {
        gameState.myType = type;
    }

    public GameState getGameState() {
        return gameState;
    }

    public StrategyEngine.ShotOption getLastDecision() {
        return lastDecision;
    }

    private void notifyState(String state) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onStateChange(state);
            }
        });
    }
}
