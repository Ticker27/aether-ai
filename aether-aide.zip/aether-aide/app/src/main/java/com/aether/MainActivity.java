package com.aether;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aether.brain.AetherBrain;
import com.aether.brain.StrategyEngine;
import com.aether.game.Ball;
import com.aether.game.Vec2;
import com.aether.overlay.AetherOverlay;
import com.aether.overlay.DebugOverlay;
import com.aether.overlay.FloatingMenu;
import com.aether.vision.AetherAccessibility;
import com.aether.vision.BallDetector;
import com.aether.vision.ScreenCapture;
import com.aether.vision.TableDetector;

import java.util.List;

/**
 * Aether AI — Main Activity
 * รวม Floating Menu + Table Auto-detect
 */
public class MainActivity extends Activity {
    private static final String TAG = "AetherMain";
    private static final int REQUEST_MEDIA_PROJECTION = 1001;
    private static final int REQUEST_OVERLAY = 1002;

    private Button btnStart, btnStop, btnCalibrate;
    private TextView tvStatus, tvInfo;

    private ScreenCapture screenCapture;
    private BallDetector ballDetector;
    private TableDetector tableDetector;
    private AetherBrain brain;
    private Handler mainHandler;

    private boolean engineRunning = false;
    private boolean debugMode = false;
    private TableDetector.TableResult currentTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainHandler = new Handler(Looper.getMainLooper());

        btnStart = (Button) findViewById(R.id.btnStart);
        btnStop = (Button) findViewById(R.id.btnStop);
        btnCalibrate = (Button) findViewById(R.id.btnCalibrate);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        tvInfo = (TextView) findViewById(R.id.tvInfo);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startEngine();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopEngine();
            }
        });

        btnCalibrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalibration();
            }
        });

        checkPermissions();
        setupAccessibility();
        setupFloatingMenu();
        updateUI();
    }

    private void setupAccessibility() {
        AetherAccessibility.setCallback(new AetherAccessibility.AccessibilityCallback() {
            @Override
            public void onGameDetected() {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText("🎯 ตรวจพบเกม 8 Ball Pool");
                    }
                });
            }

            @Override
            public void onTurnChanged(boolean myTurn) {
                if (brain != null) brain.setMyTurn(myTurn);
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText(myTurn ? "🟢 ตาของเรา" : "🔴 ตาคู่แข่ง");
                    }
                });
            }

            @Override
            public void onGameStateChanged(String state) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvInfo.setText("สถานะ: " + state);
                    }
                });
            }

            @Override
            public void onTextFound(String text) {
                Log.d(TAG, "Game: " + text);
            }
        });
    }

    /**
     * ตั้งค่า Floating Menu
     */
    private void setupFloatingMenu() {
        FloatingMenu.setCallback(new FloatingMenu.MenuCallback() {
            @Override
            public void onStartStop(boolean start) {
                if (start) {
                    startEngine();
                } else {
                    stopEngine();
                }
            }

            @Override
            public void onCalibrate() {
                openCalibration();
            }

            @Override
            public void onDebugToggle(boolean on) {
                debugMode = on;
                Toast.makeText(MainActivity.this,
                    on ? "📊 Debug ON" : "📊 Debug OFF",
                    Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSettings() {
                Toast.makeText(MainActivity.this,
                    "⚙️ Settings (เร็วๆ นี้)",
                    Toast.LENGTH_SHORT).show();
            }
        });

        // เริ่ม Floating Menu
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(this, FloatingMenu.class);
            startService(intent);
        }
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            }
        }
    }

    private void startEngine() {
        if (engineRunning) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "❌ ต้องอนุญาต Overlay", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        MediaProjectionManager mpm = (MediaProjectionManager)
            getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);
    }

    private void stopEngine() {
        engineRunning = false;

        if (screenCapture != null) {
            screenCapture.stop();
            screenCapture = null;
        }

        try {
            stopService(new Intent(this, AetherOverlay.class));
            stopService(new Intent(this, DebugOverlay.class));
        } catch (Exception e) {
            Log.e(TAG, "Error stopping services", e);
        }

        brain = null;
        currentTable = null;
        updateUI();
        Toast.makeText(this, "⏹️ หยุดแล้ว", Toast.LENGTH_SHORT).show();
    }

    private void openCalibration() {
        startActivity(new Intent(this, CalibrationActivity.class));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MEDIA_PROJECTION && resultCode == RESULT_OK && data != null) {
            initEngine(resultCode, data);
        }
    }

    /**
     * เริ่ม Engine ทั้งหมด
     */
    private void initEngine(int resultCode, Intent data) {
        MediaProjectionManager mpm = (MediaProjectionManager)
            getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        MediaProjection projection = mpm.getMediaProjection(resultCode, data);

        if (projection == null) {
            Toast.makeText(this, "❌ MediaProjection ล้มเหลว", Toast.LENGTH_SHORT).show();
            return;
        }

        // สร้าง components
        screenCapture = new ScreenCapture(this, projection);
        ballDetector = new BallDetector();
        tableDetector = new TableDetector();
        brain = new AetherBrain(this);

        brain.setCallback(new AetherBrain.BrainCallback() {
            @Override
            public void onShotDecision(StrategyEngine.ShotOption shot) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvInfo.setText("🎯 " + shot.reason);
                    }
                });
            }

            @Override
            public void onESPUpdate(AetherOverlay.ESPData espData) {
                // ส่งไป overlay
            }

            @Override
            public void onStateChange(String state) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvStatus.setText(state);
                    }
                });
            }
        });

        // Frame callback — ตรวจจับโต๊ะ + ลูก
        screenCapture.setFrameCallback(new ScreenCapture.FrameCallback() {
            @Override
            public void onFrame(final Bitmap frame, long timestamp) {
                processFrame(frame);
            }
        });

        // เริ่ม services
        try {
            startService(new Intent(this, AetherOverlay.class));
            if (debugMode) {
                startService(new Intent(this, DebugOverlay.class));
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting services", e);
        }

        screenCapture.start();
        engineRunning = true;
        updateUI();
        Toast.makeText(this, "👁️ Aether AI เริ่มทำงาน", Toast.LENGTH_SHORT).show();
    }

    /**
     * ประมวลผลแต่ละเฟรม
     */
    private void processFrame(Bitmap frame) {
        // === 1. ตรวจจับโต๊ะ (ทำครั้งแรก หรือ ทุกๆ 30 เฟรม) ===
        if (currentTable == null) {
            currentTable = TableDetector.detect(frame);
            if (currentTable.found) {
                // ตั้งค่า table bounds ให้ ball detector
                ballDetector.setTableBounds(
                    currentTable.left, currentTable.top,
                    currentTable.right, currentTable.bottom
                );

                Log.d(TAG, "Table detected: " + currentTable);
                for (int i = 0; i < 6; i++) {
                    Log.d(TAG, String.format("  Pocket %d: (%.0f, %.0f)",
                        i, currentTable.pockets[i].x, currentTable.pockets[i].y));
                }

                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvInfo.setText(String.format("โต๊ะ: %.0fx%.0f, หลุม 6 จุด",
                            currentTable.width, currentTable.height));
                    }
                });
            }
        }

        // === 2. ตรวจจับลูก ===
        if (currentTable != null && currentTable.found) {
            List<Ball> detected = ballDetector.detect(frame);

            // === 3. ส่งไป Brain ===
            if (brain != null) {
                brain.processVision(
                    detected.toArray(new Ball[0]),
                    currentTable.left, currentTable.top,
                    currentTable.width, currentTable.height
                );
            }

            // === 4. Debug overlay ===
            if (debugMode) {
                updateDebugOverlay(detected);
            }
        }
    }

    /**
     * อัปเดต debug overlay
     */
    private void updateDebugOverlay(List<Ball> detected) {
        DebugOverlay.DebugData data = new DebugOverlay.DebugData();
        data.frameWidth = screenCapture.getWidth();
        data.frameHeight = screenCapture.getHeight();
        data.status = engineRunning ? "✅ Running" : "⏹ Stopped";

        for (Ball b : detected) {
            DebugOverlay.BallDebugInfo info = new DebugOverlay.BallDebugInfo();
            info.number = b.number;
            info.pos = b.pos;
            info.color = b.color;
            info.confidence = 0.8f;
            data.detectedBalls.add(info);
        }

        // ส่งไป overlay
        Intent intent = new Intent("com.aether.DEBUG_UPDATE");
        // ใช้ static method แทน
    }

    private void updateUI() {
        btnStart.setEnabled(!engineRunning);
        btnStop.setEnabled(engineRunning);
        tvStatus.setText(engineRunning ? "🟢 กำลังทำงาน..." : "⏹️ หยุดอยู่");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (engineRunning) stopEngine();
        try {
            stopService(new Intent(this, FloatingMenu.class));
        } catch (Exception e) {
            Log.e(TAG, "Error stopping floating menu", e);
        }
    }
}
