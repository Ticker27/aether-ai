package com.aether.brain;

import com.aether.game.Ball;
import com.aether.game.GameState;
import com.aether.game.Vec2;

import java.util.ArrayList;
import java.util.List;

/**
 * เอนจิ้นฟิสิกส์ — จำลองการเคลื่อนที่ของลูก
 * รองรับ: ชนลูก, ชนขอบ (multi-bounce), spin, ลงหลุม
 * เหมือนในวิดีโอ ESP: แสดงเส้นทางทุกลูก, bank shot, combo
 */
public class PhysicsEngine {

    // === ค่าคงที่ ===
    public static final float BALL_RADIUS     = 0.025f;
    public static final float TABLE_LEFT      = 0.05f;
    public static final float TABLE_RIGHT     = 0.95f;
    public static final float TABLE_TOP       = 0.05f;
    public static final float TABLE_BOTTOM    = 0.95f;
    public static final float POCKET_RADIUS   = 0.04f;

    public static final float CUSHION_RESTITUTION = 0.82f;
    public static final float BALL_RESTITUTION    = 0.95f;
    public static final float FRICTION            = 0.985f;
    public static final float SPIN_DECAY          = 0.98f;
    public static final float MIN_VELOCITY        = 0.0003f;
    public static final int   MAX_SIM_STEPS       = 800;

    // === หลุม ===
    public static final Vec2[] POCKETS = {
        new Vec2(TABLE_LEFT,  TABLE_TOP),
        new Vec2(0.5f,        TABLE_TOP - 0.01f),
        new Vec2(TABLE_RIGHT, TABLE_TOP),
        new Vec2(TABLE_LEFT,  TABLE_BOTTOM),
        new Vec2(0.5f,        TABLE_BOTTOM + 0.01f),
        new Vec2(TABLE_RIGHT, TABLE_BOTTOM)
    };

    // =====================================================
    //  ผลลัพธ์การจำลองแบบเต็ม (เหมือน ESP ในวิดีโอ)
    // =====================================================
    public static class FullSimResult {
        // เส้นทางลูก cue
        public List<Vec2> cuePath = new ArrayList<>();
        public boolean cuePocketed;

        // เส้นทางทุกลูก (สำหรับ multi-ball ESP)
        public List<BallPathResult> ballPaths = new ArrayList<>();

        // Bank shot paths (เส้นทางชิ่ง)
        public List<List<Vec2>> bankPaths = new ArrayList<>();

        // จุดกระทบ
        public Vec2 impactPoint;
        public int targetBallNum;
        public int pocketIndex = -1;

        // Shot info
        public String shotType = "STRAIGHT";
        public int collisionCount;
    }

    public static class BallPathResult {
        public int ballNumber;
        public List<Vec2> path = new ArrayList<>();
        public boolean pocketed;
        public int pocketIndex = -1;
        public Vec2 finalPos;
    }

    // =====================================================
    //  จำลองแบบเต็ม — ทุกลูก, ทุก碰撞, multi-bounce
    // =====================================================
    public static FullSimResult simulateFull(Vec2 cuePos, Vec2 aimDir, float power,
                                              List<Ball> balls, boolean hasSpin,
                                              float sideSpin, float topSpin) {
        FullSimResult result = new FullSimResult();

        // สร้างลูกจำลอง
        List<SimBall> simBalls = new ArrayList<>();
        for (Ball b : balls) {
            simBalls.add(new SimBall(b));
        }

        // หาลูก cue
        SimBall cue = null;
        for (SimBall b : simBalls) {
            if (b.number == 0) { cue = b; break; }
        }
        if (cue == null) return result;

        // ตั้งค่าเริ่มต้น
        float speed = power * 0.18f;
        cue.vel = aimDir.normalized().mul(speed);

        // Spin
        cue.sideSpin = hasSpin ? sideSpin : 0;
        cue.topSpin = hasSpin ? topSpin : 0;

        // Top spin effect
        if (cue.topSpin > 0) cue.vel = cue.vel.mul(1 + cue.topSpin * 0.2f);
        if (cue.topSpin < 0) cue.vel = cue.vel.mul(1 + cue.topSpin * 0.15f);

        // เก็บ path เริ่มต้น
        result.cuePath.add(cue.pos.copy());

        // สร้าง BallPathResult สำหรับทุกลูก
        for (SimBall b : simBalls) {
            BallPathResult bpr = new BallPathResult();
            bpr.ballNumber = b.number;
            bpr.path.add(b.pos.copy());
            result.ballPaths.add(bpr);
        }

        boolean cueHitTarget = false;

        // === จำลอง ===
        for (int step = 0; step < MAX_SIM_STEPS; step++) {
            boolean anyMoving = false;

            // อัปเดตตำแหน่ง
            for (SimBall b : simBalls) {
                if (b.pocketed) continue;
                b.pos = b.pos.add(b.vel);

                // Friction
                b.vel = b.vel.mul(FRICTION);
                b.sideSpin *= SPIN_DECAY;
                b.topSpin *= SPIN_DECAY;

                // Side spin → เบี่ยงทิศ
                if (Math.abs(b.sideSpin) > 0.01f && b.vel.length() > MIN_VELOCITY) {
                    Vec2 perp = b.vel.normalized().perpendicular();
                    b.vel = b.vel.add(perp.mul(b.sideSpin * 0.0008f));
                }

                if (b.vel.length() < MIN_VELOCITY) {
                    b.vel = new Vec2();
                } else {
                    anyMoving = true;
                }
            }

            // ตรวจชนลูก vs ลูก
            for (int i = 0; i < simBalls.size(); i++) {
                for (int j = i + 1; j < simBalls.size(); j++) {
                    SimBall a = simBalls.get(i), b = simBalls.get(j);
                    if (a.pocketed || b.pocketed) continue;

                    Vec2 diff = b.pos.sub(a.pos);
                    float dist = diff.length();
                    float minDist = BALL_RADIUS * 2;

                    if (dist < minDist && dist > 0.0001f) {
                        Vec2 normal = diff.normalized();
                        float overlap = minDist - dist;
                        a.pos = a.pos.sub(normal.mul(overlap / 2));
                        b.pos = b.pos.add(normal.mul(overlap / 2));

                        Vec2 relVel = a.vel.sub(b.vel);
                        float velNorm = relVel.dot(normal);
                        if (velNorm > 0) {
                            float j_impulse = -(1 + BALL_RESTITUTION) * velNorm / 2;
                            Vec2 impulse = normal.mul(j_impulse);
                            a.vel = a.vel.add(impulse);
                            b.vel = b.vel.sub(impulse);

                            // Spin transfer
                            b.sideSpin += a.sideSpin * 0.1f;

                            result.collisionCount++;
                            if (a.number == 0 || b.number == 0) {
                                cueHitTarget = true;
                                result.impactPoint = a.number == 0 ?
                                    a.pos.add(normal.mul(BALL_RADIUS)) :
                                    b.pos.sub(normal.mul(BALL_RADIUS));
                                result.targetBallNum = a.number == 0 ? b.number : a.number;
                            }
                        }
                    }
                }
            }

            // ตรวจชนขอบ + ลงหลุม
            for (SimBall b : simBalls) {
                if (b.pocketed) continue;

                // Cushion
                boolean bounced = false;
                if (b.pos.x - BALL_RADIUS < TABLE_LEFT) {
                    b.pos.x = TABLE_LEFT + BALL_RADIUS;
                    b.vel.x = Math.abs(b.vel.x) * CUSHION_RESTITUTION;
                    bounced = true;
                }
                if (b.pos.x + BALL_RADIUS > TABLE_RIGHT) {
                    b.pos.x = TABLE_RIGHT - BALL_RADIUS;
                    b.vel.x = -Math.abs(b.vel.x) * CUSHION_RESTITUTION;
                    bounced = true;
                }
                if (b.pos.y - BALL_RADIUS < TABLE_TOP) {
                    b.pos.y = TABLE_TOP + BALL_RADIUS;
                    b.vel.y = Math.abs(b.vel.y) * CUSHION_RESTITUTION;
                    bounced = true;
                }
                if (b.pos.y + BALL_RADIUS > TABLE_BOTTOM) {
                    b.pos.y = TABLE_BOTTOM - BALL_RADIUS;
                    b.vel.y = -Math.abs(b.vel.y) * CUSHION_RESTITUTION;
                    bounced = true;
                }

                // Pocket check
                for (int p = 0; p < POCKETS.length; p++) {
                    if (b.pos.distTo(POCKETS[p]) < POCKET_RADIUS) {
                        b.pocketed = true;
                        if (b.number == 0) {
                            result.cuePocketed = true;
                        } else {
                            for (BallPathResult bpr : result.ballPaths) {
                                if (bpr.ballNumber == b.number) {
                                    bpr.pocketed = true;
                                    bpr.pocketIndex = p;
                                    result.pocketIndex = p;
                                }
                            }
                        }
                        break;
                    }
                }
            }

            // บันทึก paths
            result.cuePath.add(cue.pos.copy());
            for (int i = 0; i < simBalls.size(); i++) {
                if (i < result.ballPaths.size()) {
                    result.ballPaths.get(i).path.add(simBalls.get(i).pos.copy());
                }
            }

            if (!anyMoving) break;
        }

        // บันทึก final positions
        for (int i = 0; i < simBalls.size(); i++) {
            if (i < result.ballPaths.size()) {
                result.ballPaths.get(i).finalPos = simBalls.get(i).pos.copy();
            }
        }

        // กำหนด shot type
        if (result.collisionCount == 0) result.shotType = "MISS";
        else if (result.collisionCount > 2) result.shotType = "COMBO";
        else result.shotType = "STRAIGHT";

        return result;
    }

    // =====================================================
    //  Bank Shot Detection — หาเส้นทางชิ่งขอบ
    // =====================================================
    public static class BankShotResult {
        public List<Vec2> path;
        public Vec2 bankPoint;      // จุดที่ชนขอบ
        public int cushionIndex;    // ขอบไหน (0=ซ้าย, 1=ขวา, 2=บน, 3=ล่าง)
        public float score;         // คะแนนความเป็นไปได้
    }

    public static List<BankShotResult> findBankShots(Vec2 cuePos, Vec2 targetPos,
                                                       Vec2 pocketPos, List<Ball> balls) {
        List<BankShotResult> results = new ArrayList<>();

        // ลองทุกขอบ (4 ด้าน)
        float[][] cushions = {
            {TABLE_LEFT, 0},     // 0: ซ้าย
            {TABLE_RIGHT, 0},    // 1: ขวา
            {0, TABLE_TOP},      // 2: บน
            {0, TABLE_BOTTOM}    // 3: ล่าง
        };

        for (int c = 0; c < cushions.length; c++) {
            // คำนวณจุดสะท้อนของหลุม
            Vec2 reflectedPocket;
            if (cushions[c][0] != 0) {
                reflectedPocket = new Vec2(2 * cushions[c][0] - pocketPos.x, pocketPos.y);
            } else {
                reflectedPocket = new Vec2(pocketPos.x, 2 * cushions[c][1] - pocketPos.y);
            }

            // คำนวณทิศทางจากลูกเป้าหมายไปจุดสะท้อน
            Vec2 targetToReflected = reflectedPocket.sub(targetPos).normalized();

            // จุดที่ลูก cue ต้องกระทบลูกเป้าหมาย
            Vec2 contactPoint = targetPos.sub(targetToReflected.mul(BALL_RADIUS * 2));

            // ทิศทางจาก cue ไป contact point
            Vec2 aimDir = contactPoint.sub(cuePos).normalized();

            // จำลอง
            List<Ball> simBalls = new ArrayList<>(balls);
            FullSimResult sim = simulateFull(cuePos, aimDir, 0.5f, simBalls, false, 0, 0);

            // ตรวจว่าลูกเป้าหมายลงหลุมจริงไหม
            for (BallPathResult bpr : sim.ballPaths) {
                if (bpr.ballNumber == getTargetBallNum(targetPos, balls) && bpr.pocketed) {
                    BankShotResult bank = new BankShotResult();
                    bank.path = bpr.path;
                    bank.cushionIndex = c;
                    bank.score = 80 - c * 5; // ขอบใกล้ดีกว่า

                    // หาจุด bounce
                    for (int i = 1; i < bpr.path.size() - 1; i++) {
                        Vec2 p = bpr.path.get(i);
                        boolean nearCushion =
                            Math.abs(p.x - TABLE_LEFT) < BALL_RADIUS * 3 ||
                            Math.abs(p.x - TABLE_RIGHT) < BALL_RADIUS * 3 ||
                            Math.abs(p.y - TABLE_TOP) < BALL_RADIUS * 3 ||
                            Math.abs(p.y - TABLE_BOTTOM) < BALL_RADIUS * 3;
                        if (nearCushion) {
                            bank.bankPoint = p;
                            break;
                        }
                    }

                    results.add(bank);
                    break;
                }
            }
        }

        return results;
    }

    // =====================================================
    //  Multi-Cushion Bank Shot (3-4 cushions เหมือนในวิดีโอ)
    // =====================================================
    public static List<List<Vec2>> findMultiCushionShots(Vec2 cuePos, Vec2 targetPos,
                                                           Vec2 pocketPos, List<Ball> balls,
                                                           int maxCushions) {
        List<List<Vec2>> results = new ArrayList<>();

        // Recursive reflection method
        findReflections(cuePos, targetPos, pocketPos, balls, maxCushions,
            new ArrayList<>(), results);

        return results;
    }

    private static void findReflections(Vec2 cuePos, Vec2 targetPos, Vec2 pocketPos,
                                         List<Ball> balls, int remaining,
                                         List<Vec2> currentPath, List<List<Vec2>> results) {
        if (remaining <= 0 || currentPath.size() > 4) return;

        float[][] edges = {
            {TABLE_LEFT, 0}, {TABLE_RIGHT, 0},
            {0, TABLE_TOP}, {0, TABLE_BOTTOM}
        };

        for (float[] edge : edges) {
            Vec2 reflected;
            if (edge[0] != 0) {
                reflected = new Vec2(2 * edge[0] - pocketPos.x, pocketPos.y);
            } else {
                reflected = new Vec2(pocketPos.x, 2 * edge[1] - pocketPos.y);
            }

            // ตรวจสอบว่า reflected point อยู่บนโต๊ะ
            if (reflected.x < TABLE_LEFT || reflected.x > TABLE_RIGHT ||
                reflected.y < TABLE_TOP || reflected.y > TABLE_BOTTOM) {
                continue;
            }

            List<Vec2> path = new ArrayList<>(currentPath);
            path.add(reflected);

            // ลองจำลอง
            Vec2 aimDir = reflected.sub(cuePos).normalized();
            FullSimResult sim = simulateFull(cuePos, aimDir, 0.5f,
                new ArrayList<>(balls), false, 0, 0);

            for (BallPathResult bpr : sim.ballPaths) {
                if (bpr.ballNumber == getTargetBallNum(targetPos, balls) && bpr.pocketed) {
                    results.add(bpr.path);
                    return;
                }
            }

            // ลอง bounce ต่อ
            findReflections(cuePos, targetPos, reflected, balls,
                remaining - 1, path, results);
        }
    }

    // =====================================================
    //  Quick Sim — สำหรับ guideline (เร็ว, ไม่ละเอียด)
    // =====================================================
    public static List<Vec2> quickSim(Vec2 cuePos, Vec2 aimDir,
                                       List<Ball> balls, int maxSteps) {
        List<Vec2> path = new ArrayList<>();
        Vec2 pos = cuePos.copy();
        Vec2 vel = aimDir.normalized().mul(0.1f);
        float r = BALL_RADIUS;
        path.add(pos.copy());

        for (int i = 0; i < maxSteps; i++) {
            pos = pos.add(vel);
            vel = vel.mul(FRICTION);

            if (pos.x - r < TABLE_LEFT)  { pos.x = TABLE_LEFT + r;  vel.x = -vel.x * CUSHION_RESTITUTION; }
            if (pos.x + r > TABLE_RIGHT) { pos.x = TABLE_RIGHT - r; vel.x = -vel.x * CUSHION_RESTITUTION; }
            if (pos.y - r < TABLE_TOP)   { pos.y = TABLE_TOP + r;   vel.y = -vel.y * CUSHION_RESTITUTION; }
            if (pos.y + r > TABLE_BOTTOM){ pos.y = TABLE_BOTTOM - r;vel.y = -vel.y * CUSHION_RESTITUTION; }

            boolean hit = false;
            for (Ball b : balls) {
                if (b.isCue() || b.pocketed) continue;
                if (pos.distTo(b.pos) < r * 2) { hit = true; break; }
            }
            if (hit) break;

            boolean pocketed = false;
            for (Vec2 pocket : POCKETS) {
                if (pos.distTo(pocket) < POCKET_RADIUS) { pocketed = true; break; }
            }
            if (pocketed) break;

            path.add(pos.copy());
            if (vel.length() < MIN_VELOCITY) break;
        }
        return path;
    }

    // === Helper ===
    private static int getTargetBallNum(Vec2 targetPos, List<Ball> balls) {
        for (Ball b : balls) {
            if (b.pos.distTo(targetPos) < 0.05f) return b.number;
        }
        return -1;
    }

    // === SimBall (ลูกจำลอง) ===
    private static class SimBall {
        int number;
        Vec2 pos, vel;
        float sideSpin, topSpin;
        boolean pocketed;

        SimBall(Ball b) {
            this.number = b.number;
            this.pos = b.pos.copy();
            this.vel = new Vec2();
        }
    }
}
