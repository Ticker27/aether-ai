# Aether AI ProGuard Rules
-keepattributes *Annotation*
-keep class com.aether.** { *; }
