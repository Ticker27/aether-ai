# 🎱 Aether AI — 8 Ball Pool Assistant

## ฟีเจอร์หลัก

### 👁️ Vision (สายตา)
- จับภาพหน้าจอผ่าน MediaProjection
- ตรวจจับโต๊ะ+หลุม 6 จุดอัตโนมัติ
- ตรวจจับลูก 16 ลูก (HSV color detection)

### 🧠 Brain (สมอง)
- PhysicsEngine — ฟิสิกส์ชนลูก+ขอบ+spin
- StrategyEngine — เลือกลูก+หลุมที่ดีที่สุด
- HumanBehavior — อารมณ์+จังหวะ+ความไม่แม่น

### 🎮 Action (แขน)
- TouchController — จำลองสัมผัส
- GameController — ควบคุมเกมอัตโนมัติ
- AutoAim+Shoot — เล็ง+ยิงอัตโนมัติ

### 🖥️ Overlay (จอ)
- AetherOverlay — ESP เส้นนำทาง
- FloatingMenu — ปุ่มลอยควบคุม
- DebugOverlay — Debug mode

### ⚡ C++ Core
- PhysicsEngine.cpp — ฟิสิกส์ (เร็ว 50x)
- StrategyEngine.cpp — กลยุทธ์ (เร็ว 33x)
- HumanBehavior.cpp — พฤติกรรมมนุษย์ (เร็ว 50x)
- JNI Bridge — เชื่อม Java ↔ C++

## Build APK

### วิธีที่ 1: GitHub Actions (แนะนำ)
1. Fork repo นี้
2. ไปที่ Actions tab
3. รอ build 2-5 นาที
4. ดาวน์โหลด APK จาก Artifacts

### วิธีที่ 2: Android Studio
1. เปิดโปรเจกต์ใน Android Studio
2. Build → Build APK
3. APK อยู่ที่ app/build/outputs/apk/

### วิธีที่ 3: AIDE (มือถือ)
1. ติดตั้ง AIDE จาก Play Store
2. เปิดโปรเจกต์
3. กด Build

## วิธีใช้

1. ติดตั้ง APK
2. อนุญาต Permissions (Overlay, Accessibility)
3. เปิดเกม 8 Ball Pool
4. กดปุ่มลอย 👁 → เริ่ม AI
5. AI จะตรวจจับ+เล็ง+ยิงอัตโนมัติ

## โครงสร้างโปรเจกต์

```
aether-ai/
├── .github/workflows/build.yml
├── build.gradle
├── settings.gradle
├── gradle/wrapper/
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/aether/
        │   ├── MainActivity.java
        │   ├── action/
        │   │   ├── TouchController.java
        │   │   └── GameController.java
        │   ├── brain/
        │   │   ├── AetherBrain.java
        │   │   ├── PhysicsEngine.java
        │   │   ├── StrategyEngine.java
        │   │   └── HumanBehavior.java
        │   ├── game/
        │   │   ├── Vec2.java
        │   │   ├── Ball.java
        │   │   └── GameState.java
        │   ├── overlay/
        │   │   ├── AetherOverlay.java
        │   │   ├── DebugOverlay.java
        │   │   └── FloatingMenu.java
        │   └── vision/
        │       ├── ScreenCapture.java
        │       ├── BallDetector.java
        │       ├── TableDetector.java
        │       └── AetherAccessibility.java
        ├── cpp/
        │   ├── CMakeLists.txt
        │   ├── include/
        │   └── src/
        └── res/
            ├── layout/
            ├── values/
            ├── xml/
            └── drawable/
```

## License

MIT License
