#pragma once
#include "Vec2.h"

namespace aether {

enum class BallType { CUE, SOLID, STRIPE, EIGHT };

struct Ball {
    int number = 0;
    Vec2 pos;
    Vec2 vel;
    Vec2 spin;
    float radius = 0.025f;
    bool pocketed = false;
    bool visible = true;

    Ball() = default;
    Ball(int num, Vec2 p) : number(num), pos(p) {}

    bool isCue() const { return number == 0; }
    bool isEight() const { return number == 8; }
    bool isSolid() const { return number >= 1 && number <= 7; }
    bool isStripe() const { return number >= 9 && number <= 15; }
    bool isMoving() const { return vel.length() > 0.001f; }

    BallType getType() const {
        if (number == 0) return BallType::CUE;
        if (number == 8) return BallType::EIGHT;
        if (number <= 7) return BallType::SOLID;
        return BallType::STRIPE;
    }
};

} // namespace aether
