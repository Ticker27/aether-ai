#pragma once
#include <cmath>

namespace aether {

struct Vec2 {
    float x = 0.f, y = 0.f;

    Vec2() = default;
    Vec2(float x, float y) : x(x), y(y) {}

    Vec2 operator+(const Vec2& o) const { return {x + o.x, y + o.y}; }
    Vec2 operator-(const Vec2& o) const { return {x - o.x, y - o.y}; }
    Vec2 operator*(float s) const { return {x * s, y * s}; }
    Vec2 operator/(float s) const { return {x / s, y / s}; }
    Vec2& operator+=(const Vec2& o) { x += o.x; y += o.y; return *this; }
    Vec2& operator-=(const Vec2& o) { x -= o.x; y -= o.y; return *this; }
    Vec2& operator*=(float s) { x *= s; y *= s; return *this; }

    float dot(const Vec2& o) const { return x * o.x + y * o.y; }
    float cross(const Vec2& o) const { return x * o.y - y * o.x; }
    float length() const { return std::sqrt(x * x + y * y); }
    float lengthSq() const { return x * x + y * y; }
    float distTo(const Vec2& o) const { return (*this - o).length(); }

    Vec2 normalized() const {
        float l = length();
        return l > 0 ? *this / l : Vec2{0, 0};
    }

    Vec2 perpendicular() const { return {-y, x}; }

    Vec2 reflect(const Vec2& n) const {
        return *this - n * (2.f * dot(n));
    }

    Vec2 rotated(float rad) const {
        float c = std::cos(rad), s = std::sin(rad);
        return {x * c - y * s, x * s + y * c};
    }
};

} // namespace aether
