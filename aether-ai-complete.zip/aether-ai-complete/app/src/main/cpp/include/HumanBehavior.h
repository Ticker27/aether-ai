#pragma once
#include "Vec2.h"
#include "StrategyEngine.h"
#include <random>

namespace aether {

enum class PlayStyle { AGGRESSIVE, DEFENSIVE, BALANCED, SHOWOFF, CAUTIOUS };
enum class Mood { CONFIDENT, NERVOUS, FOCUSED, FRUSTRATED, RELAXED };

class HumanBehavior {
public:
    HumanBehavior();

    void setPlayStyle(PlayStyle style);
    void updateMood(bool madeLastShot, bool isWinning, int ballsRemaining, bool isBreak);

    long calculateThinkTime(const ShotOption& shot);
    float adjustAngle(float angle);
    float adjustPower(float power);
    bool shouldTakeShot(const ShotOption& shot);
    bool willMakeShot(const ShotOption& shot);
    float calculateAccuracy();

    PlayStyle suggestStyle(int myBallsLeft, int oppBallsLeft, bool isBreak);

    Mood getMood() const { return mood; }
    PlayStyle getStyle() const { return style; }

    int getShotsTaken() const { return shotsTaken; }
    int getShotsMade() const { return shotsMade; }

private:
    PlayStyle style = PlayStyle::BALANCED;
    Mood mood = Mood::RELAXED;
    std::mt19937 rng;

    int shotsTaken = 0;
    int shotsMade = 0;
    int consecutiveMisses = 0;
    int consecutiveMakes = 0;

    float personalityFactor;
    float patienceFactor;
    float riskTolerance;

    float calculateDifficulty(const ShotOption& shot);
};

} // namespace aether
