#pragma once
#include "Vec2.h"
#include "Ball.h"
#include <vector>

namespace aether {

// ผลลัพธ์การจำลอง
struct SimResult {
    std::vector<Vec2> cuePath;
    std::vector<Vec2> targetPath;
    bool targetPocketed = false;
    bool cuePocketed = false;
    int pocketIndex = -1;
    Vec2 finalCuePos;
    int collisionCount = 0;
};

// ผลลัพธ์แบบเต็ม (ทุกลูก)
struct BallPathResult {
    int ballNumber;
    std::vector<Vec2> path;
    bool pocketed = false;
    int pocketIndex = -1;
    Vec2 finalPos;
};

struct FullSimResult {
    std::vector<Vec2> cuePath;
    bool cuePocketed = false;
    std::vector<BallPathResult> ballPaths;
    Vec2 impactPoint;
    int targetBallNum = -1;
    int pocketIndex = -1;
    int collisionCount = 0;
    const char* shotType = "STRAIGHT";
};

class PhysicsEngine {
public:
    // ค่าคงที่
    static constexpr float BALL_RADIUS = 0.025f;
    static constexpr float TABLE_LEFT = 0.05f;
    static constexpr float TABLE_RIGHT = 0.95f;
    static constexpr float TABLE_TOP = 0.05f;
    static constexpr float TABLE_BOTTOM = 0.95f;
    static constexpr float POCKET_RADIUS = 0.04f;
    static constexpr float CUSHION_RESTITUTION = 0.82f;
    static constexpr float BALL_RESTITUTION = 0.95f;
    static constexpr float FRICTION = 0.985f;
    static constexpr float SPIN_DECAY = 0.98f;
    static constexpr float MIN_VELOCITY = 0.0003f;
    static constexpr int MAX_SIM_STEPS = 800;

    // หลุม 6 จุด
    static const Vec2 POCKETS[6];

    // จำลองแบบเต็ม
    static FullSimResult simulateFull(Vec2 cuePos, Vec2 aimDir, float power,
                                       const std::vector<Ball>& balls,
                                       bool hasSpin = false,
                                       float sideSpin = 0.f,
                                       float topSpin = 0.f);

    // จำลองแบบเร็ว (สำหคับ guideline)
    static std::vector<Vec2> quickSim(Vec2 cuePos, Vec2 aimDir,
                                       const std::vector<Ball>& balls,
                                       int maxSteps = 200);

private:
    // ลูกจำ模拟
    struct SimBall {
        int number;
        Vec2 pos, vel;
        float sideSpin = 0.f, topSpin = 0.f;
        bool pocketed = false;

        SimBall(const Ball& b) : number(b.number), pos(b.pos) {}
    };

    static void handleBallCollision(SimBall& a, SimBall& b, int& collisionCount,
                                     Vec2& impactPoint, int& targetBallNum);
    static void handleCushionCollision(SimBall& b);
    static bool checkPocket(SimBall& b, int& pocketIndex);
};

} // namespace aether
