#pragma once
#include "Vec2.h"
#include "Ball.h"
#include "PhysicsEngine.h"
#include <vector>

namespace aether {

struct ShotOption {
    int targetBallNum = -1;
    Vec2 aimDir;
    Vec2 pocketTarget;
    float power = 0.5f;
    float score = 0.f;
    float angle = 0.f;
    bool isBankShot = false;
    int bankCount = 0;
    float sideSpin = 0.f;
    float topSpin = 0.f;
    const char* shotType = "STRAIGHT";
    FullSimResult simResult;
};

class StrategyEngine {
public:
    // หา shot ที่ดีที่สุด
    static ShotOption findBestShot(Vec2 cuePos, const std::vector<Ball>& myBalls,
                                    const std::vector<Ball>& allBalls,
                                    int myType = 0);

private:
    // วิเคราะห์ shot ตรง
    static ShotOption analyzeStraightShot(Vec2 cuePos, const Ball& target,
                                           Vec2 pocket, const std::vector<Ball>& allBalls);

    // วิเคราะห์ bank shot
    static ShotOption analyzeBankShot(Vec2 cuePos, const Ball& target,
                                       Vec2 pocket, const std::vector<Ball>& allBalls);

    // ตั้งรับ
    static ShotOption defensiveShot(Vec2 cuePos);

    // แนะนำ spin
    static void recommendSpin(ShotOption& shot, Vec2 cuePos, Vec2 targetPos, Vec2 pocket);

    // นับลูกขวาง
    static int countBlockers(Vec2 from, Vec2 to, const std::vector<Ball>& balls);

    // คำนวณแรง
    static float calculatePower(float dist, float cutAngle);
};

} // namespace aether
