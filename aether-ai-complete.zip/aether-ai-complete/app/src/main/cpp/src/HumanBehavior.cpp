#include "HumanBehavior.h"
#include <cmath>
#include <algorithm>

namespace aether {

HumanBehavior::HumanBehavior() : rng(std::random_device{}()) {
    std::uniform_real_distribution<float> dist(0.f, 1.f);
    personalityFactor = 0.3f + dist(rng) * 0.5f;
    patienceFactor = 0.2f + dist(rng) * 0.6f;
    riskTolerance = 0.2f + dist(rng) * 0.5f;
}

void HumanBehavior::setPlayStyle(PlayStyle s) {
    style = s;
    switch (s) {
        case PlayStyle::AGGRESSIVE:
            riskTolerance = std::min(1.f, riskTolerance + 0.2f);
            patienceFactor = std::max(0.f, patienceFactor - 0.2f);
            break;
        case PlayStyle::DEFENSIVE:
            riskTolerance = std::max(0.f, riskTolerance - 0.2f);
            patienceFactor = std::min(1.f, patienceFactor + 0.2f);
            break;
        case PlayStyle::SHOWOFF:
            riskTolerance = std::min(1.f, riskTolerance + 0.3f);
            break;
        case PlayStyle::CAUTIOUS:
            patienceFactor = std::min(1.f, patienceFactor + 0.3f);
            break;
        default: break;
    }
}

void HumanBehavior::updateMood(bool madeLastShot, bool isWinning,
                                 int ballsRemaining, bool isBreak) {
    if (madeLastShot) {
        consecutiveMakes++;
        consecutiveMisses = 0;
        if (consecutiveMakes >= 3) mood = Mood::CONFIDENT;
        else if (consecutiveMakes >= 2) mood = Mood::FOCUSED;
    } else {
        consecutiveMisses++;
        consecutiveMakes = 0;
        if (consecutiveMisses >= 3) mood = Mood::FRUSTRATED;
        else if (consecutiveMisses >= 2) mood = Mood::NERVOUS;
        else mood = Mood::FOCUSED;
    }

    if (ballsRemaining <= 2 && isWinning) mood = Mood::NERVOUS;
    if (isBreak) mood = Mood::RELAXED;
}

long HumanBehavior::calculateThinkTime(const ShotOption& shot) {
    float difficulty = calculateDifficulty(shot);
    long baseTime;

    switch (mood) {
        case Mood::CONFIDENT:  baseTime = 500 + (long)(difficulty * 1000); break;
        case Mood::NERVOUS:    baseTime = 500 + (long)(difficulty * 2500); break;
        case Mood::FOCUSED:    baseTime = 500 + (long)(difficulty * 1500); break;
        case Mood::FRUSTRATED: baseTime = 500 + (long)(difficulty * 500);  break;
        default:               baseTime = 500 + (long)(difficulty * 2000); break;
    }

    switch (style) {
        case PlayStyle::AGGRESSIVE: baseTime = (long)(baseTime * 0.6f); break;
        case PlayStyle::CAUTIOUS:   baseTime = (long)(baseTime * 1.5f); break;
        case PlayStyle::SHOWOFF:    baseTime = (long)(baseTime * 0.8f); break;
        default: break;
    }

    baseTime = (long)(baseTime * (0.5f + patienceFactor));

    std::uniform_real_distribution<float> jitter(0.8f, 1.2f);
    baseTime = (long)(baseTime * jitter(rng));

    return std::max(500L, std::min(5000L, baseTime));
}

float HumanBehavior::adjustAngle(float angle) {
    float noise = 3.0f;  // degrees

    switch (mood) {
        case Mood::CONFIDENT:  noise *= 0.5f; break;
        case Mood::NERVOUS:    noise *= 1.5f; break;
        case Mood::FRUSTRATED: noise *= 1.3f; break;
        case Mood::FOCUSED:    noise *= 0.7f; break;
        default: break;
    }

    noise *= (1.0f - personalityFactor * 0.5f);

    std::uniform_real_distribution<float> dist(-noise, noise);
    float adjustment = dist(rng) * (3.14159f / 180.f);  // to radians

    // 30% chance no adjustment
    std::uniform_real_distribution<float> coinFlip(0.f, 1.f);
    if (coinFlip(rng) < 0.3f) adjustment = 0;

    return angle + adjustment;
}

float HumanBehavior::adjustPower(float power) {
    float noise = 0.08f;

    switch (mood) {
        case Mood::CONFIDENT:  noise *= 0.6f; break;
        case Mood::NERVOUS:    noise *= 1.4f; break;
        case Mood::FRUSTRATED: noise *= 1.2f; break;
        default: break;
    }

    std::uniform_real_distribution<float> dist(-noise, noise);
    float adjustment = dist(rng);

    std::uniform_real_distribution<float> coinFlip(0.f, 1.f);
    if (coinFlip(rng) < 0.4f) adjustment = 0;

    return std::max(0.1f, std::min(1.f, power + adjustment));
}

bool HumanBehavior::shouldTakeShot(const ShotOption& shot) {
    float difficulty = calculateDifficulty(shot);

    if (difficulty > 0.8f) {
        float chance = 0.3f + riskTolerance * 0.5f;
        std::uniform_real_distribution<float> dist(0.f, 1.f);
        if (dist(rng) > chance) return false;
    }

    if (mood == Mood::FRUSTRATED) return true;

    if (style == PlayStyle::CAUTIOUS && difficulty > 0.6f) {
        std::uniform_real_distribution<float> dist(0.f, 1.f);
        if (dist(rng) < 0.4f) return false;
    }

    return true;
}

bool HumanBehavior::willMakeShot(const ShotOption& shot) {
    float accuracy = calculateAccuracy();
    float difficulty = calculateDifficulty(shot);
    float successChance = accuracy * (1.f - difficulty * 0.5f);

    std::uniform_real_distribution<float> dist(0.f, 1.f);
    bool made = dist(rng) < successChance;

    shotsTaken++;
    if (made) shotsMade++;

    return made;
}

float HumanBehavior::calculateAccuracy() {
    float accuracy = 0.85f;

    switch (mood) {
        case Mood::CONFIDENT:  accuracy += 0.08f; break;
        case Mood::NERVOUS:    accuracy -= 0.10f; break;
        case Mood::FOCUSED:    accuracy += 0.05f; break;
        case Mood::FRUSTRATED: accuracy -= 0.15f; break;
        case Mood::RELAXED:    accuracy += 0.02f; break;
    }

    if (consecutiveMakes >= 3) accuracy += 0.05f;
    if (consecutiveMisses >= 2) accuracy -= 0.08f;

    accuracy += (personalityFactor - 0.5f) * 0.1f;

    return std::max(0.60f, std::min(0.95f, accuracy));
}

float HumanBehavior::calculateDifficulty(const ShotOption& shot) {
    float difficulty = 0.3f;

    if (shot.angle != 0) {
        float angleDeg = std::abs(shot.angle * 180.f / 3.14159f);
        float cutAngle = std::fmod(angleDeg, 90.f);
        difficulty += (cutAngle / 90.f) * 0.3f;
    }

    difficulty += shot.power * 0.2f;

    if (shot.isBankShot) {
        difficulty += 0.2f;
        difficulty += shot.bankCount * 0.1f;
    }

    if (std::abs(shot.sideSpin) > 0.1f || std::abs(shot.topSpin) > 0.1f) {
        difficulty += 0.1f;
    }

    return std::min(1.f, difficulty);
}

PlayStyle HumanBehavior::suggestStyle(int myBallsLeft, int oppBallsLeft, bool isBreak) {
    if (isBreak) return PlayStyle::AGGRESSIVE;
    if (myBallsLeft < oppBallsLeft - 2) return PlayStyle::DEFENSIVE;
    if (myBallsLeft > oppBallsLeft + 2) return PlayStyle::AGGRESSIVE;
    return PlayStyle::BALANCED;
}

} // namespace aether
