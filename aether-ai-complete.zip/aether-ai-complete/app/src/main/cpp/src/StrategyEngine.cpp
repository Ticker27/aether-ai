#include "StrategyEngine.h"
#include <cmath>
#include <algorithm>

namespace aether {

ShotOption StrategyEngine::findBestShot(Vec2 cuePos, const std::vector<Ball>& myBalls,
                                          const std::vector<Ball>& allBalls, int myType) {
    if (myBalls.empty()) return defensiveShot(cuePos);

    std::vector<ShotOption> allShots;

    // ลองทุก combination: ลูก x หลุม
    for (const auto& target : myBalls) {
        for (int p = 0; p < 6; ++p) {
            // Shot ตรง
            ShotOption shot = analyzeStraightShot(cuePos, target,
                PhysicsEngine::POCKETS[p], allBalls);
            if (shot.score > 0) allShots.push_back(shot);

            // Bank shot
            ShotOption bankShot = analyzeBankShot(cuePos, target,
                PhysicsEngine::POCKETS[p], allBalls);
            if (bankShot.score > 0) allShots.push_back(bankShot);
        }
    }

    if (allShots.empty()) return defensiveShot(cuePos);

    // เรียงตามคะแนน
    std::sort(allShots.begin(), allShots.end(),
        [](const ShotOption& a, const ShotOption& b) {
            return a.score > b.score;
        });

    return allShots[0];
}

ShotOption StrategyEngine::analyzeStraightShot(Vec2 cuePos, const Ball& target,
                                                  Vec2 pocket, const std::vector<Ball>& allBalls) {
    ShotOption shot;
    shot.targetBallNum = target.number;

    Vec2 targetToPocket = (pocket - target.pos).normalized();
    Vec2 contactPoint = target.pos - targetToPocket * (PhysicsEngine::BALL_RADIUS * 2);
    shot.aimDir = (contactPoint - cuePos).normalized();

    shot.angle = std::atan2(shot.aimDir.y, shot.aimDir.x);
    float targetAngle = std::atan2(targetToPocket.y, targetToPocket.x);
    float cutAngle = std::abs(shot.angle - targetAngle);

    if (cutAngle > 1.4f) { shot.score = 0; return shot; }

    // จำ模拟
    shot.simResult = PhysicsEngine::simulateFull(cuePos, shot.aimDir, 0.5f, allBalls);

    // ตรวจว่าลูกเป้าหมายลงหลุม
    bool targetPocketed = false;
    for (const auto& bpr : shot.simResult.ballPaths) {
        if (bpr.ballNumber == target.number && bpr.pocketed) {
            targetPocketed = true;
            shot.pocketTarget = PhysicsEngine::POCKETS[bpr.pocketIndex];
            break;
        }
    }

    if (!targetPocketed || shot.simResult.cuePocketed) {
        shot.score = 0;
        return shot;
    }

    // คำนวณคะแนน
    float score = 100;
    score -= cutAngle * 30;
    score -= cuePos.distTo(target.pos) * 20;

    Vec2 finalCue = shot.simResult.cuePath.empty() ? Vec2{0.5f, 0.5f} :
                    shot.simResult.cuePath.back();
    score += (1 - finalCue.distTo({0.5f, 0.5f})) * 10;

    int blockers = countBlockers(cuePos, contactPoint, allBalls);
    score -= blockers * 15;

    shot.power = calculatePower(cuePos.distTo(target.pos), cutAngle);
    shot.score = score;
    shot.shotType = "STRAIGHT";

    recommendSpin(shot, cuePos, target.pos, pocket);
    return shot;
}

ShotOption StrategyEngine::analyzeBankShot(Vec2 cuePos, const Ball& target,
                                             Vec2 pocket, const std::vector<Ball>& allBalls) {
    ShotOption shot;
    shot.score = 0;

    // ลองขอบ 4 ด้าน
    float cushions[4][2] = {
        {PhysicsEngine::TABLE_LEFT, 0},
        {PhysicsEngine::TABLE_RIGHT, 0},
        {0, PhysicsEngine::TABLE_TOP},
        {0, PhysicsEngine::TABLE_BOTTOM}
    };

    for (int c = 0; c < 4; ++c) {
        Vec2 reflectedPocket;
        if (cushions[c][0] != 0) {
            reflectedPocket = {2 * cushions[c][0] - pocket.x, pocket.y};
        } else {
            reflectedPocket = {pocket.x, 2 * cushions[c][1] - pocket.y};
        }

        Vec2 targetToReflected = (reflectedPocket - target.pos).normalized();
        Vec2 contactPoint = target.pos - targetToReflected * (PhysicsEngine::BALL_RADIUS * 2);
        Vec2 aimDir = (contactPoint - cuePos).normalized();

        auto sim = PhysicsEngine::simulateFull(cuePos, aimDir, 0.5f, allBalls);

        for (const auto& bpr : sim.ballPaths) {
            if (bpr.ballNumber == target.number && bpr.pocketed) {
                float score = 80 - c * 5;
                float dist = cuePos.distTo(target.pos);
                score -= dist * 15;

                if (score > shot.score) {
                    shot.targetBallNum = target.number;
                    shot.aimDir = aimDir;
                    shot.pocketTarget = PhysicsEngine::POCKETS[bpr.pocketIndex];
                    shot.score = score;
                    shot.angle = std::atan2(aimDir.y, aimDir.x);
                    shot.power = calculatePower(dist, 0.3f);
                    shot.isBankShot = true;
                    shot.bankCount = 1;
                    shot.shotType = "BANK";
                    shot.simResult = sim;
                }
                break;
            }
        }
    }

    return shot;
}

ShotOption StrategyEngine::defensiveShot(Vec2 cuePos) {
    ShotOption shot;
    shot.targetBallNum = -1;
    shot.aimDir = (Vec2{0.5f, 0.5f} - cuePos).normalized();
    shot.power = 0.3f;
    shot.score = 20;
    shot.angle = std::atan2(shot.aimDir.y, shot.aimDir.x);
    shot.shotType = "DEFENSIVE";
    return shot;
}

void StrategyEngine::recommendSpin(ShotOption& shot, Vec2 cuePos, Vec2 targetPos, Vec2 pocket) {
    Vec2 cueToTarget = (targetPos - cuePos).normalized();
    Vec2 targetToPocket = (pocket - targetPos).normalized();
    float cross = cueToTarget.cross(targetToPocket);

    if (cross > 0.1f) shot.sideSpin = 0.3f;
    else if (cross < -0.1f) shot.sideSpin = -0.3f;

    float dist = cuePos.distTo(targetPos);
    if (dist > 0.4f) shot.topSpin = 0.5f;
    else shot.topSpin = -0.3f;
}

int StrategyEngine::countBlockers(Vec2 from, Vec2 to, const std::vector<Ball>& balls) {
    int count = 0;
    Vec2 dir = (to - from).normalized();
    float dist = from.distTo(to);

    for (const auto& b : balls) {
        if (b.isCue() || b.pocketed) continue;
        Vec2 toBall = b.pos - from;
        float proj = toBall.dot(dir);
        if (proj < 0 || proj > dist) continue;
        float perpDist = (toBall - dir * proj).length();
        if (perpDist < PhysicsEngine::BALL_RADIUS * 3) count++;
    }
    return count;
}

float StrategyEngine::calculatePower(float dist, float cutAngle) {
    return std::min(1.f, 0.3f + dist * 0.8f + cutAngle * 0.2f);
}

} // namespace aether
