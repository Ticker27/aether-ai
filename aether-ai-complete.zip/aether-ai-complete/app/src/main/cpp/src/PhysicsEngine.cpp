#include "PhysicsEngine.h"
#include <cmath>
#include <algorithm>

namespace aether {

const Vec2 PhysicsEngine::POCKETS[6] = {
    {TABLE_LEFT, TABLE_TOP},
    {0.5f, TABLE_TOP - 0.01f},
    {TABLE_RIGHT, TABLE_TOP},
    {TABLE_LEFT, TABLE_BOTTOM},
    {0.5f, TABLE_BOTTOM + 0.01f},
    {TABLE_RIGHT, TABLE_BOTTOM}
};

FullSimResult PhysicsEngine::simulateFull(Vec2 cuePos, Vec2 aimDir, float power,
                                            const std::vector<Ball>& balls,
                                            bool hasSpin, float sideSpin, float topSpin) {
    FullSimResult result;

    // สร้างลูกจำ模拟
    std::vector<SimBall> simBalls;
    simBalls.reserve(balls.size());
    for (const auto& b : balls) {
        simBalls.emplace_back(b);
    }

    // หาลูก cue
    SimBall* cue = nullptr;
    for (auto& b : simBalls) {
        if (b.number == 0) { cue = &b; break; }
    }
    if (!cue) return result;

    // ตั้งค่าเริ่มต้น
    float speed = power * 0.18f;
    cue->vel = aimDir.normalized() * speed;
    cue->sideSpin = hasSpin ? sideSpin : 0.f;
    cue->topSpin = hasSpin ? topSpin : 0.f;

    // Top spin effect
    if (cue->topSpin > 0) cue->vel = cue->vel * (1 + cue->topSpin * 0.2f);
    if (cue->topSpin < 0) cue->vel = cue->vel * (1 + cue->topSpin * 0.15f);

    // เก็บ path เริ่มต้น
    result.cuePath.push_back(cue->pos);

    // สร้าง BallPathResult
    for (const auto& b : simBalls) {
        BallPathResult bpr;
        bpr.ballNumber = b.number;
        bpr.path.push_back(b.pos);
        result.ballPaths.push_back(bpr);
    }

    // === จำลอง ===
    for (int step = 0; step < MAX_SIM_STEPS; ++step) {
        bool anyMoving = false;

        // อัปเดตตำแหน่ง
        for (auto& b : simBalls) {
            if (b.pocketed) continue;

            b.pos = b.pos + b.vel;
            b.vel = b.vel * FRICTION;
            b.sideSpin *= SPIN_DECAY;
            b.topSpin *= SPIN_DECAY;

            // Side spin effect
            if (std::abs(b.sideSpin) > 0.01f && b.vel.length() > MIN_VELOCITY) {
                Vec2 perp = b.vel.normalized().perpendicular();
                b.vel = b.vel + perp * (b.sideSpin * 0.0008f);
            }

            if (b.vel.length() < MIN_VELOCITY) {
                b.vel = {0, 0};
            } else {
                anyMoving = true;
            }
        }

        // ตรวจชนลูก vs ลูก
        for (size_t i = 0; i < simBalls.size(); ++i) {
            for (size_t j = i + 1; j < simBalls.size(); ++j) {
                if (simBalls[i].pocketed || simBalls[j].pocketed) continue;
                handleBallCollision(simBalls[i], simBalls[j],
                                    result.collisionCount, result.impactPoint,
                                    result.targetBallNum);
            }
        }

        // ตรวจชนขอบ + ลงหลุม
        for (auto& b : simBalls) {
            if (b.pocketed) continue;
            handleCushionCollision(b);

            int pIdx = -1;
            if (checkPocket(b, pIdx)) {
                if (b.number == 0) {
                    result.cuePocketed = true;
                } else {
                    result.pocketIndex = pIdx;
                    for (auto& bpr : result.ballPaths) {
                        if (bpr.ballNumber == b.number) {
                            bpr.pocketed = true;
                            bpr.pocketIndex = pIdx;
                        }
                    }
                }
            }
        }

        // บันทึก paths
        result.cuePath.push_back(cue->pos);
        for (size_t i = 0; i < simBalls.size() && i < result.ballPaths.size(); ++i) {
            result.ballPaths[i].path.push_back(simBalls[i].pos);
        }

        if (!anyMoving) break;
    }

    // บันทึก final positions
    for (size_t i = 0; i < simBalls.size() && i < result.ballPaths.size(); ++i) {
        result.ballPaths[i].finalPos = simBalls[i].pos;
    }

    // กำหนด shot type
    if (result.collisionCount == 0) result.shotType = "MISS";
    else if (result.collisionCount > 2) result.shotType = "COMBO";
    else result.shotType = "STRAIGHT";

    return result;
}

std::vector<Vec2> PhysicsEngine::quickSim(Vec2 cuePos, Vec2 aimDir,
                                            const std::vector<Ball>& balls,
                                            int maxSteps) {
    std::vector<Vec2> path;
    Vec2 pos = cuePos;
    Vec2 vel = aimDir.normalized() * 0.1f;
    float r = BALL_RADIUS;

    path.push_back(pos);

    for (int i = 0; i < maxSteps; ++i) {
        pos = pos + vel;
        vel = vel * FRICTION;

        // Cushion
        if (pos.x - r < TABLE_LEFT)  { pos.x = TABLE_LEFT + r;  vel.x = -vel.x * CUSHION_RESTITUTION; }
        if (pos.x + r > TABLE_RIGHT) { pos.x = TABLE_RIGHT - r; vel.x = -vel.x * CUSHION_RESTITUTION; }
        if (pos.y - r < TABLE_TOP)   { pos.y = TABLE_TOP + r;   vel.y = -vel.y * CUSHION_RESTITUTION; }
        if (pos.y + r > TABLE_BOTTOM){ pos.y = TABLE_BOTTOM - r;vel.y = -vel.y * CUSHION_RESTITUTION; }

        // ตรวจชนลูก
        bool hit = false;
        for (const auto& b : balls) {
            if (b.isCue() || b.pocketed) continue;
            if (pos.distTo(b.pos) < r * 2) { hit = true; break; }
        }
        if (hit) break;

        // ตรวจหลุม
        bool pocketed = false;
        for (const auto& p : POCKETS) {
            if (pos.distTo(p) < POCKET_RADIUS) { pocketed = true; break; }
        }
        if (pocketed) break;

        path.push_back(pos);
        if (vel.length() < MIN_VELOCITY) break;
    }

    return path;
}

void PhysicsEngine::handleBallCollision(SimBall& a, SimBall& b, int& collisionCount,
                                          Vec2& impactPoint, int& targetBallNum) {
    Vec2 diff = b.pos - a.pos;
    float dist = diff.length();
    float minDist = BALL_RADIUS * 2;

    if (dist >= minDist || dist < 0.0001f) return;

    Vec2 normal = diff.normalized();
    float overlap = minDist - dist;
    a.pos = a.pos - normal * (overlap / 2);
    b.pos = b.pos + normal * (overlap / 2);

    Vec2 relVel = a.vel - b.vel;
    float velNorm = relVel.dot(normal);
    if (velNorm <= 0) return;

    float j = -(1 + BALL_RESTITUTION) * velNorm / 2;
    Vec2 impulse = normal * j;
    a.vel = a.vel + impulse;
    b.vel = b.vel - impulse;

    // Spin transfer
    b.sideSpin += a.sideSpin * 0.1f;

    collisionCount++;

    if (a.number == 0 || b.number == 0) {
        impactPoint = (a.number == 0 ? a.pos : b.pos) + normal * BALL_RADIUS;
        targetBallNum = (a.number == 0) ? b.number : a.number;
    }
}

void PhysicsEngine::handleCushionCollision(SimBall& b) {
    float r = BALL_RADIUS;

    if (b.pos.x - r < TABLE_LEFT) {
        b.pos.x = TABLE_LEFT + r;
        b.vel.x = std::abs(b.vel.x) * CUSHION_RESTITUTION;
        b.sideSpin *= 0.7f;
    }
    if (b.pos.x + r > TABLE_RIGHT) {
        b.pos.x = TABLE_RIGHT - r;
        b.vel.x = -std::abs(b.vel.x) * CUSHION_RESTITUTION;
        b.sideSpin *= 0.7f;
    }
    if (b.pos.y - r < TABLE_TOP) {
        b.pos.y = TABLE_TOP + r;
        b.vel.y = std::abs(b.vel.y) * CUSHION_RESTITUTION;
        b.sideSpin *= 0.7f;
    }
    if (b.pos.y + r > TABLE_BOTTOM) {
        b.pos.y = TABLE_BOTTOM - r;
        b.vel.y = -std::abs(b.vel.y) * CUSHION_RESTITUTION;
        b.sideSpin *= 0.7f;
    }
}

bool PhysicsEngine::checkPocket(SimBall& b, int& pocketIndex) {
    for (int i = 0; i < 6; ++i) {
        if (b.pos.distTo(POCKETS[i]) < POCKET_RADIUS) {
            b.pocketed = true;
            pocketIndex = i;
            return true;
        }
    }
    return false;
}

} // namespace aether
