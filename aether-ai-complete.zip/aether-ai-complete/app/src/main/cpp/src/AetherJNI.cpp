#include <jni.h>
#include <vector>
#include "PhysicsEngine.h"
#include "StrategyEngine.h"
#include "HumanBehavior.h"

using namespace aether;

// === Helper: Java Vec2 → C++ Vec2 ===
static Vec2 jVec2(JNIEnv* env, jobject vec2) {
    jclass cls = env->GetObjectClass(vec2);
    jfieldID xField = env->GetFieldID(cls, "x", "F");
    jfieldID yField = env->GetFieldID(cls, "y", "F");
    return {env->GetFloatField(vec2, xField), env->GetFloatField(vec2, yField)};
}

// === Helper: C++ Vec2 → Java Vec2 ===
static jobject toJavaVec2(JNIEnv* env, Vec2 v) {
    jclass cls = env->FindClass("com/aether/game/Vec2");
    jmethodID ctor = env->GetMethodID(cls, "<init>", "(FF)V");
    return env->NewObject(cls, ctor, v.x, v.y);
}

// === Helper: Java Ball[] → C++ vector<Ball> ===
static std::vector<Ball> jBallsToCpp(JNIEnv* env, jobjectArray jballs) {
    std::vector<Ball> result;
    int len = env->GetArrayLength(jballs);

    jclass ballCls = env->FindClass("com/aether/game/Ball");
    jfieldID numField = env->GetFieldID(ballCls, "number", "I");
    jfieldID posField = env->GetFieldID(ballCls, "pos", "Lcom/aether/game/Vec2;");
    jfieldID pockedField = env->GetFieldID(ballCls, "pocketed", "Z");

    for (int i = 0; i < len; ++i) {
        jobject jball = env->GetObjectArrayElement(jballs, i);
        int num = env->GetIntField(jball, numField);
        jobject jpos = env->GetObjectField(jball, posField);
        bool pocked = env->GetBooleanField(jball, pockedField);

        Ball b(num, jVec2(env, jpos));
        b.pocketed = pocked;
        result.push_back(b);

        env->DeleteLocalRef(jpos);
        env->DeleteLocalRef(jball);
    }

    return result;
}

// =====================================================
//  JNI Functions
// =====================================================

extern "C" {

// === PhysicsEngine ===

JNIEXPORT jlong JNICALL
Java_com_aether_brain_PhysicsEngine_nativeCreate(JNIEnv* env, jclass) {
    return reinterpret_cast<jlong>(new PhysicsEngine());
}

JNIEXPORT jobject JNICALL
Java_com_aether_brain_PhysicsEngine_nativeSimulateFull(
    JNIEnv* env, jclass,
    jfloat cueX, jfloat cueY,
    jfloat aimX, jfloat aimY,
    jfloat power,
    jobjectArray jballs,
    jboolean hasSpin,
    jfloat sideSpin, jfloat topSpin) {

    Vec2 cuePos = {cueX, cueY};
    Vec2 aimDir = {aimX, aimY};
    auto balls = jBallsToCpp(env, jballs);

    auto result = PhysicsEngine::simulateFull(cuePos, aimDir, power, balls,
                                               hasSpin, sideSpin, topSpin);

    // สร้าง Java SimResult object
    jclass cls = env->FindClass("com/aether/brain/PhysicsEngine$FullSimResult");
    jmethodID ctor = env->GetMethodID(cls, "<init>", "()V");
    jobject jresult = env->NewObject(cls, ctor);

    // ตั้งค่า fields
    env->SetBooleanField(jresult, env->GetFieldID(cls, "cuePocketed", "Z"),
                          result.cuePocketed);
    env->SetIntField(jresult, env->GetFieldID(cls, "targetBallNum", "I"),
                      result.targetBallNum);
    env->SetIntField(jresult, env->GetFieldID(cls, "pocketIndex", "I"),
                      result.pocketIndex);
    env->SetIntField(jresult, env->GetFieldID(cls, "collisionCount", "I"),
                      result.collisionCount);

    return jresult;
}

// === StrategyEngine ===

JNIEXPORT jobject JNICALL
Java_com_aether_brain_StrategyEngine_nativeFindBestShot(
    JNIEnv* env, jclass,
    jfloat cueX, jfloat cueY,
    jobjectArray jmyBalls,
    jobjectArray jallBalls,
    jint myType) {

    Vec2 cuePos = {cueX, cueY};
    auto myBalls = jBallsToCpp(env, jmyBalls);
    auto allBalls = jBallsToCpp(env, jallBalls);

    auto shot = StrategyEngine::findBestShot(cuePos, myBalls, allBalls, myType);

    // สร้าง Java ShotOption
    jclass cls = env->FindClass("com/aether/brain/StrategyEngine$ShotOption");
    jmethodID ctor = env->GetMethodID(cls, "<init>", "()V");
    jobject jshot = env->NewObject(cls, ctor);

    env->SetIntField(jshot, env->GetFieldID(cls, "targetBallNum", "I"),
                      shot.targetBallNum);
    env->SetFloatField(jshot, env->GetFieldID(cls, "power", "F"), shot.power);
    env->SetFloatField(jshot, env->GetFieldID(cls, "score", "F"), shot.score);
    env->SetFloatField(jshot, env->GetFieldID(cls, "angle", "F"), shot.angle);
    env->SetBooleanField(jshot, env->GetFieldID(cls, "isBankShot", "Z"),
                          shot.isBankShot);
    env->SetFloatField(jshot, env->GetFieldID(cls, "sideSpin", "F"), shot.sideSpin);
    env->SetFloatField(jshot, env->GetFieldID(cls, "topSpin", "F"), shot.topSpin);

    return jshot;
}

// === HumanBehavior ===

JNIEXPORT jlong JNICALL
Java_com_aether_brain_HumanBehavior_nativeCreate(JNIEnv* env, jclass) {
    return reinterpret_cast<jlong>(new HumanBehavior());
}

JNIEXPORT void JNICALL
Java_com_aether_brain_HumanBehavior_nativeDestroy(JNIEnv*, jclass, jlong ptr) {
    delete reinterpret_cast<HumanBehavior*>(ptr);
}

JNIEXPORT jlong JNICALL
Java_com_aether_brain_HumanBehavior_nativeCalculateThinkTime(
    JNIEnv*, jclass, jlong ptr, jfloat power, jboolean isBankShot, jint bankCount) {

    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    ShotOption shot;
    shot.power = power;
    shot.isBankShot = isBankShot;
    shot.bankCount = bankCount;
    return hb->calculateThinkTime(shot);
}

JNIEXPORT jfloat JNICALL
Java_com_aether_brain_HumanBehavior_nativeAdjustAngle(
    JNIEnv*, jclass, jlong ptr, jfloat angle) {

    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    return hb->adjustAngle(angle);
}

JNIEXPORT jfloat JNICALL
Java_com_aether_brain_HumanBehavior_nativeAdjustPower(
    JNIEnv*, jclass, jlong ptr, jfloat power) {

    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    return hb->adjustPower(power);
}

JNIEXPORT jboolean JNICALL
Java_com_aether_brain_HumanBehavior_nativeWillMakeShot(
    JNIEnv*, jclass, jlong ptr, jfloat power, jboolean isBankShot, jint bankCount) {

    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    ShotOption shot;
    shot.power = power;
    shot.isBankShot = isBankShot;
    shot.bankCount = bankCount;
    return hb->willMakeShot(shot);
}

JNIEXPORT void JNICALL
Java_com_aether_brain_HumanBehavior_nativeUpdateMood(
    JNIEnv*, jclass, jlong ptr,
    jboolean madeLastShot, jboolean isWinning, jint ballsRemaining, jboolean isBreak) {

    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    hb->updateMood(madeLastShot, isWinning, ballsRemaining, isBreak);
}

JNIEXPORT jint JNICALL
Java_com_aether_brain_HumanBehavior_nativeGetMood(JNIEnv*, jclass, jlong ptr) {
    auto* hb = reinterpret_cast<HumanBehavior*>(ptr);
    return static_cast<jint>(hb->getMood());
}

} // extern "C"
