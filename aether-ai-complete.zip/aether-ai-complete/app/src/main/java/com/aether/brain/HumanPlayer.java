package com.aether.brain;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.aether.action.GameController;
import com.aether.game.Ball;
import com.aether.game.GameState;
import com.aether.game.Vec2;
import com.aether.vision.TableDetector;

import java.util.List;
import java.util.Random;

/**
 * HumanPlayer — AI ที่เล่นเหมือนมนุษย์จริง
 * 
 * รวม:
 * 1. HumanBehavior — อารมณ์ + จังหวะ + ความไม่แม่น
 * 2. GameController — ควบคุมเกม
 * 3. StrategyEngine — เลือกลูก
 * 4. PhysicsEngine — คำนวณฟิสิกส์
 * 
 * หลักการ:
 * - ไม่ยิงทันที ต้อง "คิด" ก่อน
 * - ไม่แม่น 100% มีโอกาสพลาด
 * - มีอารมณ์ มั่นใจ/ลังเล/หัวร้อน
 * - มีสไตล์ ชอบยิงตรง/ชอบชิ่ง
 * - มีจังหวะ เร็ว/ช้า ตามสถานการณ์
 */
public class HumanPlayer {
    private static final String TAG = "AetherPlayer";

    public interface PlayerCallback {
        void onThinking(String status);
        void onShotStart(String description);
        void onShotResult(boolean made, String reason);
        void onStatsUpdate(String stats);
    }

    private GameController gameController;
    private HumanBehavior behavior;
    private Handler mainHandler;
    private PlayerCallback callback;
    private Random random = new Random();

    // สถานะ
    private boolean playing = false;
    private boolean waitingForTurn = false;

    public HumanPlayer(GameController gameController) {
        this.gameController = gameController;
        this.behavior = new HumanBehavior();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void setCallback(PlayerCallback cb) {
        this.callback = cb;
    }

    public void setPlayStyle(HumanBehavior.PlayStyle style) {
        behavior.setPlayStyle(style);
    }

    /**
     * เริ่มเล่นอัตโนมัติ
     */
    public void startPlaying() {
        playing = true;
        gameController.startAutoPlay();
        Log.d(TAG, "Human player started");
    }

    /**
     * หยุดเล่น
     */
    public void stopPlaying() {
        playing = false;
        waitingForTurn = false;
        gameController.stopAutoPlay();
        Log.d(TAG, "Human player stopped");
    }

    /**
     * ตาของเรา — เริ่มกระบวนการคิด+ยิง
     */
    public void onMyTurn(final GameState state, final TableDetector.TableResult table) {
        if (!playing) return;

        waitingForTurn = true;
        notifyThinking("🤔 กำลังวิเคราะห์...");

        // === 1. คิด (ใน background) ===
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    thinkAndShoot(state, table);
                } catch (Exception e) {
                    Log.e(TAG, "Think error", e);
                }
            }
        }).start();
    }

    /**
     * กระบวนการคิด + ยิง (เหมือนมนุษย์)
     */
    private void thinkAndShoot(GameState state, TableDetector.TableResult table) {
        // === 1. วิเคราะห์สถานการณ์ ===
        List<Ball> myBalls = state.getMyBalls();
        List<Ball> activeBalls = state.getActiveBalls();

        if (myBalls.isEmpty()) {
            notifyResult(false, "ไม่พบลูกที่ต้องยิง");
            waitingForTurn = false;
            return;
        }

        // === 2. แนะนำสไตล์ ===
        HumanBehavior.PlayStyle suggestedStyle = behavior.suggestStyle(
            myBalls.size(),
            activeBalls.size() - myBalls.size(),
            state.isBreaking
        );
        behavior.setPlayStyle(suggestedStyle);

        // === 3. เลือกลูก ===
        notifyThinking("🔍 มองหาลูกที่ดีที่สุด...");
        StrategyEngine.ShotOption bestShot = StrategyEngine.findBestShot(state);

        if (bestShot == null) {
            notifyResult(false, "ไม่พบ shot ที่ดี");
            waitingForTurn = false;
            return;
        }

        // === 4. ตัดสินใจว่ายิงหรือไม่ ===
        if (!behavior.shouldTakeShot(bestShot)) {
            notifyThinking("🛡️ เปลี่ยนใจ ตั้งรับแทน...");
            // TODO: Implement safety play
            notifyResult(false, "เลือกตั้งรับ");
            waitingForTurn = false;
            return;
        }

        // === 5. คิด (ตามอารมณ์) ===
        long thinkTime = behavior.calculateThinkTime(bestShot);
        notifyThinking(String.format("🎯 เล็งลูก %d... (%.1f วินาที)",
            bestShot.targetBall.number, thinkTime / 1000f));

        // รอตามเวลาคิด (เหมือนคนคิด)
        sleep(thinkTime);

        // === 6. ปรับมุม (ความไม่แม่น) ===
        float adjustedAngle = behavior.adjustAngle(bestShot.angle);
        float adjustedPower = behavior.adjustPower(bestShot.power);

        Log.d(TAG, String.format("Original: angle=%.1f power=%.2f",
            Math.toDegrees(bestShot.angle), bestShot.power));
        Log.d(TAG, String.format("Adjusted: angle=%.1f power=%.2f",
            Math.toDegrees(adjustedAngle), adjustedPower));

        // === 7. ยิง! ===
        notifyShotStart(String.format("🎯 ยิงลูก %d → หลุม",
            bestShot.targetBall.number));

        // คำนวณตำแหน่งจริงบนจอ
        if (state.cueBall != null && table != null) {
            Vec2 cuePos = state.cueBall.pos;
            float cueScreenX = table.left + cuePos.x * table.width;
            float cueScreenY = table.top + cuePos.y * table.height;

            // ทิศทางยิง
            float aimX = (float) Math.cos(adjustedAngle);
            float aimY = (float) Math.sin(adjustedAngle);

            // ยิงผ่าน GameController
            gameController.simpleShot(cueScreenX, cueScreenY, aimX, aimY, adjustedPower);
        }

        // === 8. รอผล ===
        sleep(1000); // รอให้ลูกเคลื่อนที่

        // === 9. ตัดสินว่ายิงลงไหม ===
        boolean made = behavior.willMakeShot(bestShot);

        // อัปเดตอารมณ์
        behavior.updateMood(made, state.isAllMyBallsPocketed(),
            myBalls.size(), state.isBreaking);

        // แจ้งผล
        if (made) {
            notifyResult(true, "✅ ยิงลง!");
        } else {
            notifyResult(false, "❌ พลาด!");
        }

        // อัปเดตสถิติ
        notifyStats(behavior.getStats());

        waitingForTurn = false;
    }

    /**
     * ตาคู่แข่ง — รอ
     */
    public void onOpponentTurn() {
        if (!playing) return;
        waitingForTurn = false;
        notifyThinking("🔴 รอตาคู่แข่ง...");
    }

    // === Helper ===

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Log.e(TAG, "Sleep interrupted", e);
        }
    }

    private void notifyThinking(final String status) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onThinking(status);
            }
        });
    }

    private void notifyShotStart(final String description) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onShotStart(description);
            }
        });
    }

    private void notifyResult(final boolean made, final String reason) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onShotResult(made, reason);
            }
        });
    }

    private void notifyStats(final String stats) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onStatsUpdate(stats);
            }
        });
    }

    public boolean isPlaying() { return playing; }
    public boolean isWaitingForTurn() { return waitingForTurn; }
    public HumanBehavior getBehavior() { return behavior; }
}
