package com.aether.vision;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.aether.action.GameController;

/**
 * Accessibility Service — อ่าน UI + จำ模拟สัมผัส
 * สำหคับ:
 * 1. อ่านสถานะเกม (ตาใคร, ข้อความ)
 * 2. จำ模拟สัมผัส (สำหคับ Autoplay)
 */
public class AetherAccessibility extends AccessibilityService {
    private static final String TAG = "AetherA11y";
    private static final String GAME_PACKAGE = "com.miniclip.eightballpool";

    public interface AccessibilityCallback {
        void onGameDetected();
        void onTurnChanged(boolean myTurn);
        void onGameStateChanged(String state);
        void onTextFound(String text);
    }

    private static AccessibilityCallback callback;
    private static GameController gameController;
    private static AetherAccessibility instance;

    public static void setCallback(AccessibilityCallback cb) {
        callback = cb;
    }

    public static void setGameController(GameController controller) {
        gameController = controller;
    }

    public static AetherAccessibility getInstance() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;

        Log.d(TAG, "Accessibility Service connected");

        // ตั้งค่าให้ดักเฉพาะเกม
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) {
            info = new AccessibilityServiceInfo();
        }
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 100;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                   | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.packageNames = new String[]{GAME_PACKAGE};
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String packageName = event.getPackageName() != null ?
            event.getPackageName().toString() : "";

        // ตรวจว่าเป็นเกมไหม
        if (!packageName.equals(GAME_PACKAGE)) return;

        if (callback != null) callback.onGameDetected();

        // วิเคราะห์ event
        switch (event.getEventType()) {
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                analyzeGameUI();
                break;

            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                String text = event.getText().toString();
                analyzeText(text);
                break;
        }
    }

    /**
     * วิเคราะห์ UI ของเกม
     */
    private void analyzeGameUI() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            findTextsRecursive(root, 0);
        } catch (Exception e) {
            Log.e(TAG, "UI analysis error", e);
        } finally {
            root.recycle();
        }
    }

    private void findTextsRecursive(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 10) return;

        CharSequence text = node.getText();
        if (text != null && text.length() > 0) {
            analyzeText(text.toString().toLowerCase());
        }

        CharSequence desc = node.getContentDescription();
        if (desc != null && desc.length() > 0) {
            analyzeText(desc.toString().toLowerCase());
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                findTextsRecursive(child, depth + 1);
                child.recycle();
            }
        }
    }

    private void analyzeText(String text) {
        text = text.toLowerCase().trim();

        // ตรวจตา
        if (text.contains("your turn") || text.contains("ตาคุณ") ||
            text.contains("shoot") || text.contains("aim")) {
            if (callback != null) callback.onTurnChanged(true);
        }

        if (text.contains("opponent") || text.contains("waiting") ||
            text.contains("คู่แข่ง") || text.contains("รอ")) {
            if (callback != null) callback.onTurnChanged(false);
        }

        // ตรวจสถานะเกม
        if (text.contains("break") || text.contains("เริ่ม")) {
            if (callback != null) callback.onGameStateChanged("breaking");
        }

        if (text.contains("win") || text.contains("ชนะ")) {
            if (callback != null) callback.onGameStateChanged("win");
        }

        if (text.contains("lose") || text.contains("แพ้")) {
            if (callback != null) callback.onGameStateChanged("lose");
        }

        if (callback != null) callback.onTextFound(text);
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        Log.d(TAG, "Accessibility destroyed");
    }
}
