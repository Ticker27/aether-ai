package com.aether.action;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.aether.brain.PhysicsEngine;
import com.aether.brain.StrategyEngine;
import com.aether.game.Ball;
import com.aether.game.GameState;
import com.aether.game.Vec2;
import com.aether.vision.TableDetector;

import java.util.List;

/**
 * ควบคุมเกมอัตโนมัติ (Autoplay)
 * — เล็ง + ยิง + ตั้ง power + spin
 * — ใช้ TouchController จำลองสัมผัส
 */
public class GameController {
    private static final String TAG = "AetherGame";

    public interface GameCallback {
        void onActionStart(String action);
        void onActionComplete(String action, boolean success);
        void onGameUpdate(String status);
    }

    private AccessibilityService service;
    private TouchController touch;
    private Handler mainHandler;
    private GameCallback callback;

    // ข้อมูลหน้าจอ
    private int screenW, screenH;

    // ข้อมูลโต๊ะ
    private float tableLeft, tableTop, tableWidth, tableHeight;

    // สถานะ
    private boolean autoPlaying = false;
    private boolean waitingForShot = false;

    public GameController(AccessibilityService service, int screenW, int screenH) {
        this.service = service;
        this.screenW = screenW;
        this.screenH = screenH;
        this.touch = new TouchController(service);
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public void setCallback(GameCallback cb) {
        this.callback = cb;
    }

    public void setTableBounds(float left, float top, float width, float height) {
        this.tableLeft = left;
        this.tableTop = top;
        this.tableWidth = width;
        this.tableHeight = height;
    }

    /**
     * เริ่ม Autoplay
     */
    public void startAutoPlay() {
        autoPlaying = true;
        Log.d(TAG, "Autoplay started");
        notifyAction("🎮 Autoplay เริ่มแล้ว");
    }

    /**
     * หยุด Autoplay
     */
    public void stopAutoPlay() {
        autoPlaying = false;
        waitingForShot = false;
        Log.d(TAG, "Autoplay stopped");
        notifyAction("⏹️ Autoplay หยุดแล้ว");
    }

    public boolean isAutoPlaying() {
        return autoPlaying;
    }

    /**
     * ยิงอัตโนมัติ — หัวใจหลักของ Autoplay
     *
     * @param cueBallPos  ตำแหน่งลูก cue (normalized)
     * @param shot        ข้อมูล shot ที่ต้องยิง
     * @param table       ข้อมูลโต๊ะ
     */
    public void executeShot(Vec2 cueBallPos, StrategyEngine.ShotOption shot,
                             TableDetector.TableResult table) {
        if (!autoPlaying || waitingForShot) return;

        waitingForShot = true;
        notifyAction("🎯 กำลังเล็ง...");

        // === 1. คำนวณตำแหน่งจริงบนจอ ===
        float cueScreenX = table.left + cueBallPos.x * table.width;
        float cueScreenY = table.top + cueBallPos.y * table.height;

        // จุดที่ต้องเล็ง (ทิศทาง aim)
        float aimDirX = shot.aimDir.x;
        float aimDirY = shot.aimDir.y;

        // ระยะดึงไม้ (power)
        float power = shot.power;

        // === 2. เล็งอัตโนมัติ ===
        float aimLength = 100f; // ระยะลากเล็ง (pixels)
        float aimEndX = cueScreenX + aimDirX * aimLength;
        float aimEndY = cueScreenY + aimDirY * aimLength;

        // === 3. ยิงอัตโนมัติ ===
        // ลากจากจุดเล็งไปทิศตรงข้าม (ดึงไม้คิว)
        float pullLength = power * 150f; // ระยะดึง (pixels)
        float pullEndX = cueScreenX - aimDirX * pullLength;
        float pullEndY = cueScreenY - aimDirY * pullLength;

        // สร้างชุดการกระทำ
        TouchController.TouchAction[] actions = {
            // แตะที่ลูก cue (เริ่มเล็ง)
            TouchController.TouchAction.tap(cueScreenX, cueScreenY),

            // รอให้เกมตอบสนอง
            TouchController.TouchAction.delay(300),

            // ลากเล็งไปทิศที่ต้องการ
            TouchController.TouchAction.swipe(
                cueScreenX, cueScreenY,
                aimEndX, aimEndY,
                500 // ระยะเวลาลาก (ms)
            ),

            // รอ
            TouchController.TouchAction.delay(200),

            // ดึงไม้คิว (จากจุดเล็ง ถอยหลังตาม power)
            TouchController.TouchAction.swipe(
                aimEndX, aimEndY,
                pullEndX, pullEndY,
                (long)(power * 800) // ยิ่งแรง ยิ่งลากนาน
            ),

            // รอ
            TouchController.TouchAction.delay(100),

            // ปล่อย (ยิง!) — ลากกลับไปข้างหน้าเร็วๆ
            TouchController.TouchAction.swipe(
                pullEndX, pullEndY,
                aimEndX, aimEndY,
                50 // เร็วมาก = ยิงแรง
            ),
        };

        // === 4. ทำการกระทำ ===
        touch.performSequence(actions, new TouchController.TouchCallback() {
            @Override
            public void onResult(boolean success) {
                waitingForShot = false;
                if (success) {
                    notifyAction("✅ ยิงสำเร็จ!");
                    Log.d(TAG, "Shot executed successfully");
                } else {
                    notifyAction("❌ ยิงไม่สำเร็จ");
                    Log.w(TAG, "Shot failed");
                }
                if (callback != null) {
                    callback.onActionComplete("shoot", success);
                }
            }
        });
    }

    /**
     * ยิงแบบง่าย (สำหคับทดสอบ)
     */
    public void simpleShot(float screenX, float screenY, float aimX, float aimY, float power) {
        if (!autoPlaying) return;

        // ดึงไม้คิว
        float pullX = screenX - aimX * power * 100;
        float pullY = screenY - aimY * power * 100;

        TouchController.TouchAction[] actions = {
            TouchController.TouchAction.tap(screenX, screenY),
            TouchController.TouchAction.delay(300),
            TouchController.TouchAction.swipe(screenX, screenY, pullX, pullY, 500),
            TouchController.TouchAction.delay(100),
            TouchController.TouchAction.swipe(pullX, pullY, screenX, screenY, 50),
        };

        touch.performSequence(actions, null);
    }

    /**
     * แตะเพื่อเริ่มตา (กรณีเกมขอให้แตะ)
     */
    public void tapToContinue(float x, float y) {
        touch.tap(x, y, null);
    }

    private void notifyAction(final String action) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (callback != null) callback.onActionStart(action);
            }
        });
    }
}
