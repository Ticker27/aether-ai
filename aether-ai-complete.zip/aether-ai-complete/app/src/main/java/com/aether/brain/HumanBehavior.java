package com.aether.brain;

import android.util.Log;

import java.util.Random;

/**
 * พฤติกรรมมนุษย์ — ทำให้ AI เล่นเหมือนคนจริง
 * 
 * หลักการ:
 * 1. ไม่ยิงทันที — ต้อง "คิด" ก่อน
 * 2. ไม่แม่น 100% — มีโอกาสพลาด
 * 3. มีอารมณ์ — มั่นใจ/ลังเล/หัวร้อน
 * 4. มีสไตล์ — ชอบยิงตรง/ชอบชิ่ง
 * 5. มีจังหวะ — เร็ว/ช้า ตามสถานการณ์
 */
public class HumanBehavior {
    private static final String TAG = "AetherHuman";

    // === สไตล์การเล่น ===
    public enum PlayStyle {
        AGGRESSIVE,   // ยิงเร็ว เสี่ยงเยอะ
        DEFENSIVE,    // ยิงช้า ปลอดภัย
        BALANCED,     // สมดุล
        SHOWOFF,      // ชอบโชว์ ยิงชิ่งบ่อย
        CAUTIOUS      // รอบคอบ คิดนาน
    }

    // === อารมณ์ ===
    public enum Mood {
        CONFIDENT,    // มั่นใจ ยิงเร็ว
        NERVOUS,      // ตื่นเต้น ลังเล
        FOCUSED,      // จดจ่อ คิดละเอียด
        FRUSTRATED,   // หัวร้อน ยิงเร็วขึ้น
        RELAXED       // ผ่อนคลาย ยิงช้า
    }

    // === ค่าคงที่ ===
    private static final float BASE_ACCURACY = 0.85f;      // ความแม่นพื้นฐาน (85%)
    private static final float MAX_ACCURACY = 0.95f;        // ความแม่นสูงสุด
    private static final float MIN_ACCURACY = 0.60f;        // ความแม่นต่ำสุด
    private static final long MIN_THINK_TIME = 500;         // เวลาคิดต่ำสุด (ms)
    private static final long MAX_THINK_TIME = 5000;        // เวลาคิดสูงสุด (ms)
    private static final float ANGLE_NOISE = 3.0f;          // สัญญาณรบกวนมุม (องศา)
    private static final float POWER_NOISE = 0.08f;         // สัญญาณรบกวนแรง (0-1)

    // === สถานะปัจจุบัน ===
    private PlayStyle style = PlayStyle.BALANCED;
    private Mood mood = Mood.RELAXED;
    private Random random = new Random();

    // === สถิติ ===
    private int shotsTaken = 0;
    private int shotsMade = 0;
    private int consecutiveMisses = 0;
    private int consecutiveMakes = 0;
    private float currentAccuracy = BASE_ACCURACY;

    // === ตัวเลขสุ่มสำหคับความเป็นมนุษย์ ===
    private float personalityFactor;  // 0-1 (0=ขี้อาย, 1=มั่นใจ)
    private float patienceFactor;     // 0-1 (0=รีบ, 1=อดทน)
    private float riskTolerance;      // 0-1 (0=ปลอดภัย, 1=เสี่ยง)

    public HumanBehavior() {
        // สุ่มบุคลิก
        personalityFactor = 0.3f + random.nextFloat() * 0.5f;  // 0.3-0.8
        patienceFactor = 0.2f + random.nextFloat() * 0.6f;     // 0.2-0.8
        riskTolerance = 0.2f + random.nextFloat() * 0.5f;      // 0.2-0.7

        Log.d(TAG, String.format("Personality: %.2f, Patience: %.2f, Risk: %.2f",
            personalityFactor, patienceFactor, riskTolerance));
    }

    /**
     * ตั้งค่าสไตล์การเล่น
     */
    public void setPlayStyle(PlayStyle style) {
        this.style = style;
        updateFactors();
    }

    /**
     * อัปเดตอารมณ์จากสถานการณ์
     */
    public void updateMood(boolean madeLastShot, boolean isWinning,
                            int ballsRemaining, boolean isBreak) {
        // ถ้ายิงลงติดต่อกัน → มั่นใจ
        if (madeLastShot) {
            consecutiveMakes++;
            consecutiveMisses = 0;
            if (consecutiveMakes >= 3) {
                mood = Mood.CONFIDENT;
            } else if (consecutiveMakes >= 2) {
                mood = Mood.FOCUSED;
            }
        } else {
            // ถ้ายิงพลาด → หัวร้อน/ตื่นเต้น
            consecutiveMisses++;
            consecutiveMakes = 0;
            if (consecutiveMisses >= 3) {
                mood = Mood.FRUSTRATED;
            } else if (consecutiveMisses >= 2) {
                mood = Mood.NERVOUS;
            } else {
                mood = Mood.FOCUSED;
            }
        }

        // ถ้าใกล้ชนะ → ตื่นเต้น
        if (ballsRemaining <= 2 && isWinning) {
            mood = Mood.NERVOUS;
        }

        // ถ้า break → ผ่อนคลาย
        if (isBreak) {
            mood = Mood.RELAXED;
        }

        Log.d(TAG, "Mood: " + mood + " | Consecutive makes: " + consecutiveMakes);
    }

    /**
     * คำนวณเวลาคิด (เหมือนมนุษย์)
     */
    public long calculateThinkTime(StrategyEngine.ShotOption shot) {
        long baseTime;

        // ตามความยากของ shot
        float difficulty = calculateDifficulty(shot);

        // ตามอารมณ์
        switch (mood) {
            case CONFIDENT:
                baseTime = (long) (MIN_THINK_TIME + difficulty * 1000);
                break;
            case NERVOUS:
                baseTime = (long) (MIN_THINK_TIME + difficulty * 2500);
                break;
            case FOCUSED:
                baseTime = (long) (MIN_THINK_TIME + difficulty * 1500);
                break;
            case FRUSTRATED:
                baseTime = (long) (MIN_THINK_TIME + difficulty * 500); // รีบยิง
                break;
            case RELAXED:
            default:
                baseTime = (long) (MIN_THINK_TIME + difficulty * 2000);
                break;
        }

        // ตามสไตล์
        switch (style) {
            case AGGRESSIVE:
                baseTime = (long) (baseTime * 0.6f);
                break;
            case CAUTIOUS:
                baseTime = (long) (baseTime * 1.5f);
                break;
            case SHOWOFF:
                baseTime = (long) (baseTime * 0.8f);
                break;
        }

        // ตามบุคลิก
        baseTime = (long) (baseTime * (0.5f + patienceFactor));

        // เพิ่มความสุ่ม (±20%)
        float jitter = 0.8f + random.nextFloat() * 0.4f;
        baseTime = (long) (baseTime * jitter);

        // จำกัดช่วง
        return Math.max(MIN_THINK_TIME, Math.min(MAX_THINK_TIME, baseTime));
    }

    /**
     * คำนวณความยากของ shot (0-1)
     */
    private float calculateDifficulty(StrategyEngine.ShotOption shot) {
        float difficulty = 0.3f;  // พื้นฐาน

        // มุมตัดยิ่งมาก ยิ่งยาก
        if (shot.angle != 0) {
            float angleDeg = (float) Math.toDegrees(shot.angle);
            float cutAngle = Math.abs(angleDeg) % 90;
            difficulty += (cutAngle / 90f) * 0.3f;
        }

        // ระยะไกล ยิ่งยาก
        difficulty += shot.power * 0.2f;

        // bank shot ยากกว่า
        if (shot.isBankShot) {
            difficulty += 0.2f;
            difficulty += shot.bankCount * 0.1f;
        }

        // spin ยากกว่า
        if (Math.abs(shot.sideSpin) > 0.1f || Math.abs(shot.topSpin) > 0.1f) {
            difficulty += 0.1f;
        }

        return Math.min(1f, difficulty);
    }

    /**
     * ปรับมุมยิง (เพิ่มความไม่แม่น)
     */
    public float adjustAngle(float angle) {
        // คำนวณ noise ตามอารมณ์และสถานการณ์
        float noise = ANGLE_NOISE;

        switch (mood) {
            case CONFIDENT:
                noise *= 0.5f;  // มั่นใจ → นิ่ง
                break;
            case NERVOUS:
                noise *= 1.5f;  // ตื่นเต้น → สั่น
                break;
            case FRUSTRATED:
                noise *= 1.3f;  // หัวร้อน → รีบ
                break;
            case FOCUSED:
                noise *= 0.7f;  // จดจ่อ → นิ่ง
                break;
        }

        // ตามบุคลิก
        noise *= (1.0f - personalityFactor * 0.5f);

        // สุ่ม noise
        float adjustment = (random.nextFloat() - 0.5f) * 2 * noise;

        // บางทีก็ไม่ปรับ (เหมือนคนเล็งตรง)
        if (random.nextFloat() < 0.3f) {
            adjustment = 0;
        }

        return angle + adjustment;
    }

    /**
     * ปรับแรงยิง (เพิ่มความไม่แม่น)
     */
    public float adjustPower(float power) {
        float noise = POWER_NOISE;

        switch (mood) {
            case CONFIDENT:
                noise *= 0.6f;
                break;
            case NERVOUS:
                noise *= 1.4f;
                break;
            case FRUSTRATED:
                noise *= 1.2f;
                break;
        }

        // สุ่ม noise
        float adjustment = (random.nextFloat() - 0.5f) * 2 * noise;

        // บางทีก็ไม่ปรับ
        if (random.nextFloat() < 0.4f) {
            adjustment = 0;
        }

        float result = power + adjustment;
        return Math.max(0.1f, Math.min(1f, result));
    }

    /**
     * ตัดสินใจว่ายิงหรือไม่ (บางทีคนก็เปลี่ยนใจ)
     */
    public boolean shouldTakeShot(StrategyEngine.ShotOption shot) {
        float difficulty = calculateDifficulty(shot);

        // ถ้ายากมาก → บางทีไม่ยิง (เลือกตั้งรับ)
        if (difficulty > 0.8f) {
            float chance = 0.3f + riskTolerance * 0.5f;
            if (random.nextFloat() > chance) {
                Log.d(TAG, "Shot too difficult, choosing safety");
                return false;
            }
        }

        // ถ้าอารมณ์หัวร้อน → ยิงหมด (ไม่สน)
        if (mood == Mood.FRUSTRATED) {
            return true;
        }

        // ถ้ารอบคอบ → ไม่ยิงถ้าเสี่ยง
        if (style == PlayStyle.CAUTIOUS && difficulty > 0.6f) {
            if (random.nextFloat() < 0.4f) {
                return false;
            }
        }

        return true;
    }

    /**
     * คำนวณความแม่น (เปลี่ยนตามสถานการณ์)
     */
    public float calculateAccuracy() {
        float accuracy = BASE_ACCURACY;

        // ตามอารมณ์
        switch (mood) {
            case CONFIDENT:
                accuracy += 0.08f;
                break;
            case NERVOUS:
                accuracy -= 0.10f;
                break;
            case FOCUSED:
                accuracy += 0.05f;
                break;
            case FRUSTRATED:
                accuracy -= 0.15f;
                break;
            case RELAXED:
                accuracy += 0.02f;
                break;
        }

        // ตามสถิติ (momentum)
        if (consecutiveMakes >= 3) {
            accuracy += 0.05f;  // ยิงลงติด → มั่นใจขึ้น
        }
        if (consecutiveMisses >= 2) {
            accuracy -= 0.08f;  // พลาดติด → ไม่มั่นใจ
        }

        // ตามบุคลิก
        accuracy += (personalityFactor - 0.5f) * 0.1f;

        // จำกัดช่วง
        return Math.max(MIN_ACCURACY, Math.min(MAX_ACCURACY, accuracy));
    }

    /**
     * ตัดสินใจว่ายิงลงไหม (ความน่าจะเป็น)
     */
    public boolean willMakeShot(StrategyEngine.ShotOption shot) {
        float accuracy = calculateAccuracy();
        float difficulty = calculateDifficulty(shot);

        // โอกาสรอด = accuracy * (1 - difficulty * 0.5)
        float successChance = accuracy * (1f - difficulty * 0.5f);

        boolean made = random.nextFloat() < successChance;

        // อัปเดตสถิติ
        shotsTaken++;
        if (made) {
            shotsMade++;
        }

        Log.d(TAG, String.format("Shot: difficulty=%.2f, accuracy=%.2f, chance=%.2f, made=%s",
            difficulty, accuracy, successChance, made));

        return made;
    }

    /**
     * เลือกสไตล์ตามสถานการณ์
     */
    public PlayStyle suggestStyle(int myBallsLeft, int oppBallsLeft, boolean isBreak) {
        if (isBreak) {
            return PlayStyle.AGGRESSIVE;
        }

        // ถ้านำเยอะ → ปลอดภัย
        if (myBallsLeft < oppBallsLeft - 2) {
            return PlayStyle.DEFENSIVE;
        }

        // ถ้าตาม → เสี่ยง
        if (myBallsLeft > oppBallsLeft + 2) {
            return PlayStyle.AGGRESSIVE;
        }

        // ถ้าเท่าๆ → สมดุล
        return PlayStyle.BALANCED;
    }

    /**
     * ดึงสถิติ
     */
    public String getStats() {
        float pct = shotsTaken > 0 ? (float) shotsMade / shotsTaken * 100 : 0;
        return String.format("Shots: %d/%d (%.0f%%) | Mood: %s | Style: %s",
            shotsMade, shotsTaken, pct, mood, style);
    }

    public Mood getMood() { return mood; }
    public PlayStyle getStyle() { return style; }

    private void updateFactors() {
        switch (style) {
            case AGGRESSIVE:
                riskTolerance = Math.min(1f, riskTolerance + 0.2f);
                patienceFactor = Math.max(0, patienceFactor - 0.2f);
                break;
            case DEFENSIVE:
                riskTolerance = Math.max(0, riskTolerance - 0.2f);
                patienceFactor = Math.min(1f, patienceFactor + 0.2f);
                break;
            case SHOWOFF:
                riskTolerance = Math.min(1f, riskTolerance + 0.3f);
                break;
            case CAUTIOUS:
                patienceFactor = Math.min(1f, patienceFactor + 0.3f);
                break;
        }
    }
}
