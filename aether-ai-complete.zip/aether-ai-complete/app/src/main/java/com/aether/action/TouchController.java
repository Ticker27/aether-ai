package com.aether.action;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/**
 * จำลองสัมผัสหน้าจอผ่าน Accessibility Service
 * — แตะ, ลาก, ปล่อย
 * — ใช้ควบคุมเกม 8 Ball Pool
 */
public class TouchController {
    private static final String TAG = "AetherTouch";

    private AccessibilityService service;
    private Handler mainHandler;

    public TouchController(AccessibilityService service) {
        this.service = service;
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    /**
     * แตะจุดเดียว
     */
    public void tap(float x, float y, final TouchCallback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            Log.w(TAG, "Gesture not supported on this API");
            if (callback != null) callback.onResult(false);
            return;
        }

        try {
            Path path = new Path();
            path.moveTo(x, y);

            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 50);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);

            service.dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    Log.d(TAG, "Tap completed");
                    if (callback != null) callback.onResult(true);
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    Log.w(TAG, "Tap cancelled");
                    if (callback != null) callback.onResult(false);
                }
            }, mainHandler);

        } catch (Exception e) {
            Log.e(TAG, "Tap error", e);
            if (callback != null) callback.onResult(false);
        }
    }

    /**
     * ลากจากจุด A ไปจุด B
     * duration: ระยะเวลา (ms)
     */
    public void swipe(float fromX, float fromY, float toX, float toY,
                       long duration, final TouchCallback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            if (callback != null) callback.onResult(false);
            return;
        }

        try {
            Path path = new Path();
            path.moveTo(fromX, fromY);
            path.lineTo(toX, toY);

            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, duration);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);

            service.dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    Log.d(TAG, "Swipe completed");
                    if (callback != null) callback.onResult(true);
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    Log.w(TAG, "Swipe cancelled");
                    if (callback != null) callback.onResult(false);
                }
            }, mainHandler);

        } catch (Exception e) {
            Log.e(TAG, "Swipe error", e);
            if (callback != null) callback.onResult(false);
        }
    }

    /**
     * ลากแบบกดค้าง (สำหคับดึงไม้คิว)
     * holdTime: เวลาที่กดค้าง (ms)
     */
    public void dragAndHold(float fromX, float fromY, float toX, float toY,
                             long holdTime, final TouchCallback callback) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            if (callback != null) callback.onResult(false);
            return;
        }

        try {
            // สร้าง path: ไปจุดเริ่ม → ค้าง → ไปจุดปลาย
            Path path = new Path();
            path.moveTo(fromX, fromY);

            // ค้างที่จุดเริ่ม
            path.lineTo(fromX + 1, fromY + 1); // เคลื่อนที่เล็กน้อย

            GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, holdTime);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(stroke);

            service.dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    Log.d(TAG, "Drag-hold completed");
                    if (callback != null) callback.onResult(true);
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    Log.w(TAG, "Drag-hold cancelled");
                    if (callback != null) callback.onResult(false);
                }
            }, mainHandler);

        } catch (Exception e) {
            Log.e(TAG, "Drag-hold error", e);
            if (callback != null) callback.onResult(false);
        }
    }

    /**
     * ชุดของการกระทำ (sequence)
     */
    public void performSequence(final TouchAction[] actions, final TouchCallback callback) {
        if (actions == null || actions.length == 0) {
            if (callback != null) callback.onResult(true);
            return;
        }

        // ทำทีละอัน
        performAction(actions, 0, callback);
    }

    private void performAction(final TouchAction[] actions, final int index,
                                final TouchCallback callback) {
        if (index >= actions.length) {
            if (callback != null) callback.onResult(true);
            return;
        }

        TouchAction action = actions[index];

        switch (action.type) {
            case TAP:
                tap(action.x1, action.y1, new TouchCallback() {
                    @Override
                    public void onResult(boolean success) {
                        // ทำอันถัดไป
                        mainHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                performAction(actions, index + 1, callback);
                            }
                        }, action.delay);
                    }
                });
                break;

            case SWIPE:
                swipe(action.x1, action.y1, action.x2, action.y2,
                    action.duration, new TouchCallback() {
                        @Override
                        public void onResult(boolean success) {
                            mainHandler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    performAction(actions, index + 1, callback);
                                }
                            }, action.delay);
                        }
                    });
                break;

            case DELAY:
                mainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        performAction(actions, index + 1, callback);
                    }
                }, action.duration);
                break;
        }
    }

    // === Callback ===
    public interface TouchCallback {
        void onResult(boolean success);
    }

    // === Action types ===
    public enum ActionType {
        TAP, SWIPE, DELAY
    }

    // === Action data ===
    public static class TouchAction {
        public ActionType type;
        public float x1, y1, x2, y2;
        public long duration;
        public long delay;

        public static TouchAction tap(float x, float y) {
            TouchAction a = new TouchAction();
            a.type = ActionType.TAP;
            a.x1 = x; a.y1 = y;
            a.delay = 100;
            return a;
        }

        public static TouchAction swipe(float x1, float y1, float x2, float y2, long duration) {
            TouchAction a = new TouchAction();
            a.type = ActionType.SWIPE;
            a.x1 = x1; a.y1 = y1;
            a.x2 = x2; a.y2 = y2;
            a.duration = duration;
            a.delay = 200;
            return a;
        }

        public static TouchAction delay(long ms) {
            TouchAction a = new TouchAction();
            a.type = ActionType.WAIT;
            a.duration = ms;
            return a;
        }
    }
}
