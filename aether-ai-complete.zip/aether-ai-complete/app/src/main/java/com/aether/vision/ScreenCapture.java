package com.aether.vision;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

/**
 * จับภาพหน้าจอผ่าน MediaProjection API
 * แก้ไข: เพิ่ม error handling ป้องกัน crash
 */
public class ScreenCapture {
    private static final String TAG = "AetherCapture";
    private static final int FPS = 10;

    private Context context;
    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private int screenWidth, screenHeight, screenDpi;
    private HandlerThread captureThread;
    private Handler captureHandler;

    private volatile boolean running = false;
    private long lastFrameTime = 0;
    private long frameIntervalMs = 1000 / FPS;

    public interface FrameCallback {
        void onFrame(Bitmap frame, long timestamp);
    }
    private FrameCallback callback;

    public ScreenCapture(Context context, MediaProjection projection) {
        this.context = context;
        this.mediaProjection = projection;

        // วัดขนาดจอ
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;
        screenDpi = dm.densityDpi;

        // ลดความละเอียดลง 50%
        screenWidth = screenWidth / 2;
        screenHeight = screenHeight / 2;

        Log.d(TAG, "Screen: " + screenWidth + "x" + screenHeight + " dpi=" + screenDpi);
    }

    public void setFrameCallback(FrameCallback cb) {
        this.callback = cb;
    }

    /**
     * เริ่มจับภาพ — เพิ่ม error handling
     */
    public void start() {
        if (running) {
            Log.w(TAG, "Already running");
            return;
        }

        try {
            running = true;

            // สร้าง background thread
            captureThread = new HandlerThread("AetherCapture");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());

            // สร้าง ImageReader
            imageReader = ImageReader.newInstance(
                screenWidth, screenHeight,
                PixelFormat.RGBA_8888,
                2
            );

            // ตั้งค่า callback
            imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    if (!running) return;

                    // Rate limiting
                    long now = System.currentTimeMillis();
                    if (now - lastFrameTime < frameIntervalMs) {
                        try {
                            Image img = reader.acquireLatestImage();
                            if (img != null) img.close();
                        } catch (Exception e) {
                            Log.e(TAG, "Skip frame error", e);
                        }
                        return;
                    }
                    lastFrameTime = now;

                    Image image = null;
                    try {
                        image = reader.acquireLatestImage();
                        if (image == null) return;

                        Bitmap bitmap = imageToBitmap(image);
                        if (callback != null && bitmap != null) {
                            callback.onFrame(bitmap, now);
                        }
                        if (bitmap != null) {
                            bitmap.recycle();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Frame processing error", e);
                    } finally {
                        if (image != null) {
                            try {
                                image.close();
                            } catch (Exception e) {
                                Log.e(TAG, "Image close error", e);
                            }
                        }
                    }
                }
            }, captureHandler);

            // สร้าง VirtualDisplay — ใช้ try-catch ป้องกัน crash
            try {
                virtualDisplay = mediaProjection.createVirtualDisplay(
                    "AetherScreen",
                    screenWidth, screenHeight, screenDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null, captureHandler
                );
                Log.d(TAG, "Screen capture started");
            } catch (Exception e) {
                Log.e(TAG, "VirtualDisplay error", e);
                stop();
                return;
            }

        } catch (Exception e) {
            Log.e(TAG, "Start error", e);
            running = false;
        }
    }

    /**
     * หยุดจับภาพ — เพิ่ม error handling
     */
    public void stop() {
        running = false;

        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "VirtualDisplay release error", e);
        }

        try {
            if (imageReader != null) {
                imageReader.close();
                imageReader = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "ImageReader close error", e);
        }

        try {
            if (captureThread != null) {
                captureThread.quitSafely();
                captureThread = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Thread quit error", e);
        }

        try {
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Projection stop error", e);
        }

        Log.d(TAG, "Screen capture stopped");
    }

    public boolean isRunning() { return running; }
    public int getWidth() { return screenWidth; }
    public int getHeight() { return screenHeight; }

    /**
     * แปลง Image เป็น Bitmap — เพิ่ม error handling
     */
    private Bitmap imageToBitmap(Image image) {
        try {
            int w = image.getWidth(), h = image.getHeight();
            Image.Plane plane = image.getPlanes()[0];
            int stride = plane.getRowStride();
            int pixelStride = plane.getPixelStride();
            int rowPadding = stride - pixelStride * w;

            Bitmap bitmap = Bitmap.createBitmap(
                w + rowPadding / pixelStride, h,
                Bitmap.Config.ARGB_8888
            );
            bitmap.copyPixelsFromBuffer(plane.getBuffer());

            // Crop padding
            if (rowPadding > 0) {
                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, w, h);
                bitmap.recycle();
                return cropped;
            }
            return bitmap;
        } catch (Exception e) {
            Log.e(TAG, "ImageToBitmap error", e);
            return null;
        }
    }
}
